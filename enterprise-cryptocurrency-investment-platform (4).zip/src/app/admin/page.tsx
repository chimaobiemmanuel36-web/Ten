"use client";

import React, { useEffect, useState } from "react";
import {
  ShieldAlert,
  Users,
  ArrowDownLeft,
  ArrowUpRight,
  Settings,
  TrendingUp,
  CheckCircle2,
  XCircle,
  AlertCircle,
  BarChart3,
  RefreshCw,
  Wallet,
  Lock,
} from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function AdminDashboardPage() {
  const [activeTab, setActiveTab] = useState<
    "overview" | "deposits" | "withdrawals" | "users" | "plans" | "settings"
  >("overview");
  const [stats, setStats] = useState<any>(null);
  const [deposits, setDeposits] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [plansList, setPlansList] = useState<any[]>([]);
  const [settingsMap, setSettingsMap] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const router = useRouter();

  const fetchAdminData = async () => {
    setLoading(true);
    try {
      const [stRes, dRes, wRes, uRes, pRes, sRes] = await Promise.all([
        fetch("/api/admin/stats", { cache: "no-store", headers: { "Cache-Control": "no-cache" } }),
        fetch("/api/deposits?all=true", { cache: "no-store", headers: { "Cache-Control": "no-cache" } }),
        fetch("/api/withdrawals?all=true", { cache: "no-store", headers: { "Cache-Control": "no-cache" } }),
        fetch("/api/admin/users", { cache: "no-store", headers: { "Cache-Control": "no-cache" } }),
        fetch("/api/plans?all=true", { cache: "no-store", headers: { "Cache-Control": "no-cache" } }),
        fetch("/api/settings", { cache: "no-store", headers: { "Cache-Control": "no-cache" } }),
      ]);

      if (stRes.status === 403 || stRes.status === 401) {
        const localUserStr = localStorage.getItem("apex_crypto_user");
        try {
          const u = localUserStr ? JSON.parse(localUserStr) : null;
          if (!u || (u.role !== "admin" && u.role !== "superadmin")) {
            router.push("/dashboard");
            return;
          }
        } catch {
          router.push("/dashboard");
          return;
        }
      }

      const stData = await stRes.json();
      const dData = await dRes.json();
      const wData = await wRes.json();
      const uData = await uRes.json();
      const pData = await pRes.json();
      const sData = await sRes.json();

      if (stData.stats) setStats(stData.stats);
      if (dData.deposits) setDeposits(dData.deposits);
      if (wData.withdrawals) setWithdrawals(wData.withdrawals);
      if (uData.users) setUsersList(uData.users);
      if (pData.plans) setPlansList(pData.plans);
      if (sData.settings) setSettingsMap(sData.settings);
    } catch {
      // Quiet
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  const handleDepositReview = async (depositId: number, action: "confirm" | "reject") => {
    setMessage("");
    setError("");
    try {
      const res = await fetch("/api/deposits", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ depositId, action }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error || "Failed to process deposit");
      } else {
        setMessage(data.message || "Deposit review processed successfully");
        await fetchAdminData();
      }
    } catch {
      setError("Network error processing deposit review");
    }
  };

  const handleWithdrawalReview = async (withdrawalId: number, action: "approve" | "reject") => {
    setMessage("");
    setError("");
    try {
      const res = await fetch("/api/withdrawals", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ withdrawalId, action }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error || "Failed to process withdrawal");
      } else {
        setMessage(data.message || "Withdrawal review processed successfully");
        await fetchAdminData();
      }
    } catch {
      setError("Network error processing withdrawal review");
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage("");
    setError("");
    try {
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ updates: settingsMap }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error || "Failed to save settings");
      } else {
        setMessage(data.message || "System configuration saved successfully!");
      }
    } catch {
      setError("Network error saving settings");
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Admin Title Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
            <ShieldAlert className="w-4 h-4" />
            <span>Enterprise Treasury & System Command</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white">
            Administration Control Panel
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Manage deposit approvals, withdrawal requests, investment plans, encrypted wallet addresses, and system configuration.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={fetchAdminData}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/10 text-slate-300 transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          </button>
          <Link
            href="/dashboard"
            className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/10 text-white font-bold text-xs transition-colors"
          >
            ← Return to Client Vault
          </Link>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-bold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {message && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar border-b border-white/5 pb-2">
        {[
          { key: "overview", label: "AUM & Revenue Overview", icon: BarChart3 },
          {
            key: "deposits",
            label: `Deposit Requests (${deposits.filter((d) => d.status === "pending").length})`,
            icon: ArrowDownLeft,
          },
          {
            key: "withdrawals",
            label: `Withdrawal Requests (${withdrawals.filter((w) => w.status === "pending").length})`,
            icon: ArrowUpRight,
          },
          { key: "users", label: `Platform Users (${usersList.length})`, icon: Users },
          { key: "plans", label: "Yield Plans", icon: TrendingUp },
          { key: "settings", label: "Wallet & Telegram Editor", icon: Settings },
        ].map((t) => {
          const Icon = t.icon;
          const isActive = activeTab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                isActive
                  ? "bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/20"
                  : "bg-slate-900/60 hover:bg-slate-900 text-slate-300 border border-white/5"
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === "overview" && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6">
              <div className="text-xs font-bold text-slate-400 uppercase">
                Total Platform AUM
              </div>
              <div className="text-3xl font-black text-white mt-1">
                ${stats?.totalAumUsd || "0.00"}
              </div>
              <div className="text-[11px] text-emerald-400 font-bold mt-1">
                ● Across 7 block networks
              </div>
            </div>

            <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6">
              <div className="text-xs font-bold text-slate-400 uppercase">
                Total Confirmed Deposits
              </div>
              <div className="text-3xl font-black text-emerald-400 mt-1">
                ${stats?.totalDepositedUsd || "0.00"}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                {deposits.length} total deposit records
              </div>
            </div>

            <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6">
              <div className="text-xs font-bold text-slate-400 uppercase">
                Total Completed Withdrawals
              </div>
              <div className="text-3xl font-black text-white mt-1">
                ${stats?.totalWithdrawnUsd || "0.00"}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                {withdrawals.length} total withdrawal records
              </div>
            </div>

            <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6">
              <div className="text-xs font-bold text-slate-400 uppercase">
                Registered Enterprise Users
              </div>
              <div className="text-3xl font-black text-amber-400 mt-1">
                {stats?.totalUsers || usersList.length} Users
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                {stats?.activeInvestmentsCount || 0} active yield vaults
              </div>
            </div>
          </div>

          {/* Recent Audit logs */}
          <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 space-y-4">
            <h3 className="text-lg font-bold text-white">Enterprise Security Audit Logs</h3>
            <div className="space-y-2.5 max-h-80 overflow-y-auto no-scrollbar">
              {(stats?.recentAuditLogs || []).map((log: any) => (
                <div
                  key={log.id}
                  className="p-3.5 rounded-2xl bg-slate-950 border border-white/5 flex items-center justify-between text-xs"
                >
                  <div>
                    <span className="font-bold text-amber-400">{log.action}</span>
                    <span className="text-slate-400 ml-2">{log.details}</span>
                  </div>
                  <div className="text-right text-[10px] text-slate-500">
                    <div>{new Date(log.createdAt).toLocaleString()}</div>
                    <div>IP: {log.ipAddress}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: DEPOSIT APPROVALS */}
      {activeTab === "deposits" && (
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 space-y-6">
          <h2 className="text-xl font-bold text-white">Deposit Verification Desk</h2>
          <div className="space-y-3">
            {deposits.map((d) => (
              <div
                key={d.id}
                className="p-4 rounded-2xl bg-slate-950 border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs"
              >
                <div className="space-y-1">
                  <div className="font-bold text-white flex items-center gap-2">
                    <span className="text-sm text-emerald-400">+{d.amount} {d.currency}</span>
                    <span className="px-2 py-0.5 rounded bg-white/10 text-[10px] text-amber-300">
                      {d.network}
                    </span>
                    <span className="text-slate-400">User: {d.userEmail || `#${d.userId}`}</span>
                  </div>
                  <div className="font-mono text-[11px] text-slate-400 break-all">
                    TXID: {d.txid}
                  </div>
                  <div className="text-[10px] text-slate-500">
                    Submitted: {new Date(d.createdAt).toLocaleString()}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {d.status === "pending" ? (
                    <>
                      <button
                        onClick={() => handleDepositReview(d.id, "confirm")}
                        className="px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 transition-colors"
                      >
                        ✓ Confirm & Credit
                      </button>
                      <button
                        onClick={() => handleDepositReview(d.id, "reject")}
                        className="px-4 py-2 rounded-xl bg-rose-500/20 text-rose-300 font-bold text-xs hover:bg-rose-500/30 transition-colors"
                      >
                        ✗ Reject
                      </button>
                    </>
                  ) : (
                    <span
                      className={`px-3 py-1 rounded-full font-bold uppercase text-[10px] ${
                        d.status === "confirmed"
                          ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                          : "bg-rose-500/10 text-rose-400 border border-rose-500/30"
                      }`}
                    >
                      {d.status}
                    </span>
                  )}
                </div>
              </div>
            ))}
            {deposits.length === 0 && (
              <div className="text-center py-8 text-xs text-slate-500">
                No deposit requests submitted yet
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: WITHDRAWAL APPROVALS */}
      {activeTab === "withdrawals" && (
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 space-y-6">
          <h2 className="text-xl font-bold text-white">Withdrawal Approval Desk</h2>
          <div className="space-y-3">
            {withdrawals.map((w) => (
              <div
                key={w.id}
                className="p-4 rounded-2xl bg-slate-950 border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs"
              >
                <div className="space-y-1">
                  <div className="font-bold text-white flex items-center gap-2">
                    <span className="text-sm text-amber-400">-{w.amount} {w.currency}</span>
                    <span className="px-2 py-0.5 rounded bg-white/10 text-[10px] text-amber-300">
                      {w.network}
                    </span>
                    <span className="text-slate-400">User: {w.userEmail || `#${w.userId}`}</span>
                  </div>
                  <div className="font-mono text-[11px] text-slate-400 break-all">
                    Destination Address: {w.address}
                  </div>
                  <div className="text-[10px] text-slate-500">
                    Requested: {new Date(w.createdAt).toLocaleString()}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {w.status === "pending" ? (
                    <>
                      <button
                        onClick={() => handleWithdrawalReview(w.id, "approve")}
                        className="px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 transition-colors"
                      >
                        ✓ Approve & Broadcast
                      </button>
                      <button
                        onClick={() => handleWithdrawalReview(w.id, "reject")}
                        className="px-4 py-2 rounded-xl bg-rose-500/20 text-rose-300 font-bold text-xs hover:bg-rose-500/30 transition-colors"
                      >
                        ✗ Reject & Refund
                      </button>
                    </>
                  ) : (
                    <span
                      className={`px-3 py-1 rounded-full font-bold uppercase text-[10px] ${
                        w.status === "completed"
                          ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                          : "bg-rose-500/10 text-rose-400 border border-rose-500/30"
                      }`}
                    >
                      {w.status}
                    </span>
                  )}
                </div>
              </div>
            ))}
            {withdrawals.length === 0 && (
              <div className="text-center py-8 text-xs text-slate-500">
                No withdrawal requests submitted yet
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: USERS LIST */}
      {activeTab === "users" && (
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 space-y-6">
          <h2 className="text-xl font-bold text-white">Registered Platform Accounts</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase">
                <tr>
                  <th className="px-4 py-3">ID / Name</th>
                  <th className="px-4 py-3">Email Address</th>
                  <th className="px-4 py-3">Role</th>
                  <th className="px-4 py-3">KYC Status</th>
                  <th className="px-4 py-3">Total Vault USD</th>
                  <th className="px-4 py-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {usersList.map((u) => (
                  <tr key={u.id} className="hover:bg-white/5">
                    <td className="px-4 py-3 font-bold text-white">
                      #{u.id} • {u.fullName}
                    </td>
                    <td className="px-4 py-3 text-slate-300">{u.email}</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded bg-white/10 text-[10px] font-bold text-amber-300 uppercase">
                        {u.role}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-emerald-400 font-bold">{u.kycStatus}</span>
                    </td>
                    <td className="px-4 py-3 font-bold text-white">
                      ${u.totalUsdVal || "0.00"}
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-emerald-400 font-bold">{u.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: PLANS LIST */}
      {activeTab === "plans" && (
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white">Algorithmic Investment Plans</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {plansList.map((p) => (
              <div
                key={p.id}
                className="p-6 rounded-3xl bg-slate-950 border border-white/10 space-y-3"
              >
                <div className="flex justify-between items-center">
                  <h3 className="font-extrabold text-white">{p.name}</h3>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                    Active
                  </span>
                </div>
                <div className="text-xs text-slate-400">{p.description}</div>
                <div className="text-xl font-black text-amber-400">
                  +{p.expectedReturnPct}% APY ({p.durationDays} days)
                </div>
                <div className="text-xs text-slate-400">
                  Min: ${p.minInvestment} • Max: ${p.maxInvestment}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 6: SETTINGS (WALLETS, TELEGRAM, SUPPORT EDITOR) */}
      {activeTab === "settings" && (
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6">
          <div>
            <h2 className="text-xl font-bold text-white">
              Encrypted System Settings & Deposit Wallets
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Update wallet addresses without touching application code. All changes propagate instantaneously across the client UI.
            </p>
          </div>

          <form onSubmit={handleSaveSettings} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { key: "wallet_BTC", label: "Bitcoin (BTC) Deposit Wallet Address" },
                { key: "wallet_ETH", label: "Ethereum (ETH ERC-20) Deposit Wallet Address" },
                { key: "wallet_USDT", label: "Tether (USDT ERC-20) Deposit Wallet Address" },
                { key: "wallet_SOL", label: "Solana (SOL) Deposit Wallet Address" },
                { key: "wallet_BNB", label: "Binance Coin (BNB BEP-20) Deposit Wallet Address" },
                { key: "wallet_XRP", label: "Ripple (XRP Ledger) Deposit Wallet Address" },
                { key: "wallet_LTC", label: "Litecoin (LTC) Deposit Wallet Address" },
              ].map((s) => (
                <div key={s.key}>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    {s.label}
                  </label>
                  <input
                    type="text"
                    value={settingsMap[s.key] || ""}
                    onChange={(e) =>
                      setSettingsMap((prev) => ({
                        ...prev,
                        [s.key]: e.target.value,
                      }))
                    }
                    className="w-full bg-slate-950 text-amber-300 font-mono text-xs rounded-xl px-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400"
                  />
                </div>
              ))}
            </div>

            <div className="pt-6 border-t border-white/10 space-y-4">
              <h3 className="text-sm font-bold text-white">
                Telegram Bot & Customer Support Desk Configuration
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Telegram Bot API Token
                  </label>
                  <input
                    type="text"
                    value={settingsMap["telegram_bot_token"] || ""}
                    onChange={(e) =>
                      setSettingsMap((prev) => ({
                        ...prev,
                        telegram_bot_token: e.target.value,
                      }))
                    }
                    className="w-full bg-slate-950 text-white text-xs rounded-xl px-4 py-3 border border-white/10 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Telegram Channel/Group Chat ID
                  </label>
                  <input
                    type="text"
                    value={settingsMap["telegram_chat_id"] || ""}
                    onChange={(e) =>
                      setSettingsMap((prev) => ({
                        ...prev,
                        telegram_chat_id: e.target.value,
                      }))
                    }
                    className="w-full bg-slate-950 text-white text-xs rounded-xl px-4 py-3 border border-white/10 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Customer Support Email Address
                  </label>
                  <input
                    type="email"
                    value={settingsMap["support_email"] || ""}
                    onChange={(e) =>
                      setSettingsMap((prev) => ({
                        ...prev,
                        support_email: e.target.value,
                      }))
                    }
                    className="w-full bg-slate-950 text-white text-xs rounded-xl px-4 py-3 border border-white/10 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Customer Support Dedicated Helpline
                  </label>
                  <input
                    type="text"
                    value={settingsMap["support_phone"] || ""}
                    onChange={(e) =>
                      setSettingsMap((prev) => ({
                        ...prev,
                        support_phone: e.target.value,
                      }))
                    }
                    className="w-full bg-slate-950 text-white text-xs rounded-xl px-4 py-3 border border-white/10 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="px-8 py-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-xs shadow-lg hover:scale-105 transition-all"
            >
              Save System Configuration
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
