import { NextResponse } from "next/server";
import { db } from "@/db";
import { cryptoAcademyLessons } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { ensureSeeded } from "@/db/ensure-seeded";
import { getCurrentUser } from "@/lib/auth";

export async function GET() {
  try {
    await ensureSeeded();
    const lessons = await db
      .select()
      .from(cryptoAcademyLessons)
      .orderBy(desc(cryptoAcademyLessons.createdAt));

    return NextResponse.json({
      success: true,
      lessons,
    });
  } catch (error) {
    console.error("Error fetching academy lessons:", error);
    return NextResponse.json(
      { error: "Failed to load Crypto Academy curriculum" },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user || (user.role !== "admin" && user.role !== "superadmin")) {
      return NextResponse.json(
        { error: "Unauthorized: Admin privileges required to add lessons" },
        { status: 403 }
      );
    }

    const body = await req.json();
    const {
      title,
      category,
      readTimeMinutes,
      level,
      summary,
      content,
      videoUrl,
      quizQuestions,
    } = body;

    if (!title || !category || !content || !level) {
      return NextResponse.json(
        { error: "Title, category, level, and content are required" },
        { status: 400 }
      );
    }

    const [newLesson] = await db
      .insert(cryptoAcademyLessons)
      .values({
        title: title.trim(),
        category: category.trim(),
        readTimeMinutes: parseInt(readTimeMinutes || "5", 10),
        level: level.trim(),
        summary: summary || "",
        content: content.trim(),
        videoUrl: videoUrl || "",
        quizQuestions: quizQuestions || [],
      })
      .returning();

    return NextResponse.json({
      success: true,
      lesson: newLesson,
      message: "Academy lesson published successfully!",
    });
  } catch (error) {
    console.error("Error publishing lesson:", error);
    return NextResponse.json(
      { error: "Failed to publish Crypto Academy lesson" },
      { status: 500 }
    );
  }
}
