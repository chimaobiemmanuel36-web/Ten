import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  users,
  wallets,
  deposits,
  withdrawals,
  activeInvestments,
  auditLogs,
} from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeeded } from "@/db/ensure-seeded";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET() {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user || (user.role !== "admin" && user.role !== "superadmin")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    const allUsers = await db.select().from(users);
    const allWallets = await db.select().from(wallets);
    const allDeposits = await db.select().from(deposits);
    const allWithdrawals = await db.select().from(withdrawals);
    const allInvestments = await db.select().from(activeInvestments);
    const recentAuditLogs = await db
      .select()
      .from(auditLogs)
      .orderBy(desc(auditLogs.createdAt))
      .limit(15);

    // Calculate total AUM in USD
    let totalAumUsd = 0;
    for (const w of allWallets) {
      const bal = parseFloat(w.balance) || 0;
      const rate =
        w.currency === "BTC"
          ? 94820
          : w.currency === "ETH"
          ? 3410
          : w.currency === "SOL"
          ? 194
          : w.currency === "BNB"
          ? 642
          : w.currency === "XRP"
          ? 2.38
          : w.currency === "LTC"
          ? 118
          : 1.0;
      totalAumUsd += bal * rate;
    }

    let totalDepositedUsd = 0;
    for (const d of allDeposits) {
      if (d.status === "confirmed") {
        const amt = parseFloat(d.amount) || 0;
        const rate =
          d.currency === "BTC"
            ? 94820
            : d.currency === "ETH"
            ? 3410
            : d.currency === "SOL"
            ? 194
            : d.currency === "BNB"
            ? 642
            : d.currency === "XRP"
            ? 2.38
            : d.currency === "LTC"
            ? 118
            : 1.0;
        totalDepositedUsd += amt * rate;
      }
    }

    let totalWithdrawnUsd = 0;
    for (const w of allWithdrawals) {
      if (w.status === "completed") {
        const amt = parseFloat(w.amount) || 0;
        const rate =
          w.currency === "BTC"
            ? 94820
            : w.currency === "ETH"
            ? 3410
            : w.currency === "SOL"
            ? 194
            : w.currency === "BNB"
            ? 642
            : w.currency === "XRP"
            ? 2.38
            : w.currency === "LTC"
            ? 118
            : 1.0;
        totalWithdrawnUsd += amt * rate;
      }
    }

    const pendingDepositsCount = allDeposits.filter((d) => d.status === "pending").length;
    const pendingWithdrawalsCount = allWithdrawals.filter((w) => w.status === "pending").length;

    // Daily volume simulated/chart series
    const chartSeries = [
      { day: "Mon", deposits: 145000, withdrawals: 42000, newUsers: 14 },
      { day: "Tue", deposits: 210000, withdrawals: 65000, newUsers: 22 },
      { day: "Wed", deposits: 180000, withdrawals: 51000, newUsers: 19 },
      { day: "Thu", deposits: 290000, withdrawals: 88000, newUsers: 31 },
      { day: "Fri", deposits: 340000, withdrawals: 92000, newUsers: 38 },
      { day: "Sat", deposits: 195000, withdrawals: 38000, newUsers: 17 },
      { day: "Sun", deposits: 420000, withdrawals: 74000, newUsers: 45 },
    ];

    return NextResponse.json({
      success: true,
      stats: {
        totalUsers: allUsers.length,
        totalAumUsd: totalAumUsd.toFixed(2),
        totalDepositedUsd: totalDepositedUsd.toFixed(2),
        totalWithdrawnUsd: totalWithdrawnUsd.toFixed(2),
        activeInvestmentsCount: allInvestments.filter((i) => i.status === "active").length,
        pendingDepositsCount,
        pendingWithdrawalsCount,
        chartSeries,
        recentAuditLogs,
      },
    });
  } catch (error) {
    console.error("Error fetching admin stats:", error);
    return NextResponse.json(
      { error: "Failed to load administration analytics" },
      { status: 500 }
    );
  }
}
