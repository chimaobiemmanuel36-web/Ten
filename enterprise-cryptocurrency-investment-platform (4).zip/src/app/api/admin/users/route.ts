import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, wallets } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeeded } from "@/db/ensure-seeded";
import { logAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET() {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user || (user.role !== "admin" && user.role !== "superadmin")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    const allUsers = await db
      .select({
        id: users.id,
        email: users.email,
        fullName: users.fullName,
        role: users.role,
        kycStatus: users.kycStatus,
        kycDocumentUrl: users.kycDocumentUrl,
        status: users.status,
        loginCount: users.loginCount,
        lastLoginAt: users.lastLoginAt,
        createdAt: users.createdAt,
      })
      .from(users)
      .orderBy(desc(users.createdAt));

    const allWallets = await db.select().from(wallets);

    const usersWithBalances = allUsers.map((u) => {
      const uWallets = allWallets.filter((w) => w.userId === u.id);
      let totalUsdVal = 0;
      for (const w of uWallets) {
        const bal = parseFloat(w.balance) || 0;
        const rate =
          w.currency === "BTC"
            ? 94820
            : w.currency === "ETH"
            ? 3410
            : w.currency === "SOL"
            ? 194
            : w.currency === "BNB"
            ? 642
            : w.currency === "XRP"
            ? 2.38
            : w.currency === "LTC"
            ? 118
            : 1.0;
        totalUsdVal += bal * rate;
      }
      return {
        ...u,
        totalUsdVal: totalUsdVal.toFixed(2),
        walletCount: uWallets.length,
      };
    });

    return NextResponse.json({
      success: true,
      users: usersWithBalances,
    });
  } catch (error) {
    console.error("Error fetching users:", error);
    return NextResponse.json(
      { error: "Failed to fetch platform users" },
      { status: 500 }
    );
  }
}

export async function PUT(req: Request) {
  try {
    await ensureSeeded();
    const admin = await getCurrentUser();

    if (!admin || (admin.role !== "admin" && admin.role !== "superadmin")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    const body = await req.json();
    const { userId, status, kycStatus, role } = body;

    if (!userId) {
      return NextResponse.json({ error: "userId is required" }, { status: 400 });
    }

    const updateData: Record<string, any> = {};
    if (status) updateData.status = status;
    if (kycStatus) updateData.kycStatus = kycStatus;
    if (role && admin.role === "superadmin") updateData.role = role;

    const [updated] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, parseInt(userId, 10)))
      .returning();

    await logAudit({
      userId: admin.id,
      action: "ADMIN_UPDATE_USER",
      details: `Updated user #${userId}: ${JSON.stringify(updateData)}`,
    });

    return NextResponse.json({
      success: true,
      user: updated,
      message: "User account updated successfully",
    });
  } catch (error) {
    console.error("Error updating user:", error);
    return NextResponse.json(
      { error: "Failed to update user account" },
      { status: 500 }
    );
  }
}
