import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  verifyPassword,
  createAuthToken,
  setAuthCookie,
} from "@/lib/auth";
import { ensureSeeded } from "@/db/ensure-seeded";
import { logAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function POST(req: Request) {
  try {
    await ensureSeeded();

    const body = await req.json();
    const { email, password, rememberMe = true, captchaToken } = body;

    if (!email || !password) {
      return NextResponse.json(
        { error: "Email and password are required" },
        { status: 400 }
      );
    }

    // CAPTCHA simple check simulation if provided
    if (captchaToken && captchaToken === "failed") {
      return NextResponse.json(
        { error: "CAPTCHA verification failed" },
        { status: 400 }
      );
    }

    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.email, email.toLowerCase().trim()))
      .limit(1);

    if (!user) {
      await logAudit({
        action: "LOGIN_FAILED_UNKNOWN_EMAIL",
        details: `Attempted login for ${email}`,
      });
      return NextResponse.json(
        { error: "Invalid email or password" },
        { status: 401 }
      );
    }

    if (user.status !== "active") {
      return NextResponse.json(
        { error: "Account suspended. Contact compliance support." },
        { status: 403 }
      );
    }

    const isPasswordValid = await verifyPassword(password, user.passwordHash);

    if (!isPasswordValid) {
      await logAudit({
        userId: user.id,
        action: "LOGIN_FAILED_INVALID_PASSWORD",
        details: `Failed password login attempt for ${user.email}`,
      });
      return NextResponse.json(
        { error: "Invalid email or password" },
        { status: 401 }
      );
    }

    // Check if 2FA is enabled
    if (user.twoFactorEnabled) {
      // If client didn't supply OTP code yet, tell client to ask for OTP
      if (!body.otpCode) {
        return NextResponse.json({
          requires2FA: true,
          email: user.email,
          message: "Please enter your 2FA verification code",
        });
      }

      // Verify OTP code (in our platform simulation, any 6 digit code or '123456' works for seamless testing, or check against secret)
      if (body.otpCode !== "123456" && body.otpCode.length !== 6) {
        return NextResponse.json(
          { error: "Invalid 2FA authentication code. For demo, use 123456." },
          { status: 401 }
        );
      }
    }

    // Update login count and lastLoginAt
    await db
      .update(users)
      .set({
        loginCount: user.loginCount + 1,
        lastLoginAt: new Date(),
      })
      .where(eq(users.id, user.id));

    const token = createAuthToken(
      {
        userId: user.id,
        email: user.email,
        role: user.role,
      },
      rememberMe
    );

    await setAuthCookie(token, rememberMe);

    await logAudit({
      userId: user.id,
      action: "LOGIN_SUCCESS",
      details: `Successful login as ${user.role} (${user.email})`,
    });

    const { passwordHash, twoFactorSecret, ...sanitized } = user;

    return NextResponse.json({
      success: true,
      user: sanitized,
      token,
    });
  } catch (error) {
    console.error("Login error:", error);
    return NextResponse.json(
      { error: "Internal server error during authentication" },
      { status: 500 }
    );
  }
}
