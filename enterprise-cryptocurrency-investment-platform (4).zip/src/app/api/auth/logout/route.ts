import { NextResponse } from "next/server";
import { clearAuthCookie, getCurrentUser } from "@/lib/auth";
import { logAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function POST() {
  const user = await getCurrentUser();
  if (user) {
    await logAudit({
      userId: user.id,
      action: "LOGOUT",
      details: `User ${user.email} logged out securely`,
    });
  }

  await clearAuthCookie();
  return NextResponse.json({ success: true, message: "Logged out successfully" });
}
