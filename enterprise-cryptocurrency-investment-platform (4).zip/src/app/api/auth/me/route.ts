import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/db";
import { wallets, activeInvestments } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureSeeded } from "@/db/ensure-seeded";

export const dynamic = "force-dynamic";
export const revalidate = 0;

const noCacheHeaders = {
  "Cache-Control": "no-store, no-cache, must-revalidate, proxy-revalidate",
  "Pragma": "no-cache",
  "Expires": "0",
};

export async function GET() {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json(
        { authenticated: false, user: null },
        { status: 401, headers: noCacheHeaders }
      );
    }

    const userWallets = await db
      .select()
      .from(wallets)
      .where(eq(wallets.userId, user.id));

    const userInvestments = await db
      .select()
      .from(activeInvestments)
      .where(eq(activeInvestments.userId, user.id));

    return NextResponse.json(
      {
        authenticated: true,
        user,
        wallets: userWallets,
        activeInvestmentsCount: userInvestments.length,
      },
      { headers: noCacheHeaders }
    );
  } catch (error) {
    console.error("Error in /api/auth/me:", error);
    return NextResponse.json(
      { authenticated: false, error: "Failed to verify session" },
      { status: 500, headers: noCacheHeaders }
    );
  }
}
