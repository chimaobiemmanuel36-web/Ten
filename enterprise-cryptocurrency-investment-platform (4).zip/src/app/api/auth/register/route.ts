import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, wallets, systemSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  hashPassword,
  createAuthToken,
  setAuthCookie,
  calculatePasswordStrength,
} from "@/lib/auth";
import { ensureSeeded } from "@/db/ensure-seeded";
import { logAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function POST(req: Request) {
  try {
    await ensureSeeded();

    const body = await req.json();
    const { email, password, fullName, referralCode, agreeTerms } = body;

    if (!email || !password || !fullName) {
      return NextResponse.json(
        { error: "Full name, email, and password are required" },
        { status: 400 }
      );
    }

    if (!agreeTerms) {
      return NextResponse.json(
        { error: "You must agree to the institutional Terms & Conditions" },
        { status: 400 }
      );
    }

    const passwordStrength = calculatePasswordStrength(password);
    if (passwordStrength.score < 2) {
      return NextResponse.json(
        {
          error:
            "Password is too weak. Please use at least 8 characters with letters and numbers.",
        },
        { status: 400 }
      );
    }

    // Check existing
    const [existing] = await db
      .select()
      .from(users)
      .where(eq(users.email, email.toLowerCase().trim()))
      .limit(1);

    if (existing) {
      return NextResponse.json(
        { error: "An account with this email already exists" },
        { status: 409 }
      );
    }

    const passwordHash = await hashPassword(password);
    const newReferralCode =
      "APEX" + Math.random().toString(36).substring(2, 8).toUpperCase();

    const [newUser] = await db
      .insert(users)
      .values({
        email: email.toLowerCase().trim(),
        passwordHash,
        fullName: fullName.trim(),
        role: "user",
        emailVerified: true,
        twoFactorEnabled: false,
        referralCode: newReferralCode,
        referredBy: referralCode || null,
        kycStatus: "unverified",
        status: "active",
        loginCount: 1,
        lastLoginAt: new Date(),
      })
      .returning();

    // Fetch default deposit addresses from settings
    const settingsList = await db.select().from(systemSettings);
    const getAddress = (curr: string) => {
      const found = settingsList.find((s) => s.key === `wallet_${curr}`);
      return found?.value || "";
    };

    // Initialize multi-currency wallets for new user
    const defaultCurrencies = ["BTC", "ETH", "USDT", "SOL", "XRP", "BNB", "LTC"];
    for (const curr of defaultCurrencies) {
      await db.insert(wallets).values({
        userId: newUser.id,
        currency: curr,
        balance: curr === "USDT" ? "1000.00000000" : "0", // Welcome demo bonus
        lockedBalance: "0",
        totalDeposited: curr === "USDT" ? "1000.00000000" : "0",
        totalWithdrawn: "0",
        depositAddress: getAddress(curr),
      });
    }

    const token = createAuthToken({
      userId: newUser.id,
      email: newUser.email,
      role: newUser.role,
    });

    await setAuthCookie(token);

    await logAudit({
      userId: newUser.id,
      action: "REGISTER_NEW_USER",
      details: `New account registered: ${newUser.email}`,
    });

    const { passwordHash: _hash, twoFactorSecret, ...sanitized } = newUser;

    return NextResponse.json({
      success: true,
      user: sanitized,
      token,
      message:
        "Welcome to ApexCrypto Enterprise! A welcome bonus of 1,000 USDT has been credited to your demo vault.",
    });
  } catch (error) {
    console.error("Registration error:", error);
    return NextResponse.json(
      { error: "Internal server error during account creation" },
      { status: 500 }
    );
  }
}
