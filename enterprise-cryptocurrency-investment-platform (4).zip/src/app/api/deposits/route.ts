import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  deposits,
  wallets,
  transactions,
  users,
} from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeeded } from "@/db/ensure-seeded";
import { logAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const filterAll = searchParams.get("all") === "true";

    let depositRecords;
    if (filterAll && (user.role === "admin" || user.role === "superadmin")) {
      depositRecords = await db
        .select({
          id: deposits.id,
          userId: deposits.userId,
          userEmail: users.email,
          userFullName: users.fullName,
          currency: deposits.currency,
          amount: deposits.amount,
          txid: deposits.txid,
          proofUrl: deposits.proofUrl,
          network: deposits.network,
          status: deposits.status,
          confirmedAt: deposits.confirmedAt,
          createdAt: deposits.createdAt,
        })
        .from(deposits)
        .leftJoin(users, eq(deposits.userId, users.id))
        .orderBy(desc(deposits.createdAt));
    } else {
      depositRecords = await db
        .select()
        .from(deposits)
        .where(eq(deposits.userId, user.id))
        .orderBy(desc(deposits.createdAt));
    }

    return NextResponse.json({
      success: true,
      deposits: depositRecords,
    });
  } catch (error) {
    console.error("Error fetching deposits:", error);
    return NextResponse.json(
      { error: "Failed to load deposit history" },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { currency, amount, txid, network, proofUrl } = body;

    if (!currency || !amount || !txid || !network) {
      return NextResponse.json(
        { error: "Currency, amount, TXID, and network are required" },
        { status: 400 }
      );
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return NextResponse.json(
        { error: "Deposit amount must be greater than zero" },
        { status: 400 }
      );
    }

    // Check if txid already submitted
    const existingTxid = await db
      .select()
      .from(deposits)
      .where(eq(deposits.txid, txid.trim()))
      .limit(1);

    if (existingTxid.length > 0) {
      return NextResponse.json(
        { error: "This TXID has already been submitted for verification" },
        { status: 409 }
      );
    }

    const [newDeposit] = await db
      .insert(deposits)
      .values({
        userId: user.id,
        currency: currency.toUpperCase(),
        amount: String(numAmount),
        txid: txid.trim(),
        proofUrl: proofUrl || "https://apexcrypto.io/proofs/default-receipt.png",
        network: network.trim(),
        status: "pending",
      })
      .returning();

    await db.insert(transactions).values({
      userId: user.id,
      type: "deposit",
      currency: currency.toUpperCase(),
      amount: String(numAmount),
      description: `Submitted ${currency} deposit (${network}) - TXID: ${txid.slice(0, 10)}...`,
      status: "pending",
    });

    await logAudit({
      userId: user.id,
      action: "SUBMIT_DEPOSIT",
      details: `Submitted deposit of ${numAmount} ${currency} on ${network} (TXID: ${txid})`,
    });

    return NextResponse.json({
      success: true,
      deposit: newDeposit,
      message:
        "Deposit submitted successfully! Our automated blockchain verification scanner will credit your vault within 1-6 confirmations.",
    });
  } catch (error) {
    console.error("Error submitting deposit:", error);
    return NextResponse.json(
      { error: "Failed to submit deposit request" },
      { status: 500 }
    );
  }
}

export async function PUT(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user || (user.role !== "admin" && user.role !== "superadmin")) {
      return NextResponse.json(
        { error: "Unauthorized: Admin privileges required" },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { depositId, action } = body; // action: 'confirm' | 'reject'

    if (!depositId || (action !== "confirm" && action !== "reject")) {
      return NextResponse.json(
        { error: "Valid depositId and action ('confirm' or 'reject') are required" },
        { status: 400 }
      );
    }

    const [targetDeposit] = await db
      .select()
      .from(deposits)
      .where(eq(deposits.id, parseInt(depositId, 10)))
      .limit(1);

    if (!targetDeposit) {
      return NextResponse.json({ error: "Deposit not found" }, { status: 404 });
    }

    if (targetDeposit.status !== "pending") {
      return NextResponse.json(
        { error: `Deposit is already ${targetDeposit.status}` },
        { status: 400 }
      );
    }

    if (action === "confirm") {
      await db
        .update(deposits)
        .set({
          status: "confirmed",
          confirmedAt: new Date(),
        })
        .where(eq(deposits.id, targetDeposit.id));

      // Credit user's wallet
      const [userWallet] = await db
        .select()
        .from(wallets)
        .where(
          eq(wallets.userId, targetDeposit.userId)
        );

      const targetWallet = (await db
        .select()
        .from(wallets)
        .where(eq(wallets.userId, targetDeposit.userId)))
        .find((w) => w.currency === targetDeposit.currency);

      if (targetWallet) {
        const currentBalance = parseFloat(targetWallet.balance) || 0;
        const addAmount = parseFloat(targetDeposit.amount) || 0;
        const currentTotalDep = parseFloat(targetWallet.totalDeposited) || 0;

        await db
          .update(wallets)
          .set({
            balance: String((currentBalance + addAmount).toFixed(8)),
            totalDeposited: String((currentTotalDep + addAmount).toFixed(8)),
          })
          .where(eq(wallets.id, targetWallet.id));
      }

      await db.insert(transactions).values({
        userId: targetDeposit.userId,
        type: "deposit",
        currency: targetDeposit.currency,
        amount: targetDeposit.amount,
        description: `Confirmed ${targetDeposit.currency} Deposit - Approved by Treasury`,
        status: "completed",
      });

      await logAudit({
        userId: user.id,
        action: "ADMIN_CONFIRM_DEPOSIT",
        details: `Confirmed deposit #${targetDeposit.id} (${targetDeposit.amount} ${targetDeposit.currency}) for user #${targetDeposit.userId}`,
      });

      return NextResponse.json({
        success: true,
        message: `Deposit #${targetDeposit.id} confirmed and ${targetDeposit.amount} ${targetDeposit.currency} credited to wallet.`,
      });
    } else {
      // reject
      await db
        .update(deposits)
        .set({
          status: "rejected",
        })
        .where(eq(deposits.id, targetDeposit.id));

      await db.insert(transactions).values({
        userId: targetDeposit.userId,
        type: "deposit",
        currency: targetDeposit.currency,
        amount: targetDeposit.amount,
        description: `Rejected ${targetDeposit.currency} Deposit Request`,
        status: "rejected",
      });

      await logAudit({
        userId: user.id,
        action: "ADMIN_REJECT_DEPOSIT",
        details: `Rejected deposit #${targetDeposit.id} for user #${targetDeposit.userId}`,
      });

      return NextResponse.json({
        success: true,
        message: `Deposit #${targetDeposit.id} has been rejected.`,
      });
    }
  } catch (error) {
    console.error("Error processing deposit approval:", error);
    return NextResponse.json(
      { error: "Failed to process deposit review" },
      { status: 500 }
    );
  }
}
