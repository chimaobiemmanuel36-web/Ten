import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  activeInvestments,
  investmentPlans,
  wallets,
  transactions,
  users,
} from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeeded } from "@/db/ensure-seeded";
import { logAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const filterAll = searchParams.get("all") === "true";

    let items;
    if (filterAll && (user.role === "admin" || user.role === "superadmin")) {
      items = await db
        .select({
          id: activeInvestments.id,
          userId: activeInvestments.userId,
          userEmail: users.email,
          userFullName: users.fullName,
          planId: activeInvestments.planId,
          planName: investmentPlans.name,
          currency: activeInvestments.currency,
          amount: activeInvestments.amount,
          expectedProfit: activeInvestments.expectedProfit,
          accruedProfit: activeInvestments.accruedProfit,
          status: activeInvestments.status,
          startDate: activeInvestments.startDate,
          endDate: activeInvestments.endDate,
          lastAccruedAt: activeInvestments.lastAccruedAt,
          earlyWithdrawalAllowed: investmentPlans.earlyWithdrawalAllowed,
        })
        .from(activeInvestments)
        .leftJoin(users, eq(activeInvestments.userId, users.id))
        .leftJoin(investmentPlans, eq(activeInvestments.planId, investmentPlans.id))
        .orderBy(desc(activeInvestments.createdAt));
    } else {
      items = await db
        .select({
          id: activeInvestments.id,
          userId: activeInvestments.userId,
          planId: activeInvestments.planId,
          planName: investmentPlans.name,
          currency: activeInvestments.currency,
          amount: activeInvestments.amount,
          expectedProfit: activeInvestments.expectedProfit,
          accruedProfit: activeInvestments.accruedProfit,
          status: activeInvestments.status,
          startDate: activeInvestments.startDate,
          endDate: activeInvestments.endDate,
          lastAccruedAt: activeInvestments.lastAccruedAt,
          earlyWithdrawalAllowed: investmentPlans.earlyWithdrawalAllowed,
        })
        .from(activeInvestments)
        .leftJoin(investmentPlans, eq(activeInvestments.planId, investmentPlans.id))
        .where(eq(activeInvestments.userId, user.id))
        .orderBy(desc(activeInvestments.createdAt));
    }

    // Simulate real-time accrued profit boost for display excitement
    const now = Date.now();
    const enhanced = items.map((inv) => {
      const startMs = new Date(inv.startDate).getTime();
      const endMs = new Date(inv.endDate).getTime();
      const totalDuration = Math.max(1, endMs - startMs);
      const elapsed = Math.min(now - startMs, totalDuration);
      const progressRatio = Math.max(0, Math.min(1, elapsed / totalDuration));

      const expProfit = parseFloat(inv.expectedProfit) || 0;
      const dynamicAccrued = (expProfit * progressRatio).toFixed(8);

      return {
        ...inv,
        accruedProfit: dynamicAccrued,
        progressPct: Math.round(progressRatio * 100),
      };
    });

    return NextResponse.json({
      success: true,
      investments: enhanced,
    });
  } catch (error) {
    console.error("Error fetching investments:", error);
    return NextResponse.json(
      { error: "Failed to load active investments" },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { planId, currency, amount } = body;

    if (!planId || !currency || !amount) {
      return NextResponse.json(
        { error: "planId, currency, and amount are required" },
        { status: 400 }
      );
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return NextResponse.json(
        { error: "Investment amount must be positive" },
        { status: 400 }
      );
    }

    const [plan] = await db
      .select()
      .from(investmentPlans)
      .where(eq(investmentPlans.id, parseInt(planId, 10)))
      .limit(1);

    if (!plan || !plan.active) {
      return NextResponse.json(
        { error: "Selected investment plan is no longer active" },
        { status: 404 }
      );
    }

    const minInv = parseFloat(plan.minInvestment);
    const maxInv = parseFloat(plan.maxInvestment);

    if (numAmount < minInv || numAmount > maxInv) {
      return NextResponse.json(
        {
          error: `Investment amount must be between ${minInv} and ${maxInv} ${currency}`,
        },
        { status: 400 }
      );
    }

    // Check user balance
    const userWallets = await db
      .select()
      .from(wallets)
      .where(eq(wallets.userId, user.id));

    const targetWallet = userWallets.find(
      (w) => w.currency === currency.toUpperCase()
    );

    if (!targetWallet) {
      return NextResponse.json(
        { error: `Wallet for ${currency} not found` },
        { status: 404 }
      );
    }

    const currentBalance = parseFloat(targetWallet.balance) || 0;
    if (currentBalance < numAmount) {
      return NextResponse.json(
        {
          error: `Insufficient available ${currency} balance. Current balance: ${currentBalance.toFixed(6)}`,
        },
        { status: 400 }
      );
    }

    // Deduct principal from wallet
    const newBal = currentBalance - numAmount;
    await db
      .update(wallets)
      .set({ balance: String(newBal.toFixed(8)) })
      .where(eq(wallets.id, targetWallet.id));

    const durationDays = plan.durationDays || 30;
    const expectedReturnPct = parseFloat(plan.expectedReturnPct) || 10;
    const totalExpectedProfit = numAmount * (expectedReturnPct / 100);

    const startDate = new Date();
    const endDate = new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000);

    const [newInvestment] = await db
      .insert(activeInvestments)
      .values({
        userId: user.id,
        planId: plan.id,
        currency: currency.toUpperCase(),
        amount: String(numAmount),
        expectedProfit: String(totalExpectedProfit.toFixed(8)),
        accruedProfit: "0",
        status: "active",
        startDate,
        endDate,
        lastAccruedAt: startDate,
      })
      .returning();

    await db.insert(transactions).values({
      userId: user.id,
      type: "investment",
      currency: currency.toUpperCase(),
      amount: String(numAmount),
      description: `Capital deployed to ${plan.name} strategy (${expectedReturnPct}% expected yield)`,
      status: "completed",
    });

    await logAudit({
      userId: user.id,
      action: "NEW_INVESTMENT_DEPLOYED",
      details: `Deployed ${numAmount} ${currency} into plan "${plan.name}"`,
    });

    return NextResponse.json({
      success: true,
      investment: newInvestment,
      message: `Capital successfully deployed! Your ${plan.name} yield strategy is now actively accruing daily returns.`,
    });
  } catch (error) {
    console.error("Error creating investment:", error);
    return NextResponse.json(
      { error: "Failed to deploy investment capital" },
      { status: 500 }
    );
  }
}

export async function PUT(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { investmentId, action } = body; // action: 'withdraw' | 'claim'

    if (!investmentId) {
      return NextResponse.json({ error: "investmentId is required" }, { status: 400 });
    }

    const [target] = await db
      .select()
      .from(activeInvestments)
      .where(eq(activeInvestments.id, parseInt(investmentId, 10)))
      .limit(1);

    if (!target) {
      return NextResponse.json({ error: "Investment not found" }, { status: 404 });
    }

    if (target.userId !== user.id && user.role !== "admin" && user.role !== "superadmin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    if (target.status !== "active") {
      return NextResponse.json(
        { error: `This investment is already ${target.status}` },
        { status: 400 }
      );
    }

    const [plan] = await db
      .select()
      .from(investmentPlans)
      .where(eq(investmentPlans.id, target.planId))
      .limit(1);

    const now = Date.now();
    const endMs = new Date(target.endDate).getTime();
    const isCompleted = now >= endMs;

    if (!isCompleted && plan && !plan.earlyWithdrawalAllowed) {
      return NextResponse.json(
        { error: "Early withdrawal is not permitted for this institutional plan during the principal lock period." },
        { status: 403 }
      );
    }

    // Calculate return amount
    const principal = parseFloat(target.amount) || 0;
    const expProfit = parseFloat(target.expectedProfit) || 0;

    let payoutAmount = principal + expProfit;
    let desc = `Completed strategy payout (${plan?.name || "Plan"}) - Principal + Profit`;

    if (!isCompleted) {
      // Early withdrawal: 2% penalty on principal, only 50% of accrued profit
      const penalty = principal * 0.02;
      const partialProfit = (expProfit * 0.3);
      payoutAmount = Math.max(0, principal - penalty + partialProfit);
      desc = `Early withdrawal payout (${plan?.name || "Plan"}) - Applied 2% early exit adjustment`;
    }

    await db
      .update(activeInvestments)
      .set({
        status: isCompleted ? "completed" : "withdrawn",
        accruedProfit: String((payoutAmount - principal).toFixed(8)),
      })
      .where(eq(activeInvestments.id, target.id));

    // Credit user's wallet
    const userWallets = await db
      .select()
      .from(wallets)
      .where(eq(wallets.userId, target.userId));

    const targetWallet = userWallets.find((w) => w.currency === target.currency);

    if (targetWallet) {
      const currentBal = parseFloat(targetWallet.balance) || 0;
      await db
        .update(wallets)
        .set({
          balance: String((currentBal + payoutAmount).toFixed(8)),
        })
        .where(eq(wallets.id, targetWallet.id));
    }

    await db.insert(transactions).values({
      userId: target.userId,
      type: "payout",
      currency: target.currency,
      amount: String(payoutAmount.toFixed(8)),
      description: desc,
      status: "completed",
    });

    await logAudit({
      userId: user.id,
      action: isCompleted ? "INVESTMENT_COMPLETED_PAYOUT" : "INVESTMENT_EARLY_WITHDRAWAL",
      details: `Paid out ${payoutAmount.toFixed(4)} ${target.currency} for investment #${target.id}`,
    });

    return NextResponse.json({
      success: true,
      message: `Successfully withdrew ${payoutAmount.toFixed(4)} ${target.currency} back to your wallet!`,
    });
  } catch (error) {
    console.error("Error processing investment withdrawal:", error);
    return NextResponse.json(
      { error: "Failed to process investment withdrawal" },
      { status: 500 }
    );
  }
}
