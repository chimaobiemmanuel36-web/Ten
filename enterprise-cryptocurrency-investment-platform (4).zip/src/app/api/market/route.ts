import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

interface CoinData {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  volume24h: number;
  marketCap: number;
  sparkline: number[];
  network: string;
  high24h: number;
  low24h: number;
}

const DEFAULT_MARKET_DATA: CoinData[] = [
  {
    id: "bitcoin",
    symbol: "BTC",
    name: "Bitcoin",
    price: 94820.5,
    change24h: 3.42,
    volume24h: 34210000000,
    marketCap: 1874000000000,
    high24h: 95400.0,
    low24h: 91200.0,
    network: "Bitcoin Native",
    sparkline: [91200, 91800, 92400, 93100, 92800, 93900, 94820.5],
  },
  {
    id: "ethereum",
    symbol: "ETH",
    name: "Ethereum",
    price: 3410.8,
    change24h: 4.85,
    volume24h: 18450000000,
    marketCap: 410000000000,
    high24h: 3450.0,
    low24h: 3240.0,
    network: "Ethereum ERC-20",
    sparkline: [3240, 3280, 3310, 3290, 3360, 3390, 3410.8],
  },
  {
    id: "solana",
    symbol: "SOL",
    name: "Solana",
    price: 194.2,
    change24h: 7.15,
    volume24h: 6200000000,
    marketCap: 91500000000,
    high24h: 198.5,
    low24h: 180.1,
    network: "Solana Native",
    sparkline: [180.1, 183.4, 186.2, 184.9, 189.5, 192.1, 194.2],
  },
  {
    id: "binancecoin",
    symbol: "BNB",
    name: "Binance Coin",
    price: 642.15,
    change24h: 1.82,
    volume24h: 1820000000,
    marketCap: 98400000000,
    high24h: 648.0,
    low24h: 630.5,
    network: "BNB BEP-20",
    sparkline: [630.5, 634.0, 636.5, 638.0, 640.2, 641.5, 642.15],
  },
  {
    id: "ripple",
    symbol: "XRP",
    name: "XRP",
    price: 2.38,
    change24h: 12.45,
    volume24h: 8900000000,
    marketCap: 135000000000,
    high24h: 2.45,
    low24h: 2.08,
    network: "XRP Ledger",
    sparkline: [2.08, 2.15, 2.21, 2.28, 2.31, 2.35, 2.38],
  },
  {
    id: "tether",
    symbol: "USDT",
    name: "Tether USD",
    price: 1.0,
    change24h: 0.02,
    volume24h: 65400000000,
    marketCap: 128500000000,
    high24h: 1.002,
    low24h: 0.999,
    network: "Ethereum ERC-20",
    sparkline: [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
  },
  {
    id: "litecoin",
    symbol: "LTC",
    name: "Litecoin",
    price: 118.4,
    change24h: -1.2,
    volume24h: 980000000,
    marketCap: 8850000000,
    high24h: 122.0,
    low24h: 116.8,
    network: "Litecoin Native",
    sparkline: [120.5, 119.8, 121.2, 119.0, 118.6, 118.9, 118.4],
  },
];

export async function GET() {
  try {
    // Attempt live CoinGecko API fetch with 3s timeout
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3000);

    const response = await fetch(
      "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=bitcoin,ethereum,solana,binancecoin,ripple,tether,litecoin&order=market_cap_desc&per_page=10&page=1&sparkline=true&price_change_percentage=24h",
      {
        headers: { Accept: "application/json" },
        signal: controller.signal,
        next: { revalidate: 30 },
      }
    ).catch(() => null);

    clearTimeout(timeout);

    let marketData = DEFAULT_MARKET_DATA;

    if (response && response.ok) {
      const liveData = await response.json();
      if (Array.isArray(liveData) && liveData.length > 0) {
        marketData = liveData.map((coin: any) => {
          const defaultCoin = DEFAULT_MARKET_DATA.find((d) => d.id === coin.id);
          return {
            id: coin.id,
            symbol: coin.symbol.toUpperCase(),
            name: coin.name,
            price: coin.current_price || defaultCoin?.price || 0,
            change24h: coin.price_change_percentage_24h || 0,
            volume24h: coin.total_volume || defaultCoin?.volume24h || 0,
            marketCap: coin.market_cap || defaultCoin?.marketCap || 0,
            high24h: coin.high_24h || coin.current_price * 1.03,
            low24h: coin.low_24h || coin.current_price * 0.97,
            network: defaultCoin?.network || "Native",
            sparkline:
              coin.sparkline_in_7d?.price?.slice(-7) || defaultCoin?.sparkline || [0],
          };
        });
      }
    }

    const fearGreed = {
      value: 78,
      label: "Extreme Greed",
      timestamp: Date.now(),
    };

    const topGainers = [...marketData]
      .sort((a, b) => b.change24h - a.change24h)
      .slice(0, 3);

    const topLosers = [...marketData]
      .sort((a, b) => a.change24h - b.change24h)
      .slice(0, 3);

    return NextResponse.json({
      success: true,
      coins: marketData,
      fearGreed,
      topGainers,
      topLosers,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Error in market API:", error);
    return NextResponse.json({
      success: true,
      coins: DEFAULT_MARKET_DATA,
      fearGreed: { value: 78, label: "Extreme Greed" },
      topGainers: DEFAULT_MARKET_DATA.slice(0, 3),
      topLosers: DEFAULT_MARKET_DATA.slice(-2),
      timestamp: new Date().toISOString(),
    });
  }
}
