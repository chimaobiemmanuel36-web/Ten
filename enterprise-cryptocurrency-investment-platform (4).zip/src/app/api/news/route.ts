import { NextResponse } from "next/server";
import { db } from "@/db";
import { newsArticles } from "@/db/schema";
import { desc } from "drizzle-orm";
import { ensureSeeded } from "@/db/ensure-seeded";

export async function GET() {
  try {
    await ensureSeeded();
    const articles = await db
      .select()
      .from(newsArticles)
      .orderBy(desc(newsArticles.publishedAt));

    return NextResponse.json({
      success: true,
      articles,
    });
  } catch (error) {
    console.error("Error fetching news:", error);
    return NextResponse.json(
      { error: "Failed to load crypto news" },
      { status: 500 }
    );
  }
}
