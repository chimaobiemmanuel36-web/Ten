import { NextResponse } from "next/server";
import { db } from "@/db";
import { investmentPlans } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeeded } from "@/db/ensure-seeded";
import { logAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET(req: Request) {
  try {
    await ensureSeeded();
    const { searchParams } = new URL(req.url);
    const includeInactive = searchParams.get("all") === "true";

    const user = await getCurrentUser();
    const isAdmin = user && (user.role === "admin" || user.role === "superadmin");

    let plansList;
    if (includeInactive && isAdmin) {
      plansList = await db
        .select()
        .from(investmentPlans)
        .orderBy(desc(investmentPlans.createdAt));
    } else {
      plansList = await db
        .select()
        .from(investmentPlans)
        .where(eq(investmentPlans.active, true))
        .orderBy(desc(investmentPlans.createdAt));
    }

    return NextResponse.json({
      success: true,
      plans: plansList,
    });
  } catch (error) {
    console.error("Error fetching plans:", error);
    return NextResponse.json(
      { error: "Failed to fetch investment plans" },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user || (user.role !== "admin" && user.role !== "superadmin")) {
      return NextResponse.json(
        { error: "Unauthorized: Only administrators can create investment plans" },
        { status: 403 }
      );
    }

    const body = await req.json();
    const {
      name,
      description,
      minInvestment,
      maxInvestment,
      durationDays,
      managementFeePct,
      expectedReturnPct,
      lockPeriodDays,
      compoundingAllowed,
      earlyWithdrawalAllowed,
      supportedCurrencies,
      termsText,
    } = body;

    if (!name || !minInvestment || !maxInvestment || !durationDays || !expectedReturnPct) {
      return NextResponse.json(
        { error: "Name, min/max investment, duration, and expected return are required" },
        { status: 400 }
      );
    }

    const [newPlan] = await db
      .insert(investmentPlans)
      .values({
        name: name.trim(),
        description: description || "",
        minInvestment: String(minInvestment),
        maxInvestment: String(maxInvestment),
        durationDays: parseInt(durationDays, 10),
        managementFeePct: String(managementFeePct || "1.00"),
        expectedReturnPct: String(expectedReturnPct),
        lockPeriodDays: parseInt(lockPeriodDays || durationDays, 10),
        compoundingAllowed: Boolean(compoundingAllowed ?? true),
        earlyWithdrawalAllowed: Boolean(earlyWithdrawalAllowed ?? true),
        supportedCurrencies: supportedCurrencies || ["USDT", "BTC", "ETH", "SOL"],
        termsText:
          termsText ||
          "Hypothetical yield projections are based on trailing algorithmic backtesting. Past performance does not guarantee future results.",
        active: true,
      })
      .returning();

    await logAudit({
      userId: user.id,
      action: "ADMIN_CREATE_PLAN",
      details: `Created new investment plan: "${newPlan.name}" (${newPlan.expectedReturnPct}% expected return)`,
    });

    return NextResponse.json({
      success: true,
      plan: newPlan,
      message: "Investment plan created and activated successfully!",
    });
  } catch (error) {
    console.error("Error creating plan:", error);
    return NextResponse.json(
      { error: "Failed to create investment plan" },
      { status: 500 }
    );
  }
}

export async function PUT(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user || (user.role !== "admin" && user.role !== "superadmin")) {
      return NextResponse.json(
        { error: "Unauthorized: Admin privileges required" },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { id, ...updates } = body;

    if (!id) {
      return NextResponse.json({ error: "Plan id is required" }, { status: 400 });
    }

    const [updated] = await db
      .update(investmentPlans)
      .set({
        ...updates,
      })
      .where(eq(investmentPlans.id, parseInt(id, 10)))
      .returning();

    await logAudit({
      userId: user.id,
      action: "ADMIN_UPDATE_PLAN",
      details: `Updated plan #${id} ("${updated?.name}")`,
    });

    return NextResponse.json({
      success: true,
      plan: updated,
      message: "Investment plan updated successfully",
    });
  } catch (error) {
    console.error("Error updating plan:", error);
    return NextResponse.json(
      { error: "Failed to update investment plan" },
      { status: 500 }
    );
  }
}
