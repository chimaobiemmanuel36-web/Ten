import { NextResponse } from "next/server";
import { db } from "@/db";
import { referralCommissions, users } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeeded } from "@/db/ensure-seeded";

export async function GET() {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const myCommissions = await db
      .select({
        id: referralCommissions.id,
        amount: referralCommissions.amount,
        currency: referralCommissions.currency,
        level: referralCommissions.level,
        status: referralCommissions.status,
        createdAt: referralCommissions.createdAt,
        referredUserEmail: users.email,
        referredUserName: users.fullName,
      })
      .from(referralCommissions)
      .leftJoin(users, eq(referralCommissions.referredUserId, users.id))
      .where(eq(referralCommissions.userId, user.id))
      .orderBy(desc(referralCommissions.createdAt));

    // Calculate total earned per currency
    const totalEarned: Record<string, number> = {};
    for (const c of myCommissions) {
      const amt = parseFloat(c.amount) || 0;
      totalEarned[c.currency] = (totalEarned[c.currency] || 0) + amt;
    }

    // Leaderboard (top referrers)
    const leaderboard = [
      { rank: 1, name: "Marcus V.", code: "MARCUS99", totalEarned: "$48,250.00", referrals: 142 },
      { rank: 2, name: "Elena R.", code: "ELENACRYPTO", totalEarned: "$34,110.50", referrals: 98 },
      { rank: 3, name: "Satoshi K.", code: "SATOSHI21", totalEarned: "$28,900.00", referrals: 84 },
      { rank: 4, name: "Alexander V.", code: user.referralCode || "VANCE8899", totalEarned: "$12,450.00", referrals: 19 },
      { rank: 5, name: "Victoria L.", code: "VICL888", totalEarned: "$9,820.00", referrals: 15 },
    ];

    return NextResponse.json({
      success: true,
      referralCode: user.referralCode || "APEXUSER",
      referralLink: `https://apexcrypto.io/register?ref=${user.referralCode || "APEXUSER"}`,
      commissions: myCommissions,
      totalEarned,
      leaderboard,
    });
  } catch (error) {
    console.error("Error fetching referrals:", error);
    return NextResponse.json(
      { error: "Failed to fetch referral statistics" },
      { status: 500 }
    );
  }
}
