import { NextResponse } from "next/server";
import { db } from "@/db";
import { systemSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeeded } from "@/db/ensure-seeded";
import { logAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET() {
  try {
    await ensureSeeded();
    const settingsList = await db.select().from(systemSettings);

    const settingsMap: Record<string, string> = {};
    for (const s of settingsList) {
      settingsMap[s.key] = s.value;
    }

    return NextResponse.json({
      success: true,
      settings: settingsMap,
    });
  } catch (error) {
    console.error("Error fetching settings:", error);
    return NextResponse.json(
      { error: "Failed to fetch system settings" },
      { status: 500 }
    );
  }
}

export async function PUT(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user || (user.role !== "admin" && user.role !== "superadmin")) {
      return NextResponse.json(
        { error: "Unauthorized: Admin access required to update system settings" },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { updates } = body; // e.g. { wallet_BTC: "bc1...", telegram_bot_token: "..." }

    if (!updates || typeof updates !== "object") {
      return NextResponse.json(
        { error: "Invalid settings updates payload" },
        { status: 400 }
      );
    }

    for (const [key, value] of Object.entries(updates)) {
      if (typeof value === "string") {
        await db
          .insert(systemSettings)
          .values({
            key,
            value,
            description: `Admin updated setting ${key}`,
            updatedAt: new Date(),
          })
          .onConflictDoUpdate({
            target: systemSettings.key,
            set: {
              value,
              updatedAt: new Date(),
            },
          });
      }
    }

    await logAudit({
      userId: user.id,
      action: "ADMIN_UPDATE_SETTINGS",
      details: `Updated keys: ${Object.keys(updates).join(", ")}`,
    });

    // return new settings map
    const newSettingsList = await db.select().from(systemSettings);
    const settingsMap: Record<string, string> = {};
    for (const s of newSettingsList) {
      settingsMap[s.key] = s.value;
    }

    return NextResponse.json({
      success: true,
      message: "System configuration and wallet addresses updated successfully",
      settings: settingsMap,
    });
  } catch (error) {
    console.error("Error updating settings:", error);
    return NextResponse.json(
      { error: "Failed to update system settings" },
      { status: 500 }
    );
  }
}
