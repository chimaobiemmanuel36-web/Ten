import { NextResponse } from "next/server";
import { db } from "@/db";
import { supportTickets, ticketMessages, users } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeeded } from "@/db/ensure-seeded";

export async function GET(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const filterAll = searchParams.get("all") === "true";

    let tickets;
    if (filterAll && (user.role === "admin" || user.role === "superadmin")) {
      tickets = await db
        .select({
          id: supportTickets.id,
          userId: supportTickets.userId,
          userEmail: users.email,
          userFullName: users.fullName,
          subject: supportTickets.subject,
          category: supportTickets.category,
          status: supportTickets.status,
          priority: supportTickets.priority,
          createdAt: supportTickets.createdAt,
          updatedAt: supportTickets.updatedAt,
        })
        .from(supportTickets)
        .leftJoin(users, eq(supportTickets.userId, users.id))
        .orderBy(desc(supportTickets.updatedAt));
    } else {
      tickets = await db
        .select()
        .from(supportTickets)
        .where(eq(supportTickets.userId, user.id))
        .orderBy(desc(supportTickets.updatedAt));
    }

    return NextResponse.json({
      success: true,
      tickets,
    });
  } catch (error) {
    console.error("Error fetching tickets:", error);
    return NextResponse.json(
      { error: "Failed to load support tickets" },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    const body = await req.json();
    const { mode, query, subject, category, priority, message } = body;

    // AI Concierge Mode (can be used by guests or logged-in users)
    if (mode === "ai-assistant") {
      const q = (query || "").toLowerCase();
      let answer =
        "Hello! I am the Apex AI Concierge. I can assist you with multi-currency deposits, institutional investment yield strategies, MPC threshold security, or withdrawal policies. How may I help you today?";

      if (q.includes("deposit") || q.includes("fund") || q.includes("qr") || q.includes("address")) {
        answer =
          "To make a deposit, go to Dashboard → Deposit. Select your desired cryptocurrency (BTC, ETH, USDT, SOL, BNB, XRP, or LTC) to view our verified deposit address and QR code. All addresses are secured by enterprise MPC vaults.";
      } else if (q.includes("withdraw") || q.includes("payout") || q.includes("cash")) {
        answer =
          "Withdrawal requests undergo automated AML compliance screening and are typically processed within 15-45 minutes. You can whitelist trusted destination addresses under Security settings.";
      } else if (q.includes("plan") || q.includes("yield") || q.includes("interest") || q.includes("return") || q.includes("invest")) {
        answer =
          "ApexCrypto Enterprise offers 7 algorithmic investment plans including 'Apex Genesis Starter', 'Quantum Alpha Fixed', and 'Solana Growth Engine'. Yields accrue daily at 00:00 UTC and can be compounded or withdrawn.";
      } else if (q.includes("security") || q.includes("mpc") || q.includes("safe") || q.includes("audit") || q.includes("cold")) {
        answer =
          "ApexCrypto Enterprise utilizes multi-region MPC Threshold cryptography, 95% air-gapped cold storage vaults, AES-256 encryption, and 2FA Google Authenticator protection.";
      } else if (q.includes("fee") || q.includes("cost")) {
        answer =
          "We charge 0% deposit fees. Investment plan management fees range from 0.50% to 1.20% annualized, which are already factored into net expected returns.";
      }

      return NextResponse.json({
        success: true,
        answer,
      });
    }

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    if (!subject || !category || !message) {
      return NextResponse.json(
        { error: "Subject, category, and initial message are required" },
        { status: 400 }
      );
    }

    const [newTicket] = await db
      .insert(supportTickets)
      .values({
        userId: user.id,
        subject: subject.trim(),
        category: category.trim(),
        status: "open",
        priority: priority || "medium",
      })
      .returning();

    await db.insert(ticketMessages).values({
      ticketId: newTicket.id,
      senderId: user.id,
      senderRole: user.role,
      message: message.trim(),
    });

    return NextResponse.json({
      success: true,
      ticket: newTicket,
      message: "Support ticket created successfully! Our 24/7 concierge team will respond shortly.",
    });
  } catch (error) {
    console.error("Error creating ticket:", error);
    return NextResponse.json(
      { error: "Failed to create support ticket" },
      { status: 500 }
    );
  }
}
