import { NextResponse } from "next/server";
import { db } from "@/db";
import { wallets, systemSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeeded } from "@/db/ensure-seeded";
import { logAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const targetUserId = searchParams.get("userId");

    let userIdToQuery = user.id;
    if (targetUserId && (user.role === "admin" || user.role === "superadmin")) {
      userIdToQuery = parseInt(targetUserId, 10);
    }

    const userWallets = await db
      .select()
      .from(wallets)
      .where(eq(wallets.userId, userIdToQuery));

    // Ensure all 7 supported currencies exist for this user
    const supported = ["BTC", "ETH", "USDT", "SOL", "XRP", "BNB", "LTC"];
    const existingCurrencies = userWallets.map((w) => w.currency);

    const settingsList = await db.select().from(systemSettings);
    const getAddress = (curr: string) => {
      const found = settingsList.find((s) => s.key === `wallet_${curr}`);
      return found?.value || "";
    };

    for (const curr of supported) {
      if (!existingCurrencies.includes(curr)) {
        const [inserted] = await db
          .insert(wallets)
          .values({
            userId: userIdToQuery,
            currency: curr,
            balance: "0",
            lockedBalance: "0",
            totalDeposited: "0",
            totalWithdrawn: "0",
            depositAddress: getAddress(curr),
          })
          .returning();
        userWallets.push(inserted);
      } else {
        // Ensure deposit address reflects latest admin settings
        const currentWallet = userWallets.find((w) => w.currency === curr);
        const latestAddr = getAddress(curr);
        if (currentWallet && currentWallet.depositAddress !== latestAddr && latestAddr) {
          await db
            .update(wallets)
            .set({ depositAddress: latestAddr })
            .where(eq(wallets.id, currentWallet.id));
          currentWallet.depositAddress = latestAddr;
        }
      }
    }

    return NextResponse.json({
      success: true,
      wallets: userWallets,
    });
  } catch (error) {
    console.error("Error fetching wallets:", error);
    return NextResponse.json(
      { error: "Failed to fetch wallet balances" },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user || (user.role !== "admin" && user.role !== "superadmin")) {
      return NextResponse.json(
        { error: "Admin authorization required to modify balances" },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { userId, currency, newBalance, reason } = body;

    if (!userId || !currency || newBalance === undefined) {
      return NextResponse.json(
        { error: "userId, currency, and newBalance are required" },
        { status: 400 }
      );
    }

    const [existingWallet] = await db
      .select()
      .from(wallets)
      .where(eq(wallets.userId, parseInt(userId, 10)))
      .limit(1);

    await db
      .update(wallets)
      .set({ balance: String(newBalance) })
      .where(eq(wallets.id, existingWallet.id));

    await logAudit({
      userId: user.id,
      action: "ADMIN_ADJUST_BALANCE",
      details: `Adjusted user #${userId} ${currency} balance to ${newBalance}. Reason: ${reason || "N/A"}`,
    });

    return NextResponse.json({
      success: true,
      message: `Balance for ${currency} updated to ${newBalance}`,
    });
  } catch (error) {
    console.error("Error adjusting balance:", error);
    return NextResponse.json(
      { error: "Failed to adjust wallet balance" },
      { status: 500 }
    );
  }
}
