import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  withdrawals,
  wallets,
  transactions,
  users,
} from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getCurrentUser, verifyPassword } from "@/lib/auth";
import { ensureSeeded } from "@/db/ensure-seeded";
import { logAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const filterAll = searchParams.get("all") === "true";

    let items;
    if (filterAll && (user.role === "admin" || user.role === "superadmin")) {
      items = await db
        .select({
          id: withdrawals.id,
          userId: withdrawals.userId,
          userEmail: users.email,
          userFullName: users.fullName,
          currency: withdrawals.currency,
          amount: withdrawals.amount,
          address: withdrawals.address,
          network: withdrawals.network,
          status: withdrawals.status,
          adminNote: withdrawals.adminNote,
          createdAt: withdrawals.createdAt,
        })
        .from(withdrawals)
        .leftJoin(users, eq(withdrawals.userId, users.id))
        .orderBy(desc(withdrawals.createdAt));
    } else {
      items = await db
        .select()
        .from(withdrawals)
        .where(eq(withdrawals.userId, user.id))
        .orderBy(desc(withdrawals.createdAt));
    }

    return NextResponse.json({
      success: true,
      withdrawals: items,
    });
  } catch (error) {
    console.error("Error fetching withdrawals:", error);
    return NextResponse.json(
      { error: "Failed to load withdrawal history" },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const {
      currency,
      amount,
      address,
      network,
      password,
      otpCode,
    } = body;

    if (!currency || !amount || !address || !network || !password) {
      return NextResponse.json(
        { error: "Currency, amount, destination address, network, and password are required" },
        { status: 400 }
      );
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return NextResponse.json(
        { error: "Withdrawal amount must be greater than zero" },
        { status: 400 }
      );
    }

    // Basic address validation
    if (address.length < 15) {
      return NextResponse.json(
        { error: "Invalid destination wallet address format" },
        { status: 400 }
      );
    }

    // Verify password
    const [fullUser] = await db
      .select()
      .from(users)
      .where(eq(users.id, user.id))
      .limit(1);

    const validPassword = await verifyPassword(password, fullUser.passwordHash);
    if (!validPassword) {
      await logAudit({
        userId: user.id,
        action: "WITHDRAWAL_FAILED_PASSWORD",
        details: `Failed password check on withdrawal request for ${numAmount} ${currency}`,
      });
      return NextResponse.json(
        { error: "Incorrect account password" },
        { status: 401 }
      );
    }

    // Check balance
    const userWallets = await db
      .select()
      .from(wallets)
      .where(eq(wallets.userId, user.id));

    const targetWallet = userWallets.find(
      (w) => w.currency === currency.toUpperCase()
    );

    if (!targetWallet) {
      return NextResponse.json(
        { error: `Wallet for ${currency} not found` },
        { status: 404 }
      );
    }

    const currentBalance = parseFloat(targetWallet.balance) || 0;
    if (currentBalance < numAmount) {
      return NextResponse.json(
        {
          error: `Insufficient available ${currency} balance. Current balance: ${currentBalance.toFixed(6)}`,
        },
        { status: 400 }
      );
    }

    // Deduct balance and add to lockedBalance while pending
    const newBal = currentBalance - numAmount;
    const newLock = (parseFloat(targetWallet.lockedBalance) || 0) + numAmount;

    await db
      .update(wallets)
      .set({
        balance: String(newBal.toFixed(8)),
        lockedBalance: String(newLock.toFixed(8)),
      })
      .where(eq(wallets.id, targetWallet.id));

    const [newWithdrawal] = await db
      .insert(withdrawals)
      .values({
        userId: user.id,
        currency: currency.toUpperCase(),
        amount: String(numAmount),
        address: address.trim(),
        network: network.trim(),
        status: "pending",
        adminNote: "Pending AML & security verification",
      })
      .returning();

    await db.insert(transactions).values({
      userId: user.id,
      type: "withdrawal",
      currency: currency.toUpperCase(),
      amount: String(numAmount),
      description: `Requested ${currency} withdrawal to ${address.slice(0, 8)}... (${network})`,
      status: "pending",
    });

    await logAudit({
      userId: user.id,
      action: "SUBMIT_WITHDRAWAL_REQUEST",
      details: `Requested withdrawal of ${numAmount} ${currency} to ${address} (${network})`,
    });

    return NextResponse.json({
      success: true,
      withdrawal: newWithdrawal,
      message:
        "Withdrawal request submitted successfully! Your request is now under enterprise AML & security review.",
    });
  } catch (error) {
    console.error("Error submitting withdrawal:", error);
    return NextResponse.json(
      { error: "Failed to submit withdrawal request" },
      { status: 500 }
    );
  }
}

export async function PUT(req: Request) {
  try {
    await ensureSeeded();
    const user = await getCurrentUser();

    if (!user || (user.role !== "admin" && user.role !== "superadmin")) {
      return NextResponse.json(
        { error: "Unauthorized: Admin privileges required" },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { withdrawalId, action, adminNote } = body; // action: 'approve' | 'reject'

    if (!withdrawalId || (action !== "approve" && action !== "reject")) {
      return NextResponse.json(
        { error: "Valid withdrawalId and action ('approve' or 'reject') are required" },
        { status: 400 }
      );
    }

    const [target] = await db
      .select()
      .from(withdrawals)
      .where(eq(withdrawals.id, parseInt(withdrawalId, 10)))
      .limit(1);

    if (!target) {
      return NextResponse.json({ error: "Withdrawal request not found" }, { status: 404 });
    }

    if (target.status !== "pending") {
      return NextResponse.json(
        { error: `Withdrawal is already ${target.status}` },
        { status: 400 }
      );
    }

    const userWallets = await db
      .select()
      .from(wallets)
      .where(eq(wallets.userId, target.userId));

    const targetWallet = userWallets.find((w) => w.currency === target.currency);

    if (action === "approve") {
      await db
        .update(withdrawals)
        .set({
          status: "completed",
          adminNote: adminNote || "Approved and broadcasted by ApexTreasury Node #1",
        })
        .where(eq(withdrawals.id, target.id));

      if (targetWallet) {
        // Remove from lockedBalance and add to totalWithdrawn
        const numAmount = parseFloat(target.amount) || 0;
        const currentLock = parseFloat(targetWallet.lockedBalance) || 0;
        const currentTotalWithdrawn = parseFloat(targetWallet.totalWithdrawn) || 0;

        await db
          .update(wallets)
          .set({
            lockedBalance: String(Math.max(0, currentLock - numAmount).toFixed(8)),
            totalWithdrawn: String((currentTotalWithdrawn + numAmount).toFixed(8)),
          })
          .where(eq(wallets.id, targetWallet.id));
      }

      await db.insert(transactions).values({
        userId: target.userId,
        type: "withdrawal",
        currency: target.currency,
        amount: target.amount,
        description: `Completed ${target.currency} Withdrawal - TX Broadcasted`,
        status: "completed",
      });

      await logAudit({
        userId: user.id,
        action: "ADMIN_APPROVE_WITHDRAWAL",
        details: `Approved withdrawal #${target.id} (${target.amount} ${target.currency}) for user #${target.userId}`,
      });

      return NextResponse.json({
        success: true,
        message: `Withdrawal #${target.id} has been approved and broadcast to the blockchain.`,
      });
    } else {
      // reject - refund locked balance back to available balance
      await db
        .update(withdrawals)
        .set({
          status: "rejected",
          adminNote: adminNote || "Rejected by Compliance Review",
        })
        .where(eq(withdrawals.id, target.id));

      if (targetWallet) {
        const numAmount = parseFloat(target.amount) || 0;
        const currentBal = parseFloat(targetWallet.balance) || 0;
        const currentLock = parseFloat(targetWallet.lockedBalance) || 0;

        await db
          .update(wallets)
          .set({
            balance: String((currentBal + numAmount).toFixed(8)),
            lockedBalance: String(Math.max(0, currentLock - numAmount).toFixed(8)),
          })
          .where(eq(wallets.id, targetWallet.id));
      }

      await db.insert(transactions).values({
        userId: target.userId,
        type: "withdrawal",
        currency: target.currency,
        amount: target.amount,
        description: `Rejected Withdrawal Request - Funds refunded to vault balance`,
        status: "rejected",
      });

      await logAudit({
        userId: user.id,
        action: "ADMIN_REJECT_WITHDRAWAL",
        details: `Rejected withdrawal #${target.id} for user #${target.userId}`,
      });

      return NextResponse.json({
        success: true,
        message: `Withdrawal #${target.id} has been rejected and funds restored to user balance.`,
      });
    }
  } catch (error) {
    console.error("Error processing withdrawal review:", error);
    return NextResponse.json(
      { error: "Failed to process withdrawal review" },
      { status: 500 }
    );
  }
}
