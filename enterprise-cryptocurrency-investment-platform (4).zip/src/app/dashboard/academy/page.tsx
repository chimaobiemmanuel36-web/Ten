"use client";

import React, { useEffect, useState } from "react";
import {
  GraduationCap,
  BookOpen,
  Award,
  CheckCircle2,
  Clock,
  ArrowRight,
  HelpCircle,
} from "lucide-react";

export default function CryptoAcademyPage() {
  const [lessons, setLessons] = useState<any[]>([]);
  const [selectedLesson, setSelectedLesson] = useState<any | null>(null);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchLessons() {
      try {
        const res = await fetch("/api/academy", { cache: "no-store", headers: { "Cache-Control": "no-cache" } });
        const data = await res.json();
        if (data.lessons) setLessons(data.lessons);
      } catch {
        // Quiet
      } finally {
        setLoading(false);
      }
    }
    fetchLessons();
  }, []);

  const handleSelectAnswer = (qIdx: number, optIdx: number) => {
    if (quizSubmitted) return;
    setSelectedAnswers((prev) => ({ ...prev, [qIdx]: optIdx }));
  };

  const calculateScore = () => {
    if (!selectedLesson?.quizQuestions) return 0;
    let correct = 0;
    selectedLesson.quizQuestions.forEach((q: any, i: number) => {
      if (selectedAnswers[i] === q.correctAnswer) correct++;
    });
    return correct;
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
          <GraduationCap className="w-4 h-4" />
          <span>Institutional Knowledge Hub</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white">
          Apex Crypto Academy
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          Master enterprise digital asset custody, quantitative delta-neutral yield strategies, and Solana MEV validator restaking.
        </p>
      </div>

      {/* Lesson detail modal / view */}
      {selectedLesson ? (
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div>
              <span className="px-3 py-1 rounded-full bg-amber-400/10 text-amber-400 text-xs font-bold border border-amber-400/30">
                {selectedLesson.level} • {selectedLesson.category}
              </span>
              <h2 className="text-2xl font-extrabold text-white mt-2">
                {selectedLesson.title}
              </h2>
              <p className="text-xs text-slate-400 flex items-center gap-1.5 mt-1">
                <Clock className="w-3.5 h-3.5" />
                <span>{selectedLesson.readTimeMinutes} Min Reading Time</span>
              </p>
            </div>
            <button
              onClick={() => {
                setSelectedLesson(null);
                setSelectedAnswers({});
                setQuizSubmitted(false);
              }}
              className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold"
            >
              ← Back to Curriculum
            </button>
          </div>

          {/* Lesson content */}
          <div className="prose prose-invert max-w-none text-xs sm:text-sm text-slate-300 leading-relaxed whitespace-pre-line">
            {selectedLesson.content}
          </div>

          {/* Interactive Quiz */}
          {selectedLesson.quizQuestions && selectedLesson.quizQuestions.length > 0 && (
            <div className="pt-6 border-t border-white/10 space-y-6">
              <div className="flex items-center gap-2 text-base font-extrabold text-white">
                <Award className="w-5 h-5 text-amber-400" />
                <span>Knowledge Check Quiz</span>
              </div>

              <div className="space-y-6">
                {selectedLesson.quizQuestions.map((q: any, qIdx: number) => {
                  const isCorrect = selectedAnswers[qIdx] === q.correctAnswer;
                  return (
                    <div
                      key={qIdx}
                      className="p-5 rounded-2xl bg-slate-950 border border-white/10 space-y-3"
                    >
                      <div className="font-bold text-white text-sm">
                        {qIdx + 1}. {q.question}
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {q.options.map((opt: string, optIdx: number) => {
                          const selected = selectedAnswers[qIdx] === optIdx;
                          let btnClass = "bg-slate-900 border-white/10 text-slate-300";
                          if (selected) btnClass = "bg-amber-400/20 border-amber-400 text-amber-300 font-bold";
                          if (quizSubmitted) {
                            if (optIdx === q.correctAnswer) {
                              btnClass = "bg-emerald-500/20 border-emerald-400 text-emerald-300 font-bold";
                            } else if (selected) {
                              btnClass = "bg-rose-500/20 border-rose-400 text-rose-300";
                            }
                          }

                          return (
                            <button
                              key={optIdx}
                              onClick={() => handleSelectAnswer(qIdx, optIdx)}
                              disabled={quizSubmitted}
                              className={`p-3 rounded-xl border text-left text-xs transition-all ${btnClass}`}
                            >
                              {String.fromCharCode(65 + optIdx)}. {opt}
                            </button>
                          );
                        })}
                      </div>

                      {quizSubmitted && (
                        <div className="text-xs pt-1">
                          {isCorrect ? (
                            <span className="text-emerald-400 font-bold">✓ Correct answer!</span>
                          ) : (
                            <span className="text-rose-400">✗ Incorrect. Correct answer is option {String.fromCharCode(65 + q.correctAnswer)}.</span>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {!quizSubmitted ? (
                <button
                  onClick={() => setQuizSubmitted(true)}
                  disabled={Object.keys(selectedAnswers).length < selectedLesson.quizQuestions.length}
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-xs shadow-lg disabled:opacity-50"
                >
                  Submit Quiz Answers
                </button>
              ) : (
                <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center justify-between">
                  <span>
                    Quiz completed! You scored {calculateScore()} out of {selectedLesson.quizQuestions.length}.
                  </span>
                  <button
                    onClick={() => {
                      setQuizSubmitted(false);
                      setSelectedAnswers({});
                    }}
                    className="underline text-white"
                  >
                    Retake Quiz
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        /* Lessons Grid */
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {lessons.map((l) => (
            <div
              key={l.id}
              onClick={() => setSelectedLesson(l)}
              className="bg-slate-900/60 border border-white/10 hover:border-amber-400/30 rounded-3xl p-6 sm:p-8 flex flex-col justify-between space-y-6 cursor-pointer transition-all"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="px-3 py-1 rounded-full bg-amber-400/10 text-amber-400 text-xs font-bold border border-amber-400/30">
                    {l.level}
                  </span>
                  <span className="text-xs text-slate-400 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    {l.readTimeMinutes} min
                  </span>
                </div>
                <h3 className="text-lg font-bold text-white mb-2">
                  {l.title}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {l.summary}
                </p>
              </div>

              <div className="pt-4 border-t border-white/5 flex items-center justify-between text-xs font-bold text-amber-400">
                <span>Start Lesson & Quiz</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
