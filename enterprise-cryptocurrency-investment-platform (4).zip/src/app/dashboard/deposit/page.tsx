"use client";

import React, { useEffect, useState } from "react";
import {
  ArrowDownLeft,
  Copy,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  QrCode as QrIcon,
  HelpCircle,
  Clock,
  Upload,
} from "lucide-react";
import { QrCode } from "@/components/qr-code";

interface CoinDeposit {
  symbol: string;
  name: string;
  network: string;
  addressKey: string;
  minDeposit: string;
  confirmations: string;
}

const DEPOSIT_COINS: CoinDeposit[] = [
  { symbol: "BTC", name: "Bitcoin", network: "Bitcoin Native", addressKey: "wallet_BTC", minDeposit: "0.0005 BTC", confirmations: "3 Confirmations" },
  { symbol: "USDT", name: "Tether USD", network: "ERC-20 / Ethereum", addressKey: "wallet_USDT", minDeposit: "10 USDT", confirmations: "6 Confirmations" },
  { symbol: "ETH", name: "Ethereum", network: "ERC-20 Native", addressKey: "wallet_ETH", minDeposit: "0.01 ETH", confirmations: "6 Confirmations" },
  { symbol: "SOL", name: "Solana", network: "Solana Native", addressKey: "wallet_SOL", minDeposit: "0.1 SOL", confirmations: "1 Confirmation" },
  { symbol: "BNB", name: "Binance Coin", network: "BEP-20 Native", addressKey: "wallet_BNB", minDeposit: "0.05 BNB", confirmations: "15 Confirmations" },
  { symbol: "XRP", name: "Ripple", network: "XRP Ledger", addressKey: "wallet_XRP", minDeposit: "20 XRP", confirmations: "1 Confirmation" },
  { symbol: "LTC", name: "Litecoin", network: "Litecoin Native", addressKey: "wallet_LTC", minDeposit: "0.1 LTC", confirmations: "6 Confirmations" },
];

export default function DepositCryptoPage() {
  const [selectedCoin, setSelectedCoin] = useState<CoinDeposit>(DEPOSIT_COINS[1]); // USDT default
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [copied, setCopied] = useState(false);
  const [amount, setAmount] = useState("");
  const [txid, setTxid] = useState("");
  const [proofUrl, setProofUrl] = useState("https://apexcrypto.io/proofs/client-receipt.png");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);
  const [depositsHistory, setDepositsHistory] = useState<any[]>([]);

  const fetchSettingsAndHistory = async () => {
    try {
      const [sRes, dRes] = await Promise.all([
        fetch("/api/settings", { cache: "no-store", headers: { "Cache-Control": "no-cache" } }),
        fetch("/api/deposits", { cache: "no-store", headers: { "Cache-Control": "no-cache" } }),
      ]);
      const sData = await sRes.json();
      const dData = await dRes.json();
      if (sData.settings) setSettings(sData.settings);
      if (dData.deposits) setDepositsHistory(dData.deposits);
    } catch {
      // Quiet
    }
  };

  useEffect(() => {
    fetchSettingsAndHistory();
  }, []);

  const depositAddress = settings[selectedCoin.addressKey] || "Loading MPC Vault Address...";

  const handleCopy = () => {
    navigator.clipboard.writeText(depositAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmitDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || parseFloat(amount) <= 0 || !txid.trim()) {
      setError("Please provide a valid deposit amount and transaction hash (TXID)");
      return;
    }

    setError("");
    setSuccess("");
    setLoading(true);

    try {
      const res = await fetch("/api/deposits", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currency: selectedCoin.symbol,
          amount,
          txid: txid.trim(),
          network: selectedCoin.network,
          proofUrl,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error || "Deposit submission failed");
      } else {
        setSuccess(data.message || "Deposit submitted for automated blockchain verification!");
        setAmount("");
        setTxid("");
        await fetchSettingsAndHistory();
      }
    } catch {
      setError("Network error submitting deposit");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
          <ArrowDownLeft className="w-4 h-4" />
          <span>MPC Threshold Deposit Address</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white">
          Deposit Cryptocurrency
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          Select an asset to generate its verified QR code and deposit address. We charge 0% deposit fees.
        </p>
      </div>

      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-bold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{success}</span>
        </div>
      )}

      {/* Asset Selector Tabs */}
      <div className="flex flex-wrap items-center gap-2">
        {DEPOSIT_COINS.map((c) => (
          <button
            key={c.symbol}
            onClick={() => {
              setSelectedCoin(c);
              setError("");
              setSuccess("");
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              selectedCoin.symbol === c.symbol
                ? "bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20"
                : "bg-slate-900/80 hover:bg-slate-900 text-slate-300 border border-white/10"
            }`}
          >
            {c.symbol} • {c.name}
          </button>
        ))}
      </div>

      {/* Deposit QR & Address Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left: QR code & details */}
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 sm:p-8 flex flex-col items-center text-center space-y-6">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30">
            <ShieldCheck className="w-4 h-4" />
            <span>Verified MPC Vault Address</span>
          </div>

          <QrCode value={depositAddress} size={180} currency={selectedCoin.symbol} />

          <div className="w-full space-y-2">
            <div className="text-xs font-bold text-slate-400">
              {selectedCoin.network} Network Address
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-white/10 font-mono text-xs text-amber-300 break-all select-all">
              {depositAddress}
            </div>
            <button
              onClick={handleCopy}
              className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-all flex items-center justify-center gap-2"
            >
              {copied ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Address Copied to Clipboard</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copy Deposit Address</span>
                </>
              )}
            </button>
          </div>

          <div className="w-full pt-2 border-t border-white/10 space-y-2 text-left text-xs text-slate-400">
            <div className="flex justify-between">
              <span>Minimum Deposit:</span>
              <span className="font-bold text-white">{selectedCoin.minDeposit}</span>
            </div>
            <div className="flex justify-between">
              <span>Required Confirmations:</span>
              <span className="font-bold text-white">{selectedCoin.confirmations}</span>
            </div>
          </div>
        </div>

        {/* Right: Submit TXID form */}
        <div className="lg:col-span-2 bg-slate-900/80 border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6">
          <div>
            <h2 className="text-xl font-bold text-white">
              Submit Transaction Hash (TXID)
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              After broadcasting your {selectedCoin.symbol} deposit, submit your transaction hash to accelerate automated vault crediting.
            </p>
          </div>

          <form onSubmit={handleSubmitDeposit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Deposit Amount ({selectedCoin.symbol})
              </label>
              <input
                type="number"
                step="any"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder={`min ${selectedCoin.minDeposit}`}
                className="w-full bg-slate-950 text-white text-sm rounded-xl px-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Blockchain Transaction ID (TXID / Hash)
              </label>
              <input
                type="text"
                required
                value={txid}
                onChange={(e) => setTxid(e.target.value)}
                placeholder="0x892a34b8c9d012e8471..."
                className="w-full bg-slate-950 text-white text-sm font-mono rounded-xl px-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Payment Receipt URL / Screenshot Proof <span className="text-slate-500 font-normal">(Optional)</span>
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={proofUrl}
                  onChange={(e) => setProofUrl(e.target.value)}
                  className="flex-1 bg-slate-950 text-white text-xs rounded-xl px-4 py-3 border border-white/10 focus:outline-none"
                />
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200/90 leading-relaxed">
              <span className="font-bold text-amber-300">Important Safety Notice:</span> Ensure you only deposit {selectedCoin.symbol} on the{" "}
              <span className="font-bold underline">{selectedCoin.network}</span> network. Sending tokens from unsupported chains may result in permanent loss.
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-slate-950 font-black text-sm shadow-xl hover:scale-[1.02] transition-all disabled:opacity-50"
            >
              {loading ? "Submitting TXID..." : "Submit Deposit Verification"}
            </button>
          </form>
        </div>
      </div>

      {/* Deposit History */}
      <div className="bg-slate-900/60 border border-white/10 rounded-3xl p-6 space-y-4">
        <h3 className="text-lg font-bold text-white">Recent Deposit History</h3>
        <div className="space-y-3">
          {depositsHistory.map((d) => (
            <div
              key={d.id}
              className="p-4 rounded-2xl bg-slate-900 border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
            >
              <div>
                <div className="font-bold text-white flex items-center gap-2">
                  <span>+{d.amount} {d.currency}</span>
                  <span className="text-slate-500">•</span>
                  <span className="text-slate-400">{d.network}</span>
                </div>
                <div className="font-mono text-[11px] text-slate-400 truncate max-w-sm">
                  TXID: {d.txid}
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span
                  className={`px-3 py-1 rounded-full font-bold uppercase text-[10px] ${
                    d.status === "confirmed"
                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                      : d.status === "pending"
                      ? "bg-amber-500/10 text-amber-400 border border-amber-500/30"
                      : "bg-rose-500/10 text-rose-400 border border-rose-500/30"
                  }`}
                >
                  {d.status}
                </span>
                <span className="text-slate-500 text-[10px]">
                  {new Date(d.createdAt).toLocaleDateString()}
                </span>
              </div>
            </div>
          ))}
          {depositsHistory.length === 0 && (
            <div className="text-center py-8 text-xs text-slate-500">
              No deposit history yet
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
