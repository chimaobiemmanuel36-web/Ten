"use client";

import React, { useEffect, useState } from "react";
import {
  BarChart2,
  TrendingUp,
  Award,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Clock,
  ShieldCheck,
  RefreshCw,
} from "lucide-react";
import Link from "next/link";

export default function ActiveInvestmentsPage() {
  const [investments, setInvestments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<number | null>(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const loadInvestments = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/investments", {
        cache: "no-store",
        headers: { "Cache-Control": "no-cache" },
      });
      const data = await res.json();
      if (data.investments) {
        setInvestments(data.investments);
      }
    } catch {
      // Quiet
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInvestments();
  }, []);

  const handleWithdrawInvestment = async (invId: number) => {
    setMessage("");
    setError("");
    setActionLoading(invId);
    try {
      const res = await fetch("/api/investments", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ investmentId: invId, action: "withdraw" }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error || "Failed to process withdrawal");
      } else {
        setMessage(data.message || "Capital successfully withdrawn back to wallet");
        await loadInvestments();
      }
    } catch {
      setError("Network error processing investment withdrawal");
    } finally {
      setActionLoading(null);
    }
  };

  const activeCount = investments.filter((i) => i.status === "active").length;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
            <BarChart2 className="w-4 h-4" />
            <span>Algorithmic Yield Execution</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white">
            Active Investment Strategies
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Monitor real-time accrued returns, compounding progress, and maturity schedules across your deployed vaults.
          </p>
        </div>
        <Link
          href="/dashboard/plans"
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-slate-950 font-black text-xs shadow-lg hover:scale-105 transition-all flex items-center gap-2 w-fit"
        >
          <span>+ Deploy New Strategy</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>

      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-bold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {message && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6">
          <div className="text-xs font-bold text-slate-400 uppercase">
            Active Strategies
          </div>
          <div className="text-3xl font-black text-white mt-1">
            {activeCount} Vaults
          </div>
          <div className="text-[11px] text-emerald-400 font-bold mt-2">
            ● 100% Smart contract verified
          </div>
        </div>

        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6">
          <div className="text-xs font-bold text-slate-400 uppercase">
            Compounding Schedule
          </div>
          <div className="text-3xl font-black text-amber-400 mt-1">
            Daily 00:00 UTC
          </div>
          <div className="text-[11px] text-slate-400 mt-2">
            Automated principal compounding
          </div>
        </div>

        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6">
          <div className="text-xs font-bold text-slate-400 uppercase">
            Insurance & Protection
          </div>
          <div className="text-3xl font-black text-emerald-400 mt-1">
            Institutional Cover
          </div>
          <div className="text-[11px] text-slate-400 mt-2">
            Multi-region MPC redundancy
          </div>
        </div>
      </div>

      {/* Strategies List */}
      <div className="space-y-4">
        {investments.map((inv) => {
          const startMs = new Date(inv.startDate).getTime();
          const endMs = new Date(inv.endDate).getTime();
          const now = Date.now();
          const isCompleted = now >= endMs || inv.status === "completed";
          const progressPct = Math.round(
            Math.max(5, Math.min(100, ((now - startMs) / (endMs - startMs)) * 100))
          );

          return (
            <div
              key={inv.id}
              className="bg-slate-900/60 border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6 hover:border-white/20 transition-all"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xl font-extrabold text-white">
                      {inv.planName || "Institutional Strategy"}
                    </span>
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                        inv.status === "active"
                          ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                          : "bg-slate-800 text-slate-400 border border-white/10"
                      }`}
                    >
                      {inv.status.toUpperCase()}
                    </span>
                  </div>
                  <div className="text-xs text-slate-400">
                    Deployed on {new Date(inv.startDate).toLocaleDateString()} • Maturity:{" "}
                    {new Date(inv.endDate).toLocaleDateString()}
                  </div>
                </div>

                {inv.status === "active" && (
                  <button
                    onClick={() => handleWithdrawInvestment(inv.id)}
                    disabled={actionLoading === inv.id}
                    className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-white/10 text-white font-bold text-xs transition-colors disabled:opacity-50"
                  >
                    {actionLoading === inv.id
                      ? "Processing..."
                      : isCompleted
                      ? "Claim Completed Payout"
                      : "Early Withdrawal"}
                  </button>
                )}
              </div>

              {/* Stats row */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-2xl bg-slate-950 border border-white/5">
                <div>
                  <div className="text-xs text-slate-400">Principal Deployed</div>
                  <div className="text-lg font-black text-white">
                    {inv.amount} {inv.currency}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-400">Accrued Profit</div>
                  <div className="text-lg font-black text-emerald-400">
                    +{inv.accruedProfit || "0.00"} {inv.currency}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-400">Expected Total Return</div>
                  <div className="text-lg font-black text-amber-400">
                    +{inv.expectedProfit} {inv.currency}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-400">Maturity Progress</div>
                  <div className="text-lg font-black text-white">
                    {progressPct}%
                  </div>
                </div>
              </div>

              {/* Progress bar */}
              <div>
                <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-400 via-amber-300 to-emerald-400"
                    style={{ width: `${progressPct}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}

        {investments.length === 0 && !loading && (
          <div className="p-12 rounded-3xl bg-slate-900/60 border border-white/10 text-center space-y-4">
            <TrendingUp className="w-10 h-10 text-amber-400 mx-auto" />
            <h3 className="text-lg font-bold text-white">No active investment strategies</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Deploy capital into one of our 7 algorithmic enterprise yield plans to start accruing daily returns.
            </p>
            <Link
              href="/dashboard/plans"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-xs"
            >
              <span>Browse Enterprise Plans</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
