"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  LayoutDashboard,
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
  TrendingUp,
  BarChart2,
  GraduationCap,
  Users,
  ShieldAlert,
  HeadphonesIcon,
  LogOut,
  Menu,
  X,
  Zap,
  ChevronRight,
  ShieldCheck,
} from "lucide-react";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [user, setUser] = useState<any>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    // 1. Immediately hydrate from localStorage to prevent flicker or redirection
    try {
      const stored = localStorage.getItem("apex_crypto_user");
      if (stored) {
        setUser(JSON.parse(stored));
      }
    } catch {
      // ignore
    }

    // 2. Verify with server without caching
    async function fetchMe(retryCount = 0) {
      try {
        const res = await fetch("/api/auth/me", {
          cache: "no-store",
          credentials: "include",
          headers: {
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
          },
        });
        const data = await res.json();
        if (data && data.user) {
          setUser(data.user);
          try {
            localStorage.setItem("apex_crypto_user", JSON.stringify(data.user));
          } catch {}
        } else if (res.status === 401) {
          const existingUser = localStorage.getItem("apex_crypto_user");
          const existingToken = localStorage.getItem("apex_crypto_token");
          if (!existingUser && !existingToken) {
            router.push("/login");
          }
        }
      } catch {
        const existingUser = localStorage.getItem("apex_crypto_user");
        const existingToken = localStorage.getItem("apex_crypto_token");
        if (!existingUser && !existingToken) {
          router.push("/login");
        }
      }
    }
    fetchMe();
  }, [router]);

  const navItems = [
    { label: "Portfolio Vault", href: "/dashboard", icon: LayoutDashboard },
    { label: "Yield Plans", href: "/dashboard/plans", icon: TrendingUp },
    { label: "Active Strategies", href: "/dashboard/investments", icon: BarChart2 },
    { label: "Deposit Crypto", href: "/dashboard/deposit", icon: ArrowDownLeft },
    { label: "Withdraw Crypto", href: "/dashboard/withdraw", icon: ArrowUpRight },
    { label: "Multi-Currency Wallets", href: "/dashboard/wallets", icon: Wallet },
    { label: "Live Market & Oracle", href: "/dashboard/market", icon: BarChart2 },
    { label: "Crypto Academy", href: "/dashboard/academy", icon: GraduationCap },
    { label: "Referral Commission", href: "/dashboard/referrals", icon: Users },
    { label: "MPC Security & 2FA", href: "/dashboard/security", icon: ShieldAlert },
    { label: "Concierge Support", href: "/dashboard/support", icon: HeadphonesIcon },
  ];

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  };

  const isAdmin = user && (user.role === "admin" || user.role === "superadmin");

  return (
    <div className="flex-1 flex bg-[#090d16] text-slate-100 min-h-screen">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-72 bg-slate-950 border-r border-white/10 shrink-0">
        {/* User identification badge */}
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 font-black flex items-center justify-center text-lg shadow-md">
              {user?.fullName?.charAt(0) || "A"}
            </div>
            <div className="overflow-hidden">
              <div className="font-extrabold text-white truncate text-sm">
                {user?.fullName || "Enterprise User"}
              </div>
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="truncate">KYC Verified</span>
              </div>
            </div>
          </div>

          {isAdmin && (
            <Link
              href="/admin"
              className="mt-4 flex items-center justify-between px-3.5 py-2 rounded-xl bg-amber-400/10 border border-amber-400/30 text-amber-300 hover:bg-amber-400/20 text-xs font-extrabold transition-all"
            >
              <div className="flex items-center gap-2">
                <Zap className="w-3.5 h-3.5 fill-amber-400" />
                <span>Admin Treasury Portal</span>
              </div>
              <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          )}
        </div>

        {/* Sidebar Nav */}
        <nav className="flex-1 overflow-y-auto px-4 py-4 space-y-1 no-scrollbar">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-2xl text-xs font-bold transition-all ${
                  isActive
                    ? "bg-gradient-to-r from-amber-500/20 to-amber-500/5 text-amber-400 border border-amber-500/30 shadow-md"
                    : "text-slate-400 hover:text-white hover:bg-white/5"
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isActive ? "text-amber-400" : "text-slate-400"
                  }`}
                />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Logout bottom */}
        <div className="p-4 border-t border-white/10">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-xs font-bold text-rose-400 hover:bg-rose-500/10 transition-colors"
          >
            <LogOut className="w-4 h-4 shrink-0" />
            <span>Secure Vault Logout</span>
          </button>
        </div>
      </aside>

      {/* Mobile Sidebar sheet */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative w-72 bg-slate-950 border-r border-white/10 flex flex-col z-10">
            <div className="p-5 border-b border-white/10 flex items-center justify-between">
              <span className="font-extrabold text-base text-white">
                Vault Navigation
              </span>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto px-4 py-4 space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = pathname === item.href;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-2xl text-xs font-bold ${
                      isActive
                        ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                        : "text-slate-400 hover:text-white"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </Link>
                );
              })}
            </nav>
          </aside>
        </div>
      )}

      {/* Main Container */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Responsive Mobile Header */}
        <div className="lg:hidden flex items-center justify-between px-4 py-3 bg-slate-950 border-b border-white/10">
          <div className="flex items-center gap-2 font-bold text-sm text-white">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="p-2 rounded-xl bg-white/5 text-slate-300"
            >
              <Menu className="w-5 h-5" />
            </button>
            <span>{user?.fullName || "Vault"}</span>
          </div>
          <Link
            href="/dashboard/deposit"
            className="px-4 py-1.5 rounded-xl bg-amber-500 text-slate-950 text-xs font-extrabold"
          >
            + Deposit
          </Link>
        </div>

        {/* Subpage Content */}
        <div className="flex-1 p-4 sm:p-8 overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}
