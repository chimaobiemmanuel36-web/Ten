"use client";

import React, { useEffect, useState } from "react";
import { Activity, ArrowUpRight, ArrowDownRight, BarChart2 } from "lucide-react";
import { TradingChart } from "@/components/trading-chart";

export default function MarketDashboardPage() {
  const [coins, setCoins] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadMarket() {
      try {
        const res = await fetch("/api/market", { cache: "no-store", headers: { "Cache-Control": "no-cache" } });
        const data = await res.json();
        if (data.coins) setCoins(data.coins);
      } catch {
        // Quiet
      } finally {
        setLoading(false);
      }
    }
    loadMarket();
  }, []);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
          <Activity className="w-4 h-4" />
          <span>Real-Time Tier-1 Oracle Feeds</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white">
          Live Market & Trading Analytics
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          Real-time aggregated market capitalization, TradingView sparkline charts, and institutional pricing indices.
        </p>
      </div>

      {/* Main Chart */}
      <TradingChart coins={coins} />

      {/* Full Asset Table */}
      <div className="bg-slate-900/80 border border-white/10 rounded-3xl overflow-hidden">
        <div className="p-6 border-b border-white/10 flex items-center justify-between">
          <h2 className="text-lg font-bold text-white">Supported Cryptocurrency Assets</h2>
          <span className="text-xs text-slate-400">100% Native & ERC-20 Support</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/60 text-slate-400 uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4">Asset</th>
                <th className="px-6 py-4">Price (USD)</th>
                <th className="px-6 py-4">24h Change</th>
                <th className="px-6 py-4">24h High / Low</th>
                <th className="px-6 py-4">Market Cap</th>
                <th className="px-6 py-4">Network</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {coins.map((c) => {
                const isPos = c.change24h >= 0;
                return (
                  <tr key={c.id} className="hover:bg-white/5 transition-colors">
                    <td className="px-6 py-4 font-bold text-white flex items-center gap-2">
                      <span className="w-6 h-6 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center font-black text-[10px] text-amber-400">
                        {c.symbol}
                      </span>
                      <span>{c.name}</span>
                    </td>
                    <td className="px-6 py-4 font-mono font-bold text-white">
                      {c.price < 10
                        ? `$${c.price.toFixed(4)}`
                        : `$${c.price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`inline-flex items-center gap-1 font-bold ${
                          isPos ? "text-emerald-400" : "text-rose-400"
                        }`}
                      >
                        {isPos ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                        {Math.abs(c.change24h).toFixed(2)}%
                      </span>
                    </td>
                    <td className="px-6 py-4 font-mono text-slate-400">
                      ${c.high24h?.toLocaleString()} / ${c.low24h?.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 font-mono text-slate-400">
                      ${(c.marketCap / 1e9).toFixed(2)}B
                    </td>
                    <td className="px-6 py-4">
                      <span className="px-2 py-0.5 rounded bg-white/5 text-[10px] text-slate-400">
                        {c.network || "Native"}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
