"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import {
  Wallet,
  TrendingUp,
  ArrowDownLeft,
  ArrowUpRight,
  ShieldCheck,
  Award,
  BarChart3,
  Activity,
  ChevronRight,
  Sparkles,
  Lock,
  ArrowRight,
  RefreshCw,
} from "lucide-react";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
} from "recharts";

export default function UserDashboardPage() {
  const [wallets, setWallets] = useState<any[]>([]);
  const [investments, setInvestments] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [deposits, setDeposits] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [walRes, invRes, depRes, withRes] = await Promise.all([
        fetch("/api/wallets"),
        fetch("/api/investments"),
        fetch("/api/deposits"),
        fetch("/api/withdrawals"),
      ]);
      const walData = await walRes.json();
      const invData = await invRes.json();
      const depData = await depRes.json();
      const withData = await withRes.json();

      if (walData.wallets) setWallets(walData.wallets);
      if (invData.investments) setInvestments(invData.investments);
      if (depData.deposits) setDeposits(depData.deposits);
      if (withData.withdrawals) setWithdrawals(withData.withdrawals);
    } catch {
      // Quiet
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAll();
  }, []);

  // Compute metrics
  const rates: Record<string, number> = {
    BTC: 94820,
    ETH: 3410,
    SOL: 194,
    BNB: 642,
    XRP: 2.38,
    LTC: 118,
    USDT: 1.0,
  };

  let totalWalletUsd = 0;
  let totalDepositsUsd = 0;
  let totalWithdrawalsUsd = 0;

  for (const w of wallets) {
    const bal = parseFloat(w.balance) || 0;
    const rate = rates[w.currency] || 1;
    totalWalletUsd += bal * rate;

    const dep = parseFloat(w.totalDeposited) || 0;
    const wit = parseFloat(w.totalWithdrawn) || 0;
    totalDepositsUsd += dep * rate;
    totalWithdrawalsUsd += wit * rate;
  }

  let activeInvestmentBalanceUsd = 0;
  let totalAccruedProfitUsd = 0;

  for (const i of investments) {
    if (i.status === "active") {
      const principal = parseFloat(i.amount) || 0;
      const accrued = parseFloat(i.accruedProfit) || 0;
      const rate = rates[i.currency] || 1;
      activeInvestmentBalanceUsd += principal * rate;
      totalAccruedProfitUsd += accrued * rate;
    }
  }

  const totalAssetsUsd = totalWalletUsd + activeInvestmentBalanceUsd;

  // Pie chart allocation
  const COLORS = ["#f59e0b", "#3b82f6", "#10b981", "#8b5cf6", "#eab308", "#06b6d4", "#94a3b8"];
  const pieData = wallets
    .map((w) => ({
      name: w.currency,
      value: (parseFloat(w.balance) || 0) * (rates[w.currency] || 1),
    }))
    .filter((d) => d.value > 0);

  const pendingDeps = deposits.filter((d) => d.status === "pending").length;
  const pendingWiths = withdrawals.filter((w) => w.status === "pending").length;

  return (
    <div className="space-y-8">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>MPC Threshold Protected Account</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white">
            Institutional Vault Overview
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={fetchAll}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/10 text-slate-300 transition-colors"
            title="Refresh Vault Data"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          </button>
          <Link
            href="/dashboard/deposit"
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-slate-950 font-black text-xs shadow-lg hover:scale-105 transition-all flex items-center gap-1.5"
          >
            <ArrowDownLeft className="w-4 h-4" />
            <span>Deposit Funds</span>
          </Link>
          <Link
            href="/dashboard/withdraw"
            className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/10 text-white font-bold text-xs transition-colors flex items-center gap-1.5"
          >
            <ArrowUpRight className="w-4 h-4 text-amber-400" />
            <span>Withdraw</span>
          </Link>
        </div>
      </div>

      {/* Primary KPI Grid (4 Cards) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Assets */}
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 shadow-xl relative overflow-hidden">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
            Total Asset Balance
          </div>
          <div className="text-3xl font-black text-white">
            ${totalAssetsUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-emerald-400 font-bold mt-2 flex items-center gap-1">
            <span>● 95% Offline Vault Security</span>
          </div>
        </div>

        {/* Investment Balance */}
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 shadow-xl">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
            Active Strategies
          </div>
          <div className="text-3xl font-black text-amber-400">
            ${activeInvestmentBalanceUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-400 mt-2 flex items-center gap-1">
            <span>{investments.filter((i) => i.status === "active").length} active algorithmic plans</span>
          </div>
        </div>

        {/* Profit / Loss */}
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 shadow-xl">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
            Accrued Profit (APY)
          </div>
          <div className="text-3xl font-black text-emerald-400">
            +${totalAccruedProfitUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-emerald-400 font-bold mt-2">
            <span>✓ Daily yield compounding</span>
          </div>
        </div>

        {/* Total Deposits & Withdrawals summary */}
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Total Deposits:</span>
            <span className="font-bold text-white">${totalDepositsUsd.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
          </div>
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Total Withdrawals:</span>
            <span className="font-bold text-white">${totalWithdrawalsUsd.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
          </div>
          <div className="flex items-center justify-between text-[11px] pt-2 border-t border-white/10">
            <span className="text-amber-400 font-bold">Pending Review:</span>
            <span className="text-slate-300">{pendingDeps} Deps / {pendingWiths} Withs</span>
          </div>
        </div>
      </div>

      {/* Wallet Balances & Allocation Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Multi-Currency Balances (2 cols) */}
        <div className="lg:col-span-2 bg-slate-900/60 border border-white/10 rounded-3xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-white">Multi-Currency Vault Balances</h2>
            <Link href="/dashboard/wallets" className="text-xs text-amber-400 font-semibold hover:underline">
              View All Wallets →
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {wallets.map((w) => {
              const bal = parseFloat(w.balance) || 0;
              const rate = rates[w.currency] || 1;
              const usdVal = bal * rate;

              return (
                <div
                  key={w.id}
                  className="p-4 rounded-2xl bg-slate-900 border border-white/5 hover:border-white/20 transition-all flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 font-black text-amber-400 flex items-center justify-center text-xs">
                      {w.currency}
                    </div>
                    <div>
                      <div className="font-bold text-white text-sm">
                        {bal < 1 ? bal.toFixed(4) : bal.toFixed(2)} {w.currency}
                      </div>
                      <div className="text-xs text-slate-400">
                        ${usdVal.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
                      </div>
                    </div>
                  </div>

                  <Link
                    href={`/dashboard/deposit?asset=${w.currency}`}
                    className="p-2 rounded-xl bg-white/5 hover:bg-amber-400/20 hover:text-amber-300 text-slate-400 text-xs font-semibold transition-colors"
                  >
                    + Add
                  </Link>
                </div>
              );
            })}
          </div>
        </div>

        {/* Allocation Recharts Donut */}
        <div className="bg-slate-900/60 border border-white/10 rounded-3xl p-6 flex flex-col justify-between">
          <div>
            <h2 className="text-lg font-bold text-white mb-2">Portfolio Asset Allocation</h2>
            <p className="text-xs text-slate-400">
              Distributed capital breakdown across verified blockchains
            </p>
          </div>

          <div className="h-48 w-full my-4">
            {pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={65}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={COLORS[index % COLORS.length]}
                      />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#0f172a",
                      borderColor: "rgba(255,255,255,0.1)",
                      borderRadius: "0.75rem",
                      color: "#fff",
                      fontSize: "12px",
                    }}
                    formatter={(val: any) => [
                      `$${Number(val).toLocaleString("en-US", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}`,
                      "Value",
                    ]}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-500">
                No active balances to chart
              </div>
            )}
          </div>

          <div className="flex flex-wrap gap-2 justify-center">
            {pieData.map((item, idx) => (
              <div key={item.name} className="flex items-center gap-1.5 text-xs text-slate-300">
                <span
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: COLORS[idx % COLORS.length] }}
                />
                <span className="font-bold">{item.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Active Investments Summary & Recent Transactions Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Active Strategies */}
        <div className="bg-slate-900/60 border border-white/10 rounded-3xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-white">Active Yield Strategies</h2>
            <Link href="/dashboard/investments" className="text-xs text-amber-400 font-semibold hover:underline">
              Manage All →
            </Link>
          </div>

          <div className="space-y-3">
            {investments.slice(0, 3).map((inv) => {
              const startMs = new Date(inv.startDate).getTime();
              const endMs = new Date(inv.endDate).getTime();
              const elapsed = Math.min(Date.now() - startMs, endMs - startMs);
              const progressPct = Math.round(Math.max(5, Math.min(100, (elapsed / (endMs - startMs)) * 100)));

              return (
                <div
                  key={inv.id}
                  className="p-4 rounded-2xl bg-slate-900 border border-white/5 space-y-2"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-white">{inv.planName || "Strategy Plan"}</span>
                    <span className="text-emerald-400 font-bold">
                      +{inv.accruedProfit || "0.00"} {inv.currency} Accrued
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-amber-400 to-emerald-400"
                      style={{ width: `${progressPct}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Principal: {inv.amount} {inv.currency}</span>
                    <span>{progressPct}% Duration Elapsed</span>
                  </div>
                </div>
              );
            })}
            {investments.length === 0 && (
              <div className="p-6 rounded-2xl bg-slate-900 text-center text-xs text-slate-400">
                No active yield strategies.{" "}
                <Link href="/dashboard/plans" className="text-amber-400 font-bold hover:underline">
                  Deploy Capital Now →
                </Link>
              </div>
            )}
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="bg-slate-900/60 border border-white/10 rounded-3xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-white">Recent Account Activity</h2>
            <Link href="/dashboard/wallets" className="text-xs text-amber-400 font-semibold hover:underline">
              Full Ledger →
            </Link>
          </div>

          <div className="space-y-2.5">
            {[...deposits.map((d) => ({ ...d, type: "deposit", desc: `Deposit (${d.network})` })), ...withdrawals.map((w) => ({ ...w, type: "withdrawal", desc: `Withdrawal to ${w.address?.slice(0, 8)}...` }))]
              .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
              .slice(0, 4)
              .map((tx, idx) => {
                const isDep = tx.type === "deposit";
                return (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-900 border border-white/5 text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold ${
                          isDep
                            ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                            : "bg-amber-500/10 text-amber-400 border border-amber-500/30"
                        }`}
                      >
                        {isDep ? "↓" : "↑"}
                      </div>
                      <div>
                        <div className="font-bold text-white">{tx.desc}</div>
                        <div className="text-[10px] text-slate-400 uppercase">
                          Status: {tx.status}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`font-bold ${isDep ? "text-emerald-400" : "text-white"}`}>
                        {isDep ? "+" : "-"}
                        {tx.amount} {tx.currency}
                      </div>
                      <div className="text-[10px] text-slate-500">
                        {new Date(tx.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      </div>
    </div>
  );
}
