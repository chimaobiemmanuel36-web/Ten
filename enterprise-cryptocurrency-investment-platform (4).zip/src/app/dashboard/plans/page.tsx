"use client";

import React, { useEffect, useState } from "react";
import {
  TrendingUp,
  ShieldCheck,
  Award,
  CheckCircle2,
  DollarSign,
  ArrowRight,
  AlertCircle,
  HelpCircle,
  Calculator,
} from "lucide-react";

interface PlanData {
  id: number;
  name: string;
  description: string;
  minInvestment: string;
  maxInvestment: string;
  durationDays: number;
  managementFeePct: string;
  expectedReturnPct: string;
  lockPeriodDays: number;
  compoundingAllowed: boolean;
  earlyWithdrawalAllowed: boolean;
  supportedCurrencies: string[];
  termsText: string;
}

export default function PlansDashboardPage() {
  const [plans, setPlans] = useState<PlanData[]>([]);
  const [wallets, setWallets] = useState<any[]>([]);
  const [selectedPlan, setSelectedPlan] = useState<PlanData | null>(null);
  const [currency, setCurrency] = useState("USDT");
  const [amount, setAmount] = useState("");
  const [calcAmount, setCalcAmount] = useState(1000);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);

  const fetchData = async () => {
    try {
      const [pRes, wRes] = await Promise.all([
        fetch("/api/plans"),
        fetch("/api/wallets"),
      ]);
      const pData = await pRes.json();
      const wData = await wRes.json();
      if (pData.plans) setPlans(pData.plans);
      if (wData.wallets) setWallets(wData.wallets);
    } catch {
      // Quiet
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleInvest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPlan || !amount || parseFloat(amount) <= 0) {
      setError("Please enter a valid investment amount");
      return;
    }

    setError("");
    setSuccess("");
    setLoading(true);

    try {
      const res = await fetch("/api/investments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          planId: selectedPlan.id,
          currency,
          amount,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error || "Failed to deploy capital");
        setLoading(false);
        return;
      }

      setSuccess(
        data.message ||
          "Capital successfully deployed into institutional strategy!"
      );
      setAmount("");
      setSelectedPlan(null);
      await fetchData();
    } catch {
      setError("Network error deploying capital");
    } finally {
      setLoading(false);
    }
  };

  const currentWallet = wallets.find((w) => w.currency === currency);
  const currentBalance = parseFloat(currentWallet?.balance || "0");

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
          <TrendingUp className="w-4 h-4" />
          <span>Institutional Algorithmic Yield Vaults</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white">
          Enterprise Investment Plans
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          Simulated projections are clearly labeled as hypothetical and based on trailing algorithmic backtests. Select a strategy to deploy capital from your wallet balance.
        </p>
      </div>

      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-bold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{success}</span>
        </div>
      )}

      {/* Hypothetical Return Simulator Box */}
      <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold text-white">
          <Calculator className="w-4 h-4 text-amber-400" />
          <span>Hypothetical Yield Simulator</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
          <div>
            <label className="block text-xs text-slate-400 mb-1 font-medium">
              Simulated Capital Amount ($ USD Equivalent)
            </label>
            <input
              type="number"
              value={calcAmount}
              onChange={(e) => setCalcAmount(parseFloat(e.target.value) || 0)}
              className="w-full bg-slate-950 text-white text-base font-bold rounded-xl px-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="md:col-span-2 grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { name: "Apex Genesis Starter", duration: 30, apy: 8.5 },
              { name: "Quantum Alpha Fixed", duration: 90, apy: 18.4 },
              { name: "Solana Growth Engine", duration: 60, apy: 14.2 },
              { name: "Institutional Yield Plus", duration: 180, apy: 36.8 },
            ].map((sim, i) => {
              const totalReturn =
                calcAmount + calcAmount * (sim.apy / 100) * (sim.duration / 365);
              return (
                <div
                  key={i}
                  className="p-3.5 rounded-2xl bg-slate-950 border border-white/5 text-center"
                >
                  <div className="text-[10px] text-slate-400 font-bold truncate">
                    {sim.name}
                  </div>
                  <div className="text-sm font-extrabold text-amber-400 mt-0.5">
                    ${totalReturn.toFixed(2)}
                  </div>
                  <div className="text-[10px] text-slate-500">
                    +{sim.apy}% APY ({sim.duration}d)
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        <div className="text-[10px] text-slate-500 italic">
          *Hypothetical yield simulations assume continuous daily compounding and market neutrality. Past performance does not guarantee future results.
        </div>
      </div>

      {/* Grid of Plans */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {plans.map((p) => {
          const minInv = parseFloat(p.minInvestment);
          const maxInv = parseFloat(p.maxInvestment);

          return (
            <div
              key={p.id}
              className="bg-slate-900/60 border border-white/10 hover:border-amber-400/30 rounded-3xl p-8 flex flex-col justify-between transition-all"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-extrabold text-white">
                    {p.name}
                  </h3>
                  <span className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-xs font-bold text-slate-300">
                    {p.durationDays} Days Lock
                  </span>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed mb-6">
                  {p.description}
                </p>

                <div className="p-4 rounded-2xl bg-slate-950 border border-white/5 mb-6">
                  <div className="text-xs text-slate-400 font-medium">
                    Expected Annual Return
                  </div>
                  <div className="text-3xl font-black text-amber-400">
                    +{p.expectedReturnPct}% APY
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1 italic">
                    *Hypothetical yield projection based on market conditions
                  </div>
                </div>

                <div className="space-y-3 text-xs text-slate-300 mb-6">
                  <div className="flex items-center justify-between py-1.5 border-b border-white/5">
                    <span className="text-slate-400">Min Investment:</span>
                    <span className="font-bold text-white">
                      ${minInv.toLocaleString()} USD
                    </span>
                  </div>
                  <div className="flex items-center justify-between py-1.5 border-b border-white/5">
                    <span className="text-slate-400">Max Allocation:</span>
                    <span className="font-bold text-white">
                      ${maxInv.toLocaleString()} USD
                    </span>
                  </div>
                  <div className="flex items-center justify-between py-1.5 border-b border-white/5">
                    <span className="text-slate-400">Supported Assets:</span>
                    <span className="font-bold text-amber-300">
                      {p.supportedCurrencies?.join(", ") || "USDT, BTC, ETH"}
                    </span>
                  </div>
                  <div className="flex items-center justify-between py-1.5">
                    <span className="text-slate-400">Compounding:</span>
                    <span className="text-emerald-400 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Daily 00:00 UTC
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  setSelectedPlan(p);
                  setCurrency(
                    p.supportedCurrencies?.[0] || "USDT"
                  );
                }}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-slate-950 font-black text-sm shadow-lg hover:scale-[1.02] transition-all flex items-center justify-center gap-2"
              >
                <span>Deploy Capital</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>

      {/* Modal to Deploy Capital */}
      {selectedPlan && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md bg-slate-900 border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <h3 className="text-xl font-black text-white">
                  Deploy to {selectedPlan.name}
                </h3>
                <p className="text-xs text-amber-400 font-bold">
                  +{selectedPlan.expectedReturnPct}% Annualized Yield
                </p>
              </div>
              <button
                onClick={() => setSelectedPlan(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white bg-white/5"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleInvest} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Select Vault Asset
                </label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-full bg-slate-950 text-white text-sm rounded-xl px-4 py-3 border border-white/10 focus:outline-none"
                >
                  {(selectedPlan.supportedCurrencies || ["USDT", "BTC", "ETH", "SOL"]).map(
                    (curr) => (
                      <option key={curr} value={curr}>
                        {curr} Vault Balance
                      </option>
                    )
                  )}
                </select>
                <div className="flex items-center justify-between text-xs text-slate-400 mt-1">
                  <span>Available Balance:</span>
                  <span className="font-bold text-amber-400">
                    {currentBalance.toFixed(6)} {currency}
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Capital Amount ({currency})
                </label>
                <input
                  type="number"
                  step="any"
                  required
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder={`Min ${selectedPlan.minInvestment}`}
                  className="w-full bg-slate-950 text-white text-sm rounded-xl px-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 text-xs text-slate-400 space-y-1">
                <div className="flex justify-between">
                  <span>Lock Period:</span>
                  <span className="font-bold text-white">
                    {selectedPlan.durationDays} Days
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Management Fee:</span>
                  <span className="font-bold text-white">
                    {selectedPlan.managementFeePct}% (Annualized)
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Early Withdrawal Policy:</span>
                  <span className="text-amber-400 font-bold">
                    {selectedPlan.earlyWithdrawalAllowed
                      ? "Allowed with 2% adjustment"
                      : "Locked during duration"}
                  </span>
                </div>
              </div>

              <div className="text-[11px] text-slate-400 italic">
                *Hypothetical yield projections are based on trailing algorithmic backtests. Past performance does not guarantee future results.
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="submit"
                  disabled={loading || currentBalance < (parseFloat(amount) || 0)}
                  className="flex-1 py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-sm shadow-lg hover:scale-105 transition-all disabled:opacity-50"
                >
                  {loading ? "Deploying..." : "Confirm & Deploy Capital"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
