"use client";

import React, { useEffect, useState } from "react";
import {
  Users,
  Copy,
  CheckCircle2,
  Award,
  DollarSign,
  TrendingUp,
  Share2,
} from "lucide-react";

export default function ReferralsDashboardPage() {
  const [data, setData] = useState<any>(null);
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadRef() {
      try {
        const res = await fetch("/api/referrals", { cache: "no-store", headers: { "Cache-Control": "no-cache" } });
        const json = await res.json();
        if (json.success) setData(json);
      } catch {
        // Quiet
      } finally {
        setLoading(false);
      }
    }
    loadRef();
  }, []);

  const handleCopy = () => {
    if (!data?.referralLink) return;
    navigator.clipboard.writeText(data.referralLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const totalUsdt = data?.totalEarned?.USDT || 0;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
          <Users className="w-4 h-4" />
          <span>Multi-Tier Institutional Network</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white">
          Referral Program & Commissions
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          Earn lifetime institutional commissions when referred peers deploy capital into ApexCrypto Enterprise yield vaults.
        </p>
      </div>

      {/* Referral Link & KPI Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-slate-900/80 border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6">
          <div>
            <h2 className="text-xl font-bold text-white">
              Your Institutional Invitation Link
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Share your custom referral code or direct onboarding URL to register new institutional investors.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950 border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="font-mono text-sm text-amber-300 break-all">
              {data?.referralLink || "https://apexcrypto.io/register?ref=APEXUSER"}
            </div>
            <button
              onClick={handleCopy}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-xs shadow-lg hover:scale-105 transition-all flex items-center justify-center gap-2 shrink-0"
            >
              {copied ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copy Invitation URL</span>
                </>
              )}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-white/10">
            <div className="p-4 rounded-2xl bg-slate-950 border border-white/5">
              <div className="text-xs text-slate-400">Referral Code</div>
              <div className="text-lg font-black text-amber-400 mt-1">
                {data?.referralCode || "APEXUSER"}
              </div>
            </div>
            <div className="p-4 rounded-2xl bg-slate-950 border border-white/5">
              <div className="text-xs text-slate-400">Commission Rate</div>
              <div className="text-lg font-black text-emerald-400 mt-1">
                8.00% Tier 1
              </div>
            </div>
            <div className="p-4 rounded-2xl bg-slate-950 border border-white/5">
              <div className="text-xs text-slate-400">Total Earned</div>
              <div className="text-lg font-black text-white mt-1">
                ${totalUsdt.toFixed(2)} USDT
              </div>
            </div>
          </div>
        </div>

        {/* Top Referrers Leaderboard */}
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 space-y-4">
          <div className="flex items-center gap-2 text-sm font-extrabold text-white">
            <Award className="w-4 h-4 text-amber-400" />
            <span>Global Partner Leaderboard</span>
          </div>

          <div className="space-y-3">
            {(data?.leaderboard || []).map((leader: any) => (
              <div
                key={leader.rank}
                className="p-3.5 rounded-2xl bg-slate-950 border border-white/5 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-7 h-7 rounded-xl bg-amber-400/10 border border-amber-400/30 text-amber-400 font-bold flex items-center justify-center">
                    #{leader.rank}
                  </div>
                  <div>
                    <div className="font-bold text-white">{leader.name}</div>
                    <div className="text-[10px] text-slate-400">
                      {leader.referrals} Institutional Referrals
                    </div>
                  </div>
                </div>
                <div className="font-extrabold text-emerald-400">
                  {leader.totalEarned}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Commission Earnings History */}
      <div className="bg-slate-900/60 border border-white/10 rounded-3xl p-6 space-y-4">
        <h3 className="text-lg font-bold text-white">Commission Earnings Ledger</h3>
        <div className="space-y-3">
          {(data?.commissions || []).map((c: any) => (
            <div
              key={c.id}
              className="p-4 rounded-2xl bg-slate-900 border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
            >
              <div>
                <div className="font-bold text-white">
                  Tier {c.level} Referral Commission — {c.referredUserName || c.referredUserEmail || "Network Partner"}
                </div>
                <div className="text-[11px] text-slate-400">
                  Paid directly into your {c.currency} vault balance
                </div>
              </div>
              <div className="text-right">
                <div className="font-black text-emerald-400">
                  +{c.amount} {c.currency}
                </div>
                <div className="text-[10px] text-slate-500">
                  {new Date(c.createdAt).toLocaleDateString()}
                </div>
              </div>
            </div>
          ))}
          {(!data?.commissions || data.commissions.length === 0) && (
            <div className="text-center py-8 text-xs text-slate-500">
              No referral commissions accrued yet. Share your link to start earning.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
