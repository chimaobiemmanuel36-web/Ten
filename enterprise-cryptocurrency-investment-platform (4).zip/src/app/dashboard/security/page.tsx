"use client";

import React, { useState } from "react";
import {
  ShieldAlert,
  ShieldCheck,
  Lock,
  KeyRound,
  Smartphone,
  CheckCircle2,
  AlertCircle,
  Activity,
  UserCheck,
} from "lucide-react";

export default function SecurityDashboardPage() {
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
  const [showSetupModal, setShowSetupModal] = useState(false);
  const [otpInput, setOtpInput] = useState("");
  const [whitelistAddress, setWhitelistAddress] = useState("");
  const [whitelistNetwork, setWhitelistNetwork] = useState("ERC-20");
  const [whitelistedAddresses, setWhitelistedAddresses] = useState([
    { id: 1, address: "0x1234567890abcdef1234567890abcdef12345678", network: "ERC-20", label: "Corporate Ledger #1" },
  ]);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const handleEnable2FA = (e: React.FormEvent) => {
    e.preventDefault();
    if (otpInput.length !== 6) {
      setError("Please enter a valid 6-digit Google Authenticator code");
      return;
    }
    setError("");
    setTwoFactorEnabled(true);
    setShowSetupModal(false);
    setOtpInput("");
    setMessage("Google Authenticator Two-Factor Authentication (2FA) successfully activated!");
  };

  const handleAddWhitelist = (e: React.FormEvent) => {
    e.preventDefault();
    if (!whitelistAddress || whitelistAddress.length < 15) {
      setError("Please provide a valid cryptocurrency wallet address");
      return;
    }
    setError("");
    setWhitelistedAddresses((prev) => [
      ...prev,
      {
        id: Date.now(),
        address: whitelistAddress.trim(),
        network: whitelistNetwork,
        label: "Verified Institutional Destination",
      },
    ]);
    setWhitelistAddress("");
    setMessage("Address successfully added to your MPC Withdrawal Whitelist");
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>ISO-27001 & SOC2 Compliant Vault</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white">
          MPC Security & Account Control
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          Configure multi-factor authentication, withdrawal whitelisting, and inspect security audit logs.
        </p>
      </div>

      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-bold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {message && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {/* Security Status KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-400 uppercase">
              MPC Vault Status
            </div>
            <div className="text-lg font-black text-white mt-0.5">
              95% Cold Storage
            </div>
            <div className="text-[11px] text-emerald-400 font-bold">
              ● Active Air-Gapped Key Shard
            </div>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-400 uppercase">
              Google Authenticator 2FA
            </div>
            <div className="text-lg font-black text-white mt-0.5">
              {twoFactorEnabled ? "Active (Secured)" : "Optional (Recommended)"}
            </div>
            <button
              onClick={() => setShowSetupModal(true)}
              className="text-[11px] text-amber-400 font-bold underline mt-0.5"
            >
              {twoFactorEnabled ? "Manage 2FA Token" : "Enable Google 2FA →"}
            </button>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 flex items-center justify-center">
            <UserCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-bold text-slate-400 uppercase">
              KYC & Compliance
            </div>
            <div className="text-lg font-black text-white mt-0.5">
              Verified Tier-3
            </div>
            <div className="text-[11px] text-slate-400">
              Unlimited institutional deposit & withdrawal
            </div>
          </div>
        </div>
      </div>

      {/* Withdrawal Whitelist Manager */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-slate-900/80 border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6">
          <div>
            <h2 className="text-xl font-bold text-white">
              Withdrawal Whitelist Directory
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Restrict outgoing automated withdrawals exclusively to your pre-verified institutional destination addresses.
            </p>
          </div>

          <div className="space-y-3">
            {whitelistedAddresses.map((w) => (
              <div
                key={w.id}
                className="p-4 rounded-2xl bg-slate-950 border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
              >
                <div>
                  <div className="font-bold text-white flex items-center gap-2">
                    <span>{w.label}</span>
                    <span className="px-2 py-0.5 rounded bg-white/10 text-[10px] text-amber-300">
                      {w.network}
                    </span>
                  </div>
                  <div className="font-mono text-[11px] text-slate-400 mt-0.5 break-all">
                    {w.address}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold">
                    ✓ Verified Whitelist
                  </span>
                </div>
              </div>
            ))}
          </div>

          <form onSubmit={handleAddWhitelist} className="pt-4 border-t border-white/10 space-y-4">
            <h3 className="text-sm font-bold text-white">Add New Whitelisted Address</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <input
                  type="text"
                  required
                  value={whitelistAddress}
                  onChange={(e) => setWhitelistAddress(e.target.value)}
                  placeholder="0x... or bc1q... destination address"
                  className="w-full bg-slate-950 text-white text-xs font-mono rounded-xl px-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400"
                />
              </div>
              <div>
                <select
                  value={whitelistNetwork}
                  onChange={(e) => setWhitelistNetwork(e.target.value)}
                  className="w-full bg-slate-950 text-white text-xs rounded-xl px-4 py-3 border border-white/10 focus:outline-none"
                >
                  <option value="ERC-20">ERC-20 Network</option>
                  <option value="Bitcoin Native">Bitcoin Native</option>
                  <option value="Solana Native">Solana Native</option>
                  <option value="BEP-20 Native">BEP-20 Native</option>
                </select>
              </div>
            </div>
            <button
              type="submit"
              className="px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors"
            >
              + Whitelist Address
            </button>
          </form>
        </div>

        {/* Audit trail */}
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 space-y-4">
          <h3 className="text-lg font-bold text-white">Recent Security Logs</h3>
          <div className="space-y-3 text-xs">
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-white/5 space-y-1">
              <div className="font-bold text-emerald-400">LOGIN_SUCCESS</div>
              <div className="text-[11px] text-slate-400">
                Authorized session established via HTTPS
              </div>
              <div className="text-[10px] text-slate-500">Just now • IP: 127.0.0.1</div>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-white/5 space-y-1">
              <div className="font-bold text-white">MPC_KEY_SHARD_CHECK</div>
              <div className="text-[11px] text-slate-400">
                Air-gapped Zurich & Singapore nodes synced
              </div>
              <div className="text-[10px] text-slate-500">10 mins ago • Automated</div>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-white/5 space-y-1">
              <div className="font-bold text-white">KYC_VERIFIED</div>
              <div className="text-[11px] text-slate-400">
                Tier-3 Institutional compliance approved
              </div>
              <div className="text-[10px] text-slate-500">2 days ago • Compliance Gate</div>
            </div>
          </div>
        </div>
      </div>

      {/* 2FA SETUP MODAL */}
      {showSetupModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md bg-slate-900 border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <h3 className="text-xl font-black text-white">
                  Configure Google Authenticator
                </h3>
                <p className="text-xs text-amber-400 font-bold">
                  Two-Factor Authentication (2FA)
                </p>
              </div>
              <button
                onClick={() => setShowSetupModal(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white bg-white/5"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs text-slate-300">
              <p className="text-slate-400">
                1. Download <span className="font-bold text-white">Google Authenticator</span> or your preferred TOTP app.
              </p>
              <p className="text-slate-400">
                2. Enter your secret recovery key into the app:
              </p>
              <div className="p-3 rounded-xl bg-slate-950 border border-amber-400/40 font-mono text-center font-bold text-amber-300 tracking-wider">
                JBSWY3DPEHPK3PXP
              </div>
              <p className="text-slate-400">
                3. Enter the 6-digit verification code generated by your app below:
              </p>

              <form onSubmit={handleEnable2FA} className="space-y-4">
                <input
                  type="text"
                  maxLength={6}
                  required
                  value={otpInput}
                  onChange={(e) => setOtpInput(e.target.value)}
                  placeholder="123456"
                  className="w-full bg-slate-950 text-white text-center font-mono text-lg tracking-widest rounded-xl py-3 border border-white/10 focus:outline-none focus:border-amber-400"
                />
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-xs shadow-lg hover:scale-105 transition-all"
                >
                  Verify & Activate 2FA
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
