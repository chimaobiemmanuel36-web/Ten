"use client";

import React, { useEffect, useState } from "react";
import {
  HeadphonesIcon,
  MessageSquare,
  Plus,
  Clock,
  CheckCircle2,
  AlertCircle,
  Bot,
  Send,
} from "lucide-react";

export default function SupportDashboardPage() {
  const [tickets, setTickets] = useState<any[]>([]);
  const [subject, setSubject] = useState("");
  const [category, setCategory] = useState("Investment Plans");
  const [priority, setPriority] = useState("medium");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);

  const fetchTickets = async () => {
    try {
      const res = await fetch("/api/support", { cache: "no-store", headers: { "Cache-Control": "no-cache" } });
      const data = await res.json();
      if (data.tickets) setTickets(data.tickets);
    } catch {
      // Quiet
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !message.trim()) {
      setError("Please provide both a ticket subject and details");
      return;
    }
    setError("");
    setSuccess("");
    setLoading(true);

    try {
      const res = await fetch("/api/support", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subject: subject.trim(),
          category,
          priority,
          message: message.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error || "Failed to submit ticket");
      } else {
        setSuccess("Support ticket created! Our institutional concierge desk will respond shortly.");
        setSubject("");
        setMessage("");
        await fetchTickets();
      }
    } catch {
      setError("Network error creating ticket");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
          <HeadphonesIcon className="w-4 h-4" />
          <span>24/7 Global Concierge & VIP Desk</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white">
          Institutional Support & Tickets
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          Open a priority concierge ticket or consult our quantitative AI assistant for immediate answers.
        </p>
      </div>

      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-bold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{success}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left: Create Ticket Form */}
        <div className="lg:col-span-2 bg-slate-900/80 border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6">
          <h2 className="text-xl font-bold text-white">
            Open New Concierge Ticket
          </h2>

          <form onSubmit={handleCreateTicket} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Ticket Subject / Summary
              </label>
              <input
                type="text"
                required
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g., Institutional Wire Verification & Higher Deposit Limits"
                className="w-full bg-slate-950 text-white text-sm rounded-xl px-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Inquiry Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-slate-950 text-white text-xs rounded-xl px-4 py-3 border border-white/10 focus:outline-none"
                >
                  <option value="Investment Plans">Investment Plans & Yields</option>
                  <option value="Deposits & Withdrawals">Deposits & Withdrawals</option>
                  <option value="KYC & Account Limits">KYC & Account Limits</option>
                  <option value="MPC Custody & Security">MPC Custody & Security</option>
                  <option value="Technical Support">Technical Support</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Priority Level
                </label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value)}
                  className="w-full bg-slate-950 text-white text-xs rounded-xl px-4 py-3 border border-white/10 focus:outline-none"
                >
                  <option value="low">Low Priority</option>
                  <option value="medium">Medium Priority</option>
                  <option value="high">High Priority</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Detailed Message
              </label>
              <textarea
                rows={4}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Describe your inquiry or institutional request..."
                className="w-full bg-slate-950 text-white text-sm rounded-xl px-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-slate-950 font-black text-sm shadow-xl hover:scale-[1.02] transition-all disabled:opacity-50"
            >
              {loading ? "Submitting Ticket..." : "Submit Support Ticket"}
            </button>
          </form>
        </div>

        {/* Right: Contact channels */}
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6">
          <h3 className="text-lg font-bold text-white">
            Direct Institutional Desk
          </h3>

          <div className="space-y-4 text-xs text-slate-300">
            <div className="p-4 rounded-2xl bg-slate-950 border border-white/5 space-y-1">
              <div className="text-slate-400">Concierge Helpline:</div>
              <div className="font-bold text-white">+1 (800) 934-8821</div>
              <div className="text-[10px] text-emerald-400 font-bold">● Available 24/7 Global Desk</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-white/5 space-y-1">
              <div className="text-slate-400">Official Institutional Email:</div>
              <div className="font-bold text-amber-300">support@apexcrypto.io</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-white/5 space-y-1">
              <div className="text-slate-400">Telegram Alert Integration:</div>
              <div className="font-bold text-white">@ApexEnterpriseRoom</div>
            </div>
          </div>
        </div>
      </div>

      {/* Tickets List */}
      <div className="bg-slate-900/60 border border-white/10 rounded-3xl p-6 space-y-4">
        <h3 className="text-lg font-bold text-white">Your Support Tickets</h3>
        <div className="space-y-3">
          {tickets.map((t) => (
            <div
              key={t.id}
              className="p-4 rounded-2xl bg-slate-900 border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
            >
              <div>
                <div className="font-bold text-white flex items-center gap-2">
                  <span>#{t.id} • {t.subject}</span>
                  <span className="px-2 py-0.5 rounded bg-white/10 text-[10px] text-amber-300">
                    {t.category}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Priority: {t.priority.toUpperCase()}
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span
                  className={`px-3 py-1 rounded-full font-bold uppercase text-[10px] ${
                    t.status === "resolved"
                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                      : "bg-amber-500/10 text-amber-400 border border-amber-500/30"
                  }`}
                >
                  {t.status}
                </span>
                <span className="text-slate-500 text-[10px]">
                  {new Date(t.createdAt).toLocaleDateString()}
                </span>
              </div>
            </div>
          ))}
          {tickets.length === 0 && (
            <div className="text-center py-8 text-xs text-slate-500">
              No support tickets opened yet
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
