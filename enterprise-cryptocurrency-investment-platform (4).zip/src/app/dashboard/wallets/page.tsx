"use client";

import React, { useEffect, useState } from "react";
import {
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
  ShieldCheck,
  Copy,
  CheckCircle2,
  QrCode as QrIcon,
} from "lucide-react";
import Link from "next/link";
import { QrCode } from "@/components/qr-code";

export default function WalletsDashboardPage() {
  const [wallets, setWallets] = useState<any[]>([]);
  const [selectedWallet, setSelectedWallet] = useState<any | null>(null);
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchWallets = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/wallets", { cache: "no-store", headers: { "Cache-Control": "no-cache" } });
      const data = await res.json();
      if (data.wallets) {
        setWallets(data.wallets);
        setSelectedWallet(data.wallets[0]);
      }
    } catch {
      // Quiet
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWallets();
  }, []);

  const rates: Record<string, number> = {
    BTC: 94820,
    ETH: 3410,
    SOL: 194,
    BNB: 642,
    XRP: 2.38,
    LTC: 118,
    USDT: 1.0,
  };

  const handleCopy = (address: string) => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
            <Wallet className="w-4 h-4" />
            <span>Multi-Currency Asset Vaults</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white">
            Wallet Balances & Deposit Addresses
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Manage your individual cryptocurrency vaults, deposit addresses, and locked allocations.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/dashboard/deposit"
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-slate-950 font-black text-xs shadow-lg hover:scale-105 transition-all flex items-center gap-1.5"
          >
            <ArrowDownLeft className="w-4 h-4" />
            <span>Deposit</span>
          </Link>
          <Link
            href="/dashboard/withdraw"
            className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/10 text-white font-bold text-xs transition-colors flex items-center gap-1.5"
          >
            <ArrowUpRight className="w-4 h-4 text-amber-400" />
            <span>Withdraw</span>
          </Link>
        </div>
      </div>

      {/* Grid of Wallets */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {wallets.map((w) => {
          const bal = parseFloat(w.balance) || 0;
          const lock = parseFloat(w.lockedBalance) || 0;
          const rate = rates[w.currency] || 1;
          const usdVal = bal * rate;
          const isSelected = selectedWallet?.id === w.id;

          return (
            <div
              key={w.id}
              onClick={() => setSelectedWallet(w)}
              className={`rounded-3xl p-6 border transition-all cursor-pointer ${
                isSelected
                  ? "bg-slate-900 border-amber-400/60 shadow-2xl shadow-amber-500/10"
                  : "bg-slate-900/60 border-white/10 hover:border-white/20"
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-white/5 border border-white/10 font-black text-amber-400 flex items-center justify-center text-sm">
                    {w.currency}
                  </div>
                  <div>
                    <div className="font-extrabold text-white text-base">
                      {w.currency} Vault
                    </div>
                    <div className="text-[11px] text-slate-400">
                      100% MPC Offline Custody
                    </div>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold">
                  Active
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-white/5 space-y-2 mb-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Available Balance:</span>
                  <span className="font-black text-white">
                    {bal < 1 ? bal.toFixed(4) : bal.toFixed(2)} {w.currency}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Locked / Pending:</span>
                  <span className="font-bold text-amber-300">
                    {lock < 1 ? lock.toFixed(4) : lock.toFixed(2)} {w.currency}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs pt-1 border-t border-white/5">
                  <span className="text-slate-400">Total USD Value:</span>
                  <span className="font-black text-emerald-400">
                    ${usdVal.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Link
                  href={`/dashboard/deposit?asset=${w.currency}`}
                  className="flex-1 py-2 text-center rounded-xl bg-white/5 hover:bg-amber-400/20 hover:text-amber-300 text-slate-300 text-xs font-bold transition-colors"
                >
                  Deposit
                </Link>
                <Link
                  href={`/dashboard/withdraw?asset=${w.currency}`}
                  className="flex-1 py-2 text-center rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold transition-colors"
                >
                  Withdraw
                </Link>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Wallet Detail QR & Address */}
      {selectedWallet && (
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-center gap-8">
          <div className="shrink-0">
            <QrCode
              value={selectedWallet.depositAddress || "bc1qapex2026"}
              size={180}
              currency={selectedWallet.currency}
            />
          </div>
          <div className="flex-1 space-y-4">
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
              <span>{selectedWallet.currency} Deposit Address (MPC Threshold Secured)</span>
            </div>
            <div className="text-xl font-extrabold text-white">
              {selectedWallet.currency} Institutional Deposit Vault
            </div>
            <div className="p-4 rounded-2xl bg-slate-950 border border-white/10 font-mono text-xs text-amber-300 break-all select-all">
              {selectedWallet.depositAddress || "No deposit address assigned"}
            </div>
            <button
              onClick={() => handleCopy(selectedWallet.depositAddress || "")}
              className="px-6 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-all flex items-center gap-2"
            >
              {copied ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Address Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copy Deposit Address</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
