"use client";

import React, { useEffect, useState } from "react";
import {
  ArrowUpRight,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  Lock,
  Wallet,
  Clock,
  KeyRound,
} from "lucide-react";

interface CoinWithdraw {
  symbol: string;
  name: string;
  network: string;
  minWithdraw: string;
  fee: string;
}

const WITHDRAW_COINS: CoinWithdraw[] = [
  { symbol: "USDT", name: "Tether USD", network: "ERC-20 / Ethereum", minWithdraw: "20 USDT", fee: "0 USDT (Covered by Treasury)" },
  { symbol: "BTC", name: "Bitcoin", network: "Bitcoin Native", minWithdraw: "0.001 BTC", fee: "0.0001 BTC" },
  { symbol: "ETH", name: "Ethereum", network: "ERC-20 Native", minWithdraw: "0.01 ETH", fee: "0.001 ETH" },
  { symbol: "SOL", name: "Solana", network: "Solana Native", minWithdraw: "0.2 SOL", fee: "0 SOL" },
  { symbol: "BNB", name: "Binance Coin", network: "BEP-20 Native", minWithdraw: "0.05 BNB", fee: "0 BNB" },
  { symbol: "XRP", name: "Ripple", network: "XRP Ledger", minWithdraw: "10 XRP", fee: "0 XRP" },
  { symbol: "LTC", name: "Litecoin", network: "Litecoin Native", minWithdraw: "0.1 LTC", fee: "0 LTC" },
];

export default function WithdrawCryptoPage() {
  const [selectedCoin, setSelectedCoin] = useState<CoinWithdraw>(WITHDRAW_COINS[0]);
  const [wallets, setWallets] = useState<any[]>([]);
  const [address, setAddress] = useState("");
  const [amount, setAmount] = useState("");
  const [password, setPassword] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<any[]>([]);

  const fetchWalletsAndHistory = async () => {
    try {
      const [wRes, hRes] = await Promise.all([
        fetch("/api/wallets", { cache: "no-store", headers: { "Cache-Control": "no-cache" } }),
        fetch("/api/withdrawals", { cache: "no-store", headers: { "Cache-Control": "no-cache" } }),
      ]);
      const wData = await wRes.json();
      const hData = await hRes.json();
      if (wData.wallets) setWallets(wData.wallets);
      if (hData.withdrawals) setHistory(hData.withdrawals);
    } catch {
      // Quiet
    }
  };

  useEffect(() => {
    fetchWalletsAndHistory();
  }, []);

  const currentWallet = wallets.find((w) => w.currency === selectedCoin.symbol);
  const availableBal = parseFloat(currentWallet?.balance || "0");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || parseFloat(amount) <= 0 || !address.trim() || !password) {
      setError("Please fill out all withdrawal fields including your account password");
      return;
    }

    if (parseFloat(amount) > availableBal) {
      setError("Withdrawal amount exceeds your available vault balance");
      return;
    }

    setError("");
    setSuccess("");
    setLoading(true);

    try {
      const res = await fetch("/api/withdrawals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currency: selectedCoin.symbol,
          amount,
          address: address.trim(),
          network: selectedCoin.network,
          password,
          otpCode: otpCode || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error || "Withdrawal request failed");
      } else {
        setSuccess(data.message || "Withdrawal request submitted for security screening!");
        setAmount("");
        setAddress("");
        setPassword("");
        setOtpCode("");
        await fetchWalletsAndHistory();
      }
    } catch {
      setError("Network error submitting withdrawal request");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
          <ArrowUpRight className="w-4 h-4" />
          <span>MPC Threshold Security Clearance</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white">
          Withdraw Cryptocurrency
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          Request an automated withdrawal to your external destination address. Requires password authentication.
        </p>
      </div>

      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-bold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{success}</span>
        </div>
      )}

      {/* Asset Selector Tabs */}
      <div className="flex flex-wrap items-center gap-2">
        {WITHDRAW_COINS.map((c) => (
          <button
            key={c.symbol}
            onClick={() => {
              setSelectedCoin(c);
              setError("");
              setSuccess("");
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              selectedCoin.symbol === c.symbol
                ? "bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20"
                : "bg-slate-900/80 hover:bg-slate-900 text-slate-300 border border-white/10"
            }`}
          >
            {c.symbol} • {c.name}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left: Form */}
        <div className="lg:col-span-2 bg-slate-900/80 border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Destination Wallet Address ({selectedCoin.network})
              </label>
              <input
                type="text"
                required
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="0x... or bc1q..."
                className="w-full bg-slate-950 text-white text-sm font-mono rounded-xl px-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-bold text-slate-300 mb-1.5">
                <span>Withdrawal Amount ({selectedCoin.symbol})</span>
                <span className="text-amber-400 cursor-pointer hover:underline" onClick={() => setAmount(String(availableBal))}>
                  Max: {availableBal.toFixed(6)} {selectedCoin.symbol}
                </span>
              </div>
              <input
                type="number"
                step="any"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder={`min ${selectedCoin.minWithdraw}`}
                className="w-full bg-slate-950 text-white text-sm rounded-xl px-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                Confirm Account Password
              </label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password to authorize..."
                className="w-full bg-slate-950 text-white text-sm rounded-xl px-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                2FA Google Authenticator Code <span className="text-slate-500 font-normal">(If enabled)</span>
              </label>
              <input
                type="text"
                maxLength={6}
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value)}
                placeholder="123456"
                className="w-full bg-slate-950 text-white text-sm font-mono tracking-widest rounded-xl px-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200/90 leading-relaxed">
              <span className="font-bold text-amber-300">AML Screening Notice:</span> Withdrawals are screened by automated AML tools. Most transactions broadcast within 15–45 minutes.
            </div>

            <button
              type="submit"
              disabled={loading || availableBal <= 0}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-slate-950 font-black text-sm shadow-xl hover:scale-[1.02] transition-all disabled:opacity-50"
            >
              {loading ? "Submitting Request..." : "Request Crypto Withdrawal"}
            </button>
          </form>
        </div>

        {/* Right: Limits & security */}
        <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
            <ShieldCheck className="w-5 h-5" />
            <span>MPC Security Whitelist</span>
          </div>
          <h3 className="text-lg font-bold text-white">
            Withdrawal Policies
          </h3>
          <div className="space-y-3 text-xs text-slate-300">
            <div className="flex justify-between py-2 border-b border-white/5">
              <span className="text-slate-400">Network Fee:</span>
              <span className="font-bold text-amber-300">{selectedCoin.fee}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-white/5">
              <span className="text-slate-400">Min Withdrawal:</span>
              <span className="font-bold text-white">{selectedCoin.minWithdraw}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-white/5">
              <span className="text-slate-400">Daily Limit:</span>
              <span className="font-bold text-emerald-400">$250,000 USD Equivalent</span>
            </div>
          </div>
        </div>
      </div>

      {/* Withdrawal History */}
      <div className="bg-slate-900/60 border border-white/10 rounded-3xl p-6 space-y-4">
        <h3 className="text-lg font-bold text-white">Recent Withdrawal History</h3>
        <div className="space-y-3">
          {history.map((w) => (
            <div
              key={w.id}
              className="p-4 rounded-2xl bg-slate-900 border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
            >
              <div>
                <div className="font-bold text-white flex items-center gap-2">
                  <span>-{w.amount} {w.currency}</span>
                  <span className="text-slate-500">•</span>
                  <span className="text-slate-400">{w.network}</span>
                </div>
                <div className="font-mono text-[11px] text-slate-400 truncate max-w-sm">
                  To: {w.address}
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span
                  className={`px-3 py-1 rounded-full font-bold uppercase text-[10px] ${
                    w.status === "completed"
                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                      : w.status === "pending"
                      ? "bg-amber-500/10 text-amber-400 border border-amber-500/30"
                      : "bg-rose-500/10 text-rose-400 border border-rose-500/30"
                  }`}
                >
                  {w.status}
                </span>
                <span className="text-slate-500 text-[10px]">
                  {new Date(w.createdAt).toLocaleDateString()}
                </span>
              </div>
            </div>
          ))}
          {history.length === 0 && (
            <div className="text-center py-8 text-xs text-slate-500">
              No withdrawal requests yet
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
