import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { CryptoTicker } from "@/components/crypto-ticker";
import { AiConciergeModal } from "@/components/ai-concierge-modal";
import { ClientAuthInit } from "@/components/client-auth-init";

export const metadata: Metadata = {
  title: "ApexCrypto Enterprise — Institutional Digital Asset Wealth Management & Yield Platform",
  description:
    "Production-ready enterprise cryptocurrency investment and quantitative yield platform. Featuring multi-region MPC Threshold security, delta-neutral yield strategies, zero-slashing Solana MEV staking, and 24/7 global multilingual concierge support.",
  keywords: [
    "cryptocurrency investment",
    "institutional crypto yield",
    "MPC security",
    "bitcoin staking",
    "solana MEV",
    "delta neutral arbitrage",
    "fintech enterprise",
  ],
  authors: [{ name: "ApexCrypto Enterprise Team" }],
};

export const viewport: Viewport = {
  themeColor: "#090d16",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body className="min-h-screen bg-[#090d16] text-slate-100 antialiased selection:bg-amber-400 selection:text-slate-950 flex flex-col">
        <ClientAuthInit />
        <CryptoTicker />
        <Navbar />
        <main className="flex-1 flex flex-col">{children}</main>
        <Footer />
        <AiConciergeModal />
      </body>
    </html>
  );
}
