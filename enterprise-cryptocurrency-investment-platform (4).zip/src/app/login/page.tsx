"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Shield,
  Lock,
  Mail,
  KeyRound,
  ArrowRight,
  AlertCircle,
  CheckCircle2,
  ShieldAlert,
} from "lucide-react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(true);
  const [captchaChecked, setCaptchaChecked] = useState(false);
  const [otpCode, setOtpCode] = useState("");
  const [requires2FA, setRequires2FA] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError("Please enter your email and password");
      return;
    }
    if (!captchaChecked) {
      setError("Please complete the security CAPTCHA check");
      return;
    }

    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email,
          password,
          rememberMe,
          otpCode: requires2FA ? otpCode : undefined,
        }),
      });

      const data = await res.json();

      if (res.status === 401 && data.requires2FA) {
        setRequires2FA(true);
        setLoading(false);
        return;
      }

      if (!res.ok || data.error) {
        setError(data.error || "Authentication failed. Please check your credentials.");
        setLoading(false);
        return;
      }

      if (data.user) {
        try {
          localStorage.setItem("apex_crypto_user", JSON.stringify(data.user));
          localStorage.setItem("apex_crypto_auth", "true");
          if (data.token) {
            localStorage.setItem("apex_crypto_token", data.token);
            document.cookie = `apex_crypto_token=${data.token}; path=/; max-age=2592000; SameSite=Lax`;
            document.cookie = `apex_crypto_session=${data.token}; path=/; max-age=2592000; SameSite=Lax`;
          }
        } catch {
          // ignore
        }
      }

      router.push("/dashboard");
      router.refresh();
      setTimeout(() => {
        if (window.location.pathname !== "/dashboard") {
          window.location.href = "/dashboard";
        }
      }, 350);
    } catch {
      setError("Network error. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 flex items-center justify-center p-4 sm:p-6 bg-gradient-to-b from-slate-950 via-[#0a0f1d] to-slate-950">
      <div className="w-full max-w-md bg-slate-900/80 border border-white/10 rounded-3xl p-8 shadow-2xl backdrop-blur-md space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <Link href="/" className="inline-flex items-center justify-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 font-black shadow-lg">
              <Shield className="w-5 h-5 fill-slate-950" />
            </div>
            <span className="font-extrabold text-xl text-white">
              APEX<span className="text-amber-400">CRYPTO</span>
            </span>
          </Link>
          <h1 className="text-2xl font-black text-white">
            Client Vault Access
          </h1>
          <p className="text-xs text-slate-400">
            Sign in to your institutional wealth management vault
          </p>
        </div>

        {error && (
          <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-semibold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-500" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="client@enterprise.com"
                className="w-full bg-slate-950 text-white text-sm rounded-xl pl-10 pr-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400/50"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-bold text-slate-300">
                Password
              </label>
              <span className="text-xs text-amber-400 hover:underline cursor-pointer">
                Forgot password?
              </span>
            </div>
            <div className="relative">
              <Lock className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-500" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full bg-slate-950 text-white text-sm rounded-xl pl-10 pr-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400/50"
              />
            </div>
          </div>

          {requires2FA && (
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-2 animate-fadeIn">
              <label className="block text-xs font-bold text-amber-300">
                2FA Google Authenticator Code
              </label>
              <div className="relative">
                <KeyRound className="absolute left-3.5 top-3.5 w-4 h-4 text-amber-400" />
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  placeholder="123456"
                  className="w-full bg-slate-950 text-white text-sm font-mono tracking-widest rounded-xl pl-10 pr-4 py-3 border border-amber-400/40 focus:outline-none"
                />
              </div>
              <p className="text-[11px] text-amber-200/80">
                Enter your 6-digit verification code from Google Authenticator.
              </p>
            </div>
          )}

          {/* CAPTCHA Simulation Box */}
          <div
            onClick={() => setCaptchaChecked(!captchaChecked)}
            className={`p-3.5 rounded-xl border flex items-center justify-between cursor-pointer select-none transition-colors ${
              captchaChecked
                ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
                : "bg-slate-950/60 border-white/10 text-slate-400 hover:border-white/20"
            }`}
          >
            <div className="flex items-center gap-3 text-xs font-bold">
              <div
                className={`w-5 h-5 rounded-md flex items-center justify-center border ${
                  captchaChecked
                    ? "bg-emerald-500 border-emerald-500 text-slate-950"
                    : "border-white/20"
                }`}
              >
                {captchaChecked && <CheckCircle2 className="w-4 h-4" />}
              </div>
              <span>I am human (MPC Security CAPTCHA)</span>
            </div>
            <ShieldAlert className="w-4 h-4 text-slate-500" />
          </div>

          {/* Remember Me */}
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <input
              type="checkbox"
              id="rememberMe"
              checked={rememberMe}
              onChange={(e) => setRememberMe(e.target.checked)}
              className="rounded bg-slate-950 border-white/10 text-amber-400 focus:ring-amber-400"
            />
            <label htmlFor="rememberMe" className="cursor-pointer">
              Remember this device for 30 days
            </label>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-slate-950 font-black text-sm shadow-xl shadow-amber-500/20 hover:scale-[1.02] active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? (
              <span>Authenticating Vault...</span>
            ) : (
              <>
                <span>Access Account</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        <div className="text-center text-xs text-slate-400 pt-2 border-t border-white/5">
          New to ApexCrypto Enterprise?{" "}
          <Link
            href="/register"
            className="text-amber-400 font-bold hover:underline"
          >
            Open Institutional Account
          </Link>
        </div>
      </div>
    </div>
  );
}
