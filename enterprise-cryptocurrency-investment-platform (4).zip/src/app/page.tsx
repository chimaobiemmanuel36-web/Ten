"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import {
  ShieldCheck,
  TrendingUp,
  Lock,
  Award,
  ArrowRight,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Zap,
  Globe,
  DollarSign,
  GraduationCap,
  Activity,
  ArrowUpRight,
  HelpCircle,
  Newspaper,
  Mail,
  Send,
  Building2,
  Cpu,
  BarChart3,
  Users,
} from "lucide-react";
import { TradingChart } from "@/components/trading-chart";

interface CoinData {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  sparkline?: number[];
}

interface PlanData {
  id: number;
  name: string;
  description: string;
  minInvestment: string;
  maxInvestment: string;
  durationDays: number;
  expectedReturnPct: string;
  lockPeriodDays: number;
  supportedCurrencies: string[];
  termsText: string;
}

export default function HomePage() {
  const [coins, setCoins] = useState<CoinData[]>([]);
  const [plans, setPlans] = useState<PlanData[]>([]);
  const [news, setNews] = useState<any[]>([]);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [newsletterSuccess, setNewsletterSuccess] = useState(false);
  const [selectedPlanModal, setSelectedPlanModal] = useState<PlanData | null>(null);

  useEffect(() => {
    async function loadData() {
      try {
        const [marketRes, plansRes, newsRes] = await Promise.all([
          fetch("/api/market"),
          fetch("/api/plans"),
          fetch("/api/news"),
        ]);
        const marketData = await marketRes.json();
        const plansData = await plansRes.json();
        const newsData = await newsRes.json();

        if (marketData.coins) setCoins(marketData.coins);
        if (plansData.plans) setPlans(plansData.plans);
        if (newsData.articles) setNews(newsData.articles);
      } catch {
        // Fallbacks automatically handled
      }
    }
    loadData();
  }, []);

  const handleNewsletter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail || !newsletterEmail.includes("@")) return;
    setNewsletterSuccess(true);
    setNewsletterEmail("");
  };

  const faqList = [
    {
      q: "How does ApexCrypto Enterprise generate algorithmic yield?",
      a: "Our quantitative yield engines deploy delta-neutral funding arbitrage across spot and perpetual futures markets, MEV-optimized Solana liquid staking, and institutional cross-exchange liquidity captures. All strategies are designed to capture yield without directional crypto price exposure.",
    },
    {
      q: "What is MPC Threshold Vault security?",
      a: "Multi-Party Computation (MPC) divides private key shares across air-gapped hardware security modules located in Switzerland, Singapore, and New York. No single server or administrator ever holds the complete private key, eliminating single points of failure.",
    },
    {
      q: "What are the minimum deposit and withdrawal limits?",
      a: "We charge 0% deposit fees with zero minimum limit on standard wallet deposits. Institutional investment plans start from as low as $100 equivalent in USDT, BTC, ETH, or SOL.",
    },
    {
      q: "Can I compound my daily accrued returns automatically?",
      a: "Yes. All our enterprise investment plans feature optional daily compounding at 00:00 UTC, which recalculates principal daily to accelerate yield accumulation.",
    },
    {
      q: "How does early withdrawal work during the principal lock period?",
      a: "Most plans permit early withdrawal before the lock period expires. Early exits undergo automated AML review and apply a modest 1.5% to 2.5% early settlement adjustment as detailed in each plan's institutional terms.",
    },
    {
      q: "What cryptocurrencies are supported for deposits and staking?",
      a: "We natively support Bitcoin (BTC), Ethereum (ETH ERC-20), Tether USD (USDT ERC-20), Solana (SOL), Binance Coin (BNB BEP-20), Ripple (XRP Ledger), and Litecoin (LTC).",
    },
  ];

  return (
    <div className="flex flex-col w-full">
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden pt-12 pb-24 lg:pt-20 lg:pb-32 bg-gradient-to-b from-slate-950 via-[#0a0f1d] to-slate-950">
        {/* Glow backdrop effects */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-gradient-to-tr from-amber-500/10 via-amber-400/5 to-emerald-500/10 rounded-full blur-[120px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-4xl mx-auto space-y-6">
            {/* Regulatory pill badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-300 text-xs font-bold tracking-wide uppercase shadow-lg shadow-amber-500/10">
              <Sparkles className="w-3.5 h-3.5 fill-amber-400 animate-pulse" />
              <span>Multi-Region MPC Custody & Institutional Delta-Neutral Yield</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white leading-[1.1]">
              The Standard in{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500">
                Enterprise Digital Asset
              </span>{" "}
              Wealth & Yield.
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-xl text-slate-300 leading-relaxed max-w-3xl mx-auto font-normal">
              Deploy capital into institutional quantitative yield strategies, delta-neutral arbitration vaults, and zero-slashing Solana MEV staking. Backed by Swiss-engineered MPC threshold security.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <Link
                href="/register"
                className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-slate-950 font-black text-base shadow-xl shadow-amber-500/25 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                <span>Open Institutional Account</span>
                <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                href="#plans"
                className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-white/10 text-white font-bold text-base shadow-lg transition-all flex items-center justify-center gap-2"
              >
                <span>Explore Yield Strategies</span>
              </Link>
            </div>

            {/* Hero Quick Statistics Pills */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-12 max-w-4xl mx-auto">
              <div className="glass-card rounded-2xl p-4 text-center">
                <div className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  $4.82B+
                </div>
                <div className="text-xs text-slate-400 mt-0.5">Total Assets Deployed</div>
              </div>
              <div className="glass-card rounded-2xl p-4 text-center">
                <div className="text-2xl sm:text-3xl font-extrabold text-amber-400 tracking-tight">
                  18.4% APY
                </div>
                <div className="text-xs text-slate-400 mt-0.5">Trailing Fixed Yield</div>
              </div>
              <div className="glass-card rounded-2xl p-4 text-center">
                <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400 tracking-tight">
                  95% Offline
                </div>
                <div className="text-xs text-slate-400 mt-0.5">Air-Gapped Cold Vaults</div>
              </div>
              <div className="glass-card rounded-2xl p-4 text-center">
                <div className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  180,000+
                </div>
                <div className="text-xs text-slate-400 mt-0.5">Verified Institutional Users</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. LIVE MARKET OVERVIEW & TRADINGVIEW CHART */}
      <section className="py-16 bg-slate-950 border-t border-white/5 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
            <div>
              <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
                <Activity className="w-4 h-4" />
                <span>Live Oracle Feeds</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
                Real-Time Institutional Market Overview
              </h2>
            </div>
            <div className="flex items-center gap-3">
              <span className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Fear & Greed Index: 78 (Extreme Greed)</span>
              </span>
            </div>
          </div>

          {/* Recharts Live Chart Component */}
          <TradingChart coins={coins} />

          {/* Mini asset summary cards below chart */}
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3 mt-6">
            {coins.map((c) => {
              const isPos = c.change24h >= 0;
              return (
                <div
                  key={c.id}
                  className="bg-slate-900/60 border border-white/5 hover:border-white/20 rounded-2xl p-3.5 transition-all"
                >
                  <div className="flex items-center justify-between text-xs font-bold text-slate-400 mb-1">
                    <span>{c.symbol}</span>
                    <span
                      className={`flex items-center text-[11px] ${
                        isPos ? "text-emerald-400" : "text-rose-400"
                      }`}
                    >
                      {isPos ? "+" : ""}
                      {c.change24h.toFixed(2)}%
                    </span>
                  </div>
                  <div className="text-sm font-extrabold text-white">
                    {c.price < 10
                      ? `$${c.price.toFixed(4)}`
                      : `$${c.price.toLocaleString("en-US", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}`}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 3. WHY CHOOSE US & ENTERPRISE ARCHITECTURE */}
      <section className="py-20 bg-[#0a0f1d] border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white">
              Why Sovereign Funds & Institutions Rely on ApexCrypto
            </h2>
            <p className="text-slate-400 text-sm sm:text-base">
              Engineered with zero compromises on cryptographic security, low-latency execution, and audited transparency.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="glass-card glass-card-hover rounded-3xl p-8 space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-400/10 border border-amber-400/30 text-amber-400 flex items-center justify-center">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white">
                Multi-Region MPC Vaults
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                Key shares are distributed across Switzerland, Singapore, and New York. No single point of failure or centralized key storage.
              </p>
              <div className="pt-2 text-xs font-bold text-amber-400 flex items-center gap-1">
                <span>95% Cold Storage Allocation</span>
              </div>
            </div>

            <div className="glass-card glass-card-hover rounded-3xl p-8 space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-400/10 border border-emerald-400/30 text-emerald-400 flex items-center justify-center">
                <TrendingUp className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white">
                Delta-Neutral Arbitrage
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                Capture perpetual funding rates and cross-exchange arbitrage yields without directional cryptocurrency price volatility.
              </p>
              <div className="pt-2 text-xs font-bold text-emerald-400 flex items-center gap-1">
                <span>8.5% – 36.8% Projected APY</span>
              </div>
            </div>

            <div className="glass-card glass-card-hover rounded-3xl p-8 space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-cyan-400/10 border border-cyan-400/30 text-cyan-400 flex items-center justify-center">
                <Cpu className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white">
                Solana MEV Validator
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                Direct Jito-Solana validator restaking with automated MEV bundle searcher tips and zero-slashing redundancy.
              </p>
              <div className="pt-2 text-xs font-bold text-cyan-400 flex items-center gap-1">
                <span>Sub-second Reward Payouts</span>
              </div>
            </div>

            <div className="glass-card glass-card-hover rounded-3xl p-8 space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-purple-400/10 border border-purple-400/30 text-purple-400 flex items-center justify-center">
                <Award className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white">
                Audited & SOC2 Certified
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                Complete ISO-27001 and SOC2 Type II compliance audits with transparent live smart contract monitoring.
              </p>
              <div className="pt-2 text-xs font-bold text-purple-400 flex items-center gap-1">
                <span>24/7 AML & Compliance Gate</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. INSTITUTIONAL INVESTMENT PLANS SHOWCASE */}
      <section id="plans" className="py-24 bg-slate-950 border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-400/10 text-amber-400 text-xs font-bold uppercase tracking-wider">
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Algorithmic Yield Vaults</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white">
              Institutional Investment Plans
            </h2>
            <p className="text-slate-400 text-sm sm:text-base">
              Select an algorithmic strategy tailored to your liquidity requirements. Simulated projections are clearly labeled as hypothetical and based on backtested market conditions.
            </p>
          </div>

          {/* Grid of Plans */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {plans.map((p) => {
              const minInv = parseFloat(p.minInvestment);
              const maxInv = parseFloat(p.maxInvestment);
              const expectedReturn = parseFloat(p.expectedReturnPct);
              const isPopular =
                p.name.includes("Quantum") || p.name.includes("Solana");

              return (
                <div
                  key={p.id}
                  className={`relative rounded-3xl p-8 flex flex-col justify-between transition-all duration-300 ${
                    isPopular
                      ? "bg-slate-900 border-2 border-amber-400/60 shadow-2xl shadow-amber-500/10"
                      : "bg-slate-900/60 border border-white/10 hover:border-white/20"
                  }`}
                >
                  {isPopular && (
                    <div className="absolute -top-3.5 right-6 px-4 py-1 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-[11px] uppercase tracking-wider shadow-md">
                      Recommended Strategy
                    </div>
                  )}

                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-xl font-extrabold text-white">
                        {p.name}
                      </h3>
                      <span className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-xs font-bold text-slate-300">
                        {p.durationDays} Days Lock
                      </span>
                    </div>

                    <p className="text-xs text-slate-400 leading-relaxed mb-6">
                      {p.description}
                    </p>

                    {/* Yield Highlight */}
                    <div className="p-4 rounded-2xl bg-slate-950 border border-white/5 mb-6">
                      <div className="text-xs text-slate-400 font-medium mb-1">
                        Expected Return (Annualized APY)
                      </div>
                      <div className="text-3xl font-black text-amber-400">
                        +{p.expectedReturnPct}%
                      </div>
                      <div className="text-[10px] text-slate-500 mt-1 italic">
                        *Hypothetical yield projection based on market conditions
                      </div>
                    </div>

                    {/* Specifications list */}
                    <div className="space-y-3 text-xs text-slate-300 mb-6">
                      <div className="flex items-center justify-between py-1.5 border-b border-white/5">
                        <span className="text-slate-400">Min Investment:</span>
                        <span className="font-bold text-white">
                          ${minInv.toLocaleString()} USD
                        </span>
                      </div>
                      <div className="flex items-center justify-between py-1.5 border-b border-white/5">
                        <span className="text-slate-400">Max Allocation:</span>
                        <span className="font-bold text-white">
                          ${maxInv.toLocaleString()} USD
                        </span>
                      </div>
                      <div className="flex items-center justify-between py-1.5 border-b border-white/5">
                        <span className="text-slate-400">Supported Assets:</span>
                        <span className="font-bold text-amber-300">
                          {p.supportedCurrencies?.join(", ") || "USDT, BTC, ETH"}
                        </span>
                      </div>
                      <div className="flex items-center justify-between py-1.5">
                        <span className="text-slate-400">Compounding:</span>
                        <span className="text-emerald-400 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Enabled (Daily 00:00 UTC)
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 space-y-3">
                    <button
                      onClick={() => setSelectedPlanModal(p)}
                      className={`w-full py-3.5 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 ${
                        isPopular
                          ? "bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-slate-950 shadow-lg shadow-amber-500/20 hover:scale-[1.02]"
                          : "bg-white/10 hover:bg-white/20 text-white border border-white/10"
                      }`}
                    >
                      <span>Invest in Strategy</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                    <div className="text-[10px] text-slate-500 text-center leading-normal">
                      Early withdrawal fee: 1.5% - 2.5% during initial lock period.
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 5. SUPPORTED CRYPTOCURRENCIES SECTION */}
      <section className="py-20 bg-[#0a0f1d] border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
                Multi-Chain Supported Assets
              </h2>
              <p className="text-slate-400 text-sm mt-2">
                Deposit, withdraw, and deploy capital across 7 major native blockchains with zero platform deposit fees.
              </p>
            </div>
            <Link
              href="/register"
              className="px-6 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/10 text-white font-semibold text-sm transition-colors w-fit"
            >
              View Full Asset List →
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-4">
            {[
              { symbol: "BTC", name: "Bitcoin", network: "Bitcoin Native", color: "text-amber-400", border: "border-amber-400/20" },
              { symbol: "ETH", name: "Ethereum", network: "ERC-20 Native", color: "text-blue-400", border: "border-blue-400/20" },
              { symbol: "USDT", name: "Tether USD", network: "ERC-20 / Solana", color: "text-emerald-400", border: "border-emerald-400/20" },
              { symbol: "SOL", name: "Solana", network: "Solana Native", color: "text-purple-400", border: "border-purple-400/20" },
              { symbol: "BNB", name: "Binance Coin", network: "BEP-20 Native", color: "text-yellow-400", border: "border-yellow-400/20" },
              { symbol: "XRP", name: "Ripple", network: "XRP Ledger", color: "text-cyan-400", border: "border-cyan-400/20" },
              { symbol: "LTC", name: "Litecoin", network: "Litecoin Native", color: "text-slate-300", border: "border-slate-400/20" },
            ].map((coin, idx) => (
              <div
                key={idx}
                className={`bg-slate-900/60 border ${coin.border} rounded-2xl p-5 text-center flex flex-col items-center justify-center gap-2 hover:bg-slate-900 transition-all`}
              >
                <div className={`text-2xl font-black ${coin.color}`}>
                  {coin.symbol}
                </div>
                <div className="font-bold text-white text-sm">{coin.name}</div>
                <span className="px-2 py-0.5 rounded bg-white/5 text-[10px] text-slate-400 font-medium">
                  {coin.network}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. CRYPTO ACADEMY PREVIEW */}
      <section id="academy" className="py-24 bg-slate-950 border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
                <GraduationCap className="w-3.5 h-3.5" />
                <span>Institutional Knowledge Hub</span>
              </div>
              <h2 className="text-3xl sm:text-5xl font-extrabold text-white">
                Apex Crypto Academy
              </h2>
              <p className="text-slate-400 text-sm sm:text-base max-w-xl mt-2">
                Master quantitative arbitrage, MPC custody engineering, and Solana MEV validator strategies with our comprehensive educational curriculum.
              </p>
            </div>
            <Link
              href="/dashboard/academy"
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 hover:scale-105 transition-all"
            >
              Explore All Lessons →
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-slate-900 border border-white/10 rounded-3xl p-8 flex flex-col justify-between space-y-6">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-bold border border-emerald-500/30">
                    Beginner Level
                  </span>
                  <span className="text-xs text-slate-400">7 Min Read</span>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">
                  Enterprise Digital Asset Custody & Security
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Understand the fundamentals of multi-signature vaults, hardware security modules (HSMs), and cold/hot wallet segregation.
                </p>
              </div>
              <Link
                href="/dashboard/academy"
                className="inline-flex items-center gap-2 text-amber-400 text-xs font-bold hover:underline"
              >
                <span>Read Lesson & Take Quiz</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            <div className="bg-slate-900 border border-white/10 rounded-3xl p-8 flex flex-col justify-between space-y-6">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 text-xs font-bold border border-amber-500/30">
                    Intermediate Level
                  </span>
                  <span className="text-xs text-slate-400">10 Min Read</span>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">
                  Quantitative Arbitrage & Delta-Neutral Yields
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  How institutional funds capture continuous funding rates across spot and perpetual futures markets without directional price risk.
                </p>
              </div>
              <Link
                href="/dashboard/academy"
                className="inline-flex items-center gap-2 text-amber-400 text-xs font-bold hover:underline"
              >
                <span>Read Lesson & Take Quiz</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

            <div className="bg-slate-900 border border-white/10 rounded-3xl p-8 flex flex-col justify-between space-y-6">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="px-3 py-1 rounded-full bg-purple-500/10 text-purple-400 text-xs font-bold border border-purple-500/30">
                    Advanced Level
                  </span>
                  <span className="text-xs text-slate-400">12 Min Read</span>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">
                  Solana MEV, Validator Restaking & Proof-of-History
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Deep dive into Solana's Turbine block propagation and searcher priority bundle capture for high-performance staking APY.
                </p>
              </div>
              <Link
                href="/dashboard/academy"
                className="inline-flex items-center gap-2 text-amber-400 text-xs font-bold hover:underline"
              >
                <span>Read Lesson & Take Quiz</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 7. FAQ ACCORDION SECTION */}
      <section id="faq" className="py-24 bg-[#0a0f1d] border-t border-white/5">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white">
              Frequently Asked Questions
            </h2>
            <p className="text-slate-400 text-sm sm:text-base">
              Clear answers regarding institutional custody, withdrawal policies, and automated algorithmic compounding.
            </p>
          </div>

          <div className="space-y-4">
            {faqList.map((item, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div
                  key={idx}
                  className="bg-slate-900/80 border border-white/10 rounded-2xl overflow-hidden transition-all"
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full flex items-center justify-between px-6 py-5 text-left font-bold text-white hover:text-amber-400 transition-colors"
                  >
                    <span className="text-base">{item.q}</span>
                    {isOpen ? (
                      <ChevronUp className="w-5 h-5 text-amber-400 shrink-0" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-slate-400 shrink-0" />
                    )}
                  </button>
                  {isOpen && (
                    <div className="px-6 pb-6 text-sm text-slate-300 leading-relaxed border-t border-white/5 pt-4">
                      {item.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 8. LATEST CRYPTO NEWS & RESEARCH */}
      <section className="py-20 bg-slate-950 border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
                <Newspaper className="w-4 h-4" />
                <span>Market Intelligence</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
                Latest Institutional Crypto News
              </h2>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {(news.length > 0
              ? news
              : [
                  {
                    id: 1,
                    title: "ApexCrypto Expands Institutional Treasury Custody Architecture with Multi-Region MPC",
                    category: "Platform News",
                    excerpt: "ApexCrypto Enterprise completes ISO-27001 and SOC2 Type II compliance audit while deploying distributed key management.",
                    source: "ApexCrypto Official",
                  },
                  {
                    id: 2,
                    title: "Global Crypto Institutional Inflows Hit Record $14.8 Billion in Q1 2026",
                    category: "Market Insights",
                    excerpt: "Spot Bitcoin and Ethereum ETP products alongside institutional yield funds lead the surge as sovereign wealth funds allocate to digital assets.",
                    source: "Bloomberg Digital Assets",
                  },
                  {
                    id: 3,
                    title: "Solana TVL Surpasses $8 Billion as Liquid Restaking Accelerates",
                    category: "DeFi & Ecosystem",
                    excerpt: "High-throughput DeFi protocols on Solana see massive liquidity growth driven by automated MEV-capturing validator staking pools.",
                    source: "CoinDesk Research",
                  },
                ]
            ).slice(0, 3).map((article: any) => (
              <div
                key={article.id}
                className="bg-slate-900/70 border border-white/10 rounded-3xl p-6 flex flex-col justify-between space-y-4 hover:border-white/20 transition-all"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-amber-400 font-bold mb-3">
                    <span>{article.category || "Industry News"}</span>
                    <span className="text-slate-500">{article.source || "Research"}</span>
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2 line-clamp-2">
                    {article.title}
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed line-clamp-3">
                    {article.excerpt}
                  </p>
                </div>
                <div className="pt-2">
                  <span className="text-xs text-amber-400 font-semibold hover:underline cursor-pointer">
                    Read Full Analysis →
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 9. NEWSLETTER SUBSCRIPTION & CONTACT CTA */}
      <section className="py-20 bg-gradient-to-b from-slate-950 to-[#0c1221] border-t border-white/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <div className="w-14 h-14 rounded-2xl bg-amber-400/10 border border-amber-400/30 text-amber-400 flex items-center justify-center mx-auto">
            <Mail className="w-7 h-7" />
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white">
            Institutional Market Research & Alpha Newsletter
          </h2>
          <p className="text-slate-300 text-sm sm:text-base max-w-xl mx-auto">
            Receive daily quantitative arbitrage yield insights, regulatory updates, and early notifications on new enterprise vault launches.
          </p>

          <form
            onSubmit={handleNewsletter}
            className="flex flex-col sm:flex-row items-center justify-center gap-3 max-w-md mx-auto pt-4"
          >
            <input
              type="email"
              required
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              placeholder="Enter institutional email address..."
              className="w-full sm:flex-1 bg-slate-900 text-white text-sm rounded-2xl px-5 py-4 border border-white/10 focus:outline-none focus:border-amber-400/50"
            />
            <button
              type="submit"
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-slate-950 font-extrabold text-sm shadow-lg shadow-amber-500/20 hover:scale-105 transition-all flex items-center justify-center gap-2"
            >
              <span>Subscribe</span>
              <Send className="w-4 h-4" />
            </button>
          </form>

          {newsletterSuccess && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold max-w-md mx-auto">
              ✓ Successfully subscribed! Please check your inbox to confirm your institutional registration.
            </div>
          )}
        </div>
      </section>

      {/* INVESTMENT PLAN DETAIL MODAL */}
      {selectedPlanModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-lg bg-slate-900 border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <h3 className="text-2xl font-black text-white">
                  {selectedPlanModal.name}
                </h3>
                <p className="text-xs text-amber-400 font-bold mt-0.5">
                  Institutional Yield Vault Strategy
                </p>
              </div>
              <button
                onClick={() => setSelectedPlanModal(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-white bg-white/5"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs sm:text-sm text-slate-300">
              <p className="text-slate-400 leading-relaxed">
                {selectedPlanModal.description}
              </p>
              <div className="p-4 rounded-2xl bg-slate-950 border border-white/10 flex items-center justify-between">
                <div>
                  <div className="text-xs text-slate-400">Expected Annual Return</div>
                  <div className="text-3xl font-black text-amber-400">
                    +{selectedPlanModal.expectedReturnPct}% APY
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-slate-400">Lock Period</div>
                  <div className="text-lg font-bold text-white">
                    {selectedPlanModal.durationDays} Days
                  </div>
                </div>
              </div>

              <div className="text-xs text-slate-400 bg-amber-500/10 border border-amber-500/20 p-3.5 rounded-xl">
                <span className="font-bold text-amber-300">Terms & Disclaimer:</span>{" "}
                {selectedPlanModal.termsText}
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <Link
                href="/register"
                onClick={() => setSelectedPlanModal(null)}
                className="flex-1 py-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-center shadow-lg hover:scale-105 transition-all"
              >
                Deploy Capital Now
              </Link>
              <button
                onClick={() => setSelectedPlanModal(null)}
                className="px-6 py-4 rounded-xl bg-slate-800 text-white font-semibold hover:bg-slate-700 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
