"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Shield,
  Lock,
  Mail,
  User,
  Gift,
  ArrowRight,
  AlertCircle,
  CheckCircle2,
} from "lucide-react";

export default function RegisterPage() {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [referralCode, setReferralCode] = useState("");
  const [agreeTerms, setAgreeTerms] = useState(true);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  // Password strength meter calculation
  const getStrength = (pwd: string) => {
    let score = 0;
    if (pwd.length >= 8) score++;
    if (pwd.length >= 12) score++;
    if (/[A-Z]/.test(pwd)) score++;
    if (/[0-9]/.test(pwd)) score++;
    if (/[^A-Za-z0-9]/.test(pwd)) score++;

    if (score <= 1)
      return { score: 1, label: "Weak", color: "bg-red-500", text: "text-red-400" };
    if (score === 2)
      return { score: 2, label: "Fair", color: "bg-amber-500", text: "text-amber-400" };
    if (score === 3)
      return { score: 3, label: "Good", color: "bg-yellow-400", text: "text-yellow-400" };
    if (score === 4)
      return { score: 4, label: "Strong", color: "bg-emerald-400", text: "text-emerald-400" };
    return {
      score: 5,
      label: "Military Grade",
      color: "bg-emerald-500",
      text: "text-emerald-300 font-bold",
    };
  };

  const strength = getStrength(password);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !email || !password) {
      setError("Please complete all required fields");
      return;
    }
    if (!agreeTerms) {
      setError("You must agree to the Institutional Terms & Conditions");
      return;
    }
    if (strength.score < 2) {
      setError("Please use a stronger password (min 8 chars, letters and numbers)");
      return;
    }

    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName,
          email,
          password,
          referralCode,
          agreeTerms,
        }),
      });

      const data = await res.json();

      if (!res.ok || data.error) {
        setError(data.error || "Registration failed. Please try again.");
        setLoading(false);
        return;
      }

      if (data.user) {
        try {
          localStorage.setItem("apex_crypto_user", JSON.stringify(data.user));
          localStorage.setItem("apex_crypto_auth", "true");
          if (data.token) {
            localStorage.setItem("apex_crypto_token", data.token);
            document.cookie = `apex_crypto_token=${data.token}; path=/; max-age=2592000; SameSite=Lax`;
            document.cookie = `apex_crypto_session=${data.token}; path=/; max-age=2592000; SameSite=Lax`;
          }
        } catch {
          // ignore
        }
      }

      router.push("/dashboard");
      router.refresh();
      setTimeout(() => {
        if (window.location.pathname !== "/dashboard") {
          window.location.href = "/dashboard";
        }
      }, 350);
    } catch {
      setError("Network error. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 flex items-center justify-center p-4 sm:p-6 bg-gradient-to-b from-slate-950 via-[#0a0f1d] to-slate-950">
      <div className="w-full max-w-md bg-slate-900/80 border border-white/10 rounded-3xl p-8 shadow-2xl backdrop-blur-md space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <Link href="/" className="inline-flex items-center justify-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 font-black shadow-lg">
              <Shield className="w-5 h-5 fill-slate-950" />
            </div>
            <span className="font-extrabold text-xl text-white">
              APEX<span className="text-amber-400">CRYPTO</span>
            </span>
          </Link>
          <h1 className="text-2xl font-black text-white">
            Open Vault Account
          </h1>
          <p className="text-xs text-slate-400">
            Institutional custody & quantitative yield onboarding
          </p>
        </div>

        {error && (
          <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-semibold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleRegister} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              Full Legal Name / Entity Name
            </label>
            <div className="relative">
              <User className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-500" />
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Alexander Vance"
                className="w-full bg-slate-950 text-white text-sm rounded-xl pl-10 pr-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400/50"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              Institutional Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-500" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="alexander@enterprise.io"
                className="w-full bg-slate-950 text-white text-sm rounded-xl pl-10 pr-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400/50"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              Secure Master Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-500" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Min 8 characters..."
                className="w-full bg-slate-950 text-white text-sm rounded-xl pl-10 pr-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400/50"
              />
            </div>

            {/* Password Strength Meter */}
            {password.length > 0 && (
              <div className="mt-2 space-y-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">Security Strength:</span>
                  <span className={strength.text}>{strength.label}</span>
                </div>
                <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden flex gap-1">
                  {[1, 2, 3, 4, 5].map((lvl) => (
                    <div
                      key={lvl}
                      className={`flex-1 h-full transition-colors ${
                        lvl <= strength.score ? strength.color : "bg-white/5"
                      }`}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              Referral Code <span className="text-slate-500 font-normal">(Optional)</span>
            </label>
            <div className="relative">
              <Gift className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-500" />
              <input
                type="text"
                value={referralCode}
                onChange={(e) => setReferralCode(e.target.value)}
                placeholder="APEX2004ADMIN"
                className="w-full bg-slate-950 text-white text-sm rounded-xl pl-10 pr-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400/50"
              />
            </div>
          </div>

          <div className="flex items-start gap-2.5 text-xs text-slate-400 pt-1">
            <input
              type="checkbox"
              id="terms"
              checked={agreeTerms}
              onChange={(e) => setAgreeTerms(e.target.checked)}
              className="mt-0.5 rounded bg-slate-950 border-white/10 text-amber-400 focus:ring-amber-400"
            />
            <label htmlFor="terms" className="cursor-pointer leading-relaxed">
              I certify that I am an accredited or institutional investor and agree to the{" "}
              <span className="text-amber-400 font-bold underline">
                Terms of Service
              </span>{" "}
              and{" "}
              <span className="text-amber-400 font-bold underline">
                MPC Custody Policy
              </span>
              .
            </label>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-slate-950 font-black text-sm shadow-xl shadow-amber-500/20 hover:scale-[1.02] active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? (
              <span>Creating MPC Vault...</span>
            ) : (
              <>
                <span>Open Vault Account</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        <div className="text-center text-xs text-slate-400 pt-2 border-t border-white/5">
          Already have an account?{" "}
          <Link
            href="/login"
            className="text-amber-400 font-bold hover:underline"
          >
            Sign In to Vault
          </Link>
        </div>
      </div>
    </div>
  );
}
