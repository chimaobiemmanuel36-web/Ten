"use client";

import React, { useState } from "react";
import {
  MessageSquare,
  X,
  Send,
  Bot,
  Sparkles,
  ShieldCheck,
} from "lucide-react";

interface ChatMessage {
  id: string;
  sender: "user" | "ai";
  text: string;
  timestamp: string;
}

export function AiConciergeModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "init-1",
      sender: "ai",
      text: "Welcome to ApexCrypto Enterprise Concierge. I am your AI quantitative & institutional support specialist. Ask me anything about our 7 investment plans, MPC threshold vaults, multi-currency deposit QR addresses, or withdrawal whitelisting.",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || loading) return;

    const userText = input.trim();
    const newMsg: ChatMessage = {
      id: "u-" + Date.now(),
      sender: "user",
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, newMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/support", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: "ai-assistant", query: userText }),
      });
      const data = await res.json();

      const aiMsg: ChatMessage = {
        id: "ai-" + Date.now(),
        sender: "ai",
        text:
          data.answer ||
          "Thank you for contacting ApexCrypto Enterprise. Our human institutional desk is also available 24/7 via the Support portal.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch {
      const errorMsg: ChatMessage = {
        id: "ai-err-" + Date.now(),
        sender: "ai",
        text: "I am currently processing high transaction volume. Please visit our Knowledge Base or open an urgent support ticket under Dashboard → Support.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const sampleQuestions = [
    "What are the 7 investment plans?",
    "How do I deposit BTC or USDT?",
    "How does MPC multi-sig security work?",
    "What is the early withdrawal policy?",
  ];

  return (
    <>
      {/* Floating button */}
      <div className="fixed bottom-6 right-6 z-50">
        <button
          onClick={() => setIsOpen(!isOpen)}
          aria-label="Open Apex AI Concierge Support"
          className="group relative flex items-center gap-3 px-5 py-3.5 rounded-full bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-slate-950 font-bold shadow-2xl shadow-amber-500/30 hover:shadow-amber-500/50 hover:scale-105 active:scale-95 transition-all duration-300"
        >
          <div className="w-7 h-7 rounded-full bg-slate-950 text-amber-400 flex items-center justify-center">
            <Bot className="w-4 h-4" />
          </div>
          <span className="hidden sm:inline">Apex AI Concierge</span>
          <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full border-2 border-slate-950 animate-pulse" />
        </button>
      </div>

      {/* Modal Dialog */}
      {isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-end sm:justify-center p-4 sm:p-6 bg-slate-950/70 backdrop-blur-sm transition-opacity"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full sm:w-[440px] max-h-[620px] bg-slate-900 border border-white/10 rounded-3xl shadow-2xl overflow-hidden flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 bg-slate-950 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-400/20 text-amber-400 flex items-center justify-center border border-amber-400/30">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5 font-bold text-white text-sm">
                    <span>Apex AI Concierge</span>
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  </div>
                  <div className="text-xs text-slate-400 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-emerald-400" />
                    <span>MPC Verified Support Desk</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Message window */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[360px] no-scrollbar">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex flex-col ${
                    m.sender === "user" ? "items-end" : "items-start"
                  }`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-xs sm:text-sm leading-relaxed ${
                      m.sender === "user"
                        ? "bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-medium rounded-br-none"
                        : "bg-slate-800 text-slate-200 border border-white/5 rounded-bl-none shadow-sm"
                    }`}
                  >
                    {m.text}
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 px-1">
                    {m.timestamp}
                  </span>
                </div>
              ))}
              {loading && (
                <div className="flex items-center gap-2 text-slate-400 text-xs bg-slate-800/50 p-3 rounded-2xl w-fit">
                  <div className="w-2 h-2 bg-amber-400 rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-amber-400 rounded-full animate-bounce delay-150" />
                  <div className="w-2 h-2 bg-amber-400 rounded-full animate-bounce delay-300" />
                  <span>Apex quantitative AI is analyzing...</span>
                </div>
              )}
            </div>

            {/* Quick Questions */}
            <div className="px-4 py-2 bg-slate-950/50 border-t border-white/5 flex gap-1.5 overflow-x-auto no-scrollbar">
              {sampleQuestions.map((sq, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setInput(sq);
                  }}
                  className="px-2.5 py-1 text-[11px] bg-white/5 hover:bg-amber-400/10 hover:text-amber-300 border border-white/5 rounded-full text-slate-300 whitespace-nowrap transition-colors"
                >
                  {sq}
                </button>
              ))}
            </div>

            {/* Input Form */}
            <form
              onSubmit={handleSend}
              className="p-3 bg-slate-950 border-t border-white/10 flex items-center gap-2"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about deposits, yield plans, MPC vaults..."
                className="flex-1 bg-slate-900 text-white text-xs sm:text-sm rounded-xl px-4 py-3 border border-white/10 focus:outline-none focus:border-amber-400/50 placeholder:text-slate-500"
              />
              <button
                type="submit"
                disabled={!input.trim() || loading}
                className="p-3 rounded-xl bg-amber-500 text-slate-950 hover:bg-amber-400 disabled:opacity-50 transition-colors"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
