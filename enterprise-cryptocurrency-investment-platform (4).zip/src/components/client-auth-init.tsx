"use client";

import { useEffect } from "react";

export function ClientAuthInit() {
  useEffect(() => {
    if (typeof window === "undefined") return;

    const originalFetch = window.fetch;
    window.fetch = async function (input, init = {}) {
      let url = "";
      if (typeof input === "string") {
        url = input;
      } else if (input instanceof URL) {
        url = input.toString();
      } else if (input && typeof (input as any).url === "string") {
        url = (input as any).url;
      }

      if (url && url.startsWith("/api/")) {
        try {
          const token = localStorage.getItem("apex_crypto_token");
          const headers = new Headers(init.headers || {});
          if (token) {
            if (!headers.has("Authorization") && !headers.has("authorization")) {
              headers.set("Authorization", `Bearer ${token}`);
            }
            if (!headers.has("x-auth-token")) {
              headers.set("x-auth-token", token);
            }
          }
          init = {
            ...init,
            credentials: "include",
            headers,
          };
        } catch {
          // ignore localStorage access errors
        }
      }
      return originalFetch.call(this, input, init);
    };
  }, []);

  return null;
}
