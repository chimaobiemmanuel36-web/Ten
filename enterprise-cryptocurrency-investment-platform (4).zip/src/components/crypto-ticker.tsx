"use client";

import React, { useEffect, useState } from "react";
import { ArrowUpRight, ArrowDownRight, Activity } from "lucide-react";

interface CoinTicker {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change24h: number;
}

export function CryptoTicker() {
  const [coins, setCoins] = useState<CoinTicker[]>([]);

  useEffect(() => {
    async function loadTicker() {
      try {
        const res = await fetch("/api/market");
        const data = await res.json();
        if (data.coins) {
          setCoins(data.coins);
        }
      } catch {
        // Fallback handled quietly
      }
    }
    loadTicker();
    const interval = setInterval(loadTicker, 15000);
    return () => clearInterval(interval);
  }, []);

  if (coins.length === 0) {
    return null;
  }

  return (
    <div className="w-full bg-slate-950/90 border-b border-white/5 backdrop-blur-md overflow-hidden py-2 px-4 text-xs select-none">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-6">
        <div className="hidden md:flex items-center gap-2 text-amber-400/90 font-medium whitespace-nowrap">
          <Activity className="w-3.5 h-3.5 animate-pulse" />
          <span>LIVE APEX ORACLE</span>
        </div>
        <div className="flex items-center gap-8 overflow-x-auto no-scrollbar py-0.5">
          {coins.map((c) => {
            const isPos = c.change24h >= 0;
            const formattedPrice =
              c.price < 10
                ? `$${c.price.toFixed(4)}`
                : `$${c.price.toLocaleString("en-US", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}`;
            return (
              <div
                key={c.id}
                className="flex items-center gap-2 whitespace-nowrap shrink-0"
              >
                <span className="font-bold text-slate-300">{c.symbol}</span>
                <span className="text-white font-mono">{formattedPrice}</span>
                <span
                  className={`flex items-center font-medium ${
                    isPos ? "text-emerald-400" : "text-rose-400"
                  }`}
                >
                  {isPos ? (
                    <ArrowUpRight className="w-3 h-3" />
                  ) : (
                    <ArrowDownRight className="w-3 h-3" />
                  )}
                  {Math.abs(c.change24h).toFixed(2)}%
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
