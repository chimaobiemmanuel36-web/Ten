"use client";

import React from "react";
import Link from "next/link";
import {
  Shield,
  ShieldCheck,
  Lock,
  Award,
  Globe,
  Send,
  ExternalLink,
} from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-white/10 text-slate-400 text-sm">
      {/* Top Banner - Security & Regulatory Certification */}
      <div className="border-b border-white/5 bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-3">
              <ShieldCheck className="w-8 h-8 text-emerald-400 shrink-0" />
              <div>
                <div className="font-bold text-white text-xs">ISO-27001 Certified</div>
                <div className="text-[11px] text-slate-500">Information Security Standard</div>
              </div>
            </div>
            <div className="flex items-center justify-center md:justify-start gap-3">
              <Lock className="w-8 h-8 text-amber-400 shrink-0" />
              <div>
                <div className="font-bold text-white text-xs">MPC Threshold Vaults</div>
                <div className="text-[11px] text-slate-500">95% Air-gapped Cold Storage</div>
              </div>
            </div>
            <div className="flex items-center justify-center md:justify-start gap-3">
              <Award className="w-8 h-8 text-cyan-400 shrink-0" />
              <div>
                <div className="font-bold text-white text-xs">SOC2 Type II Audited</div>
                <div className="text-[11px] text-slate-500">Enterprise Compliance</div>
              </div>
            </div>
            <div className="flex items-center justify-center md:justify-start gap-3">
              <Globe className="w-8 h-8 text-violet-400 shrink-0" />
              <div>
                <div className="font-bold text-white text-xs">Global Multilingual Desk</div>
                <div className="text-[11px] text-slate-500">24/7 Dedicated Concierge</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-10">
          {/* Col 1: Brand Info */}
          <div className="md:col-span-2 space-y-4">
            <Link href="/" className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 font-black">
                <Shield className="w-5 h-5 fill-slate-950" />
              </div>
              <span className="font-extrabold text-lg tracking-tight text-white">
                APEX<span className="text-amber-400">CRYPTO</span>
              </span>
            </Link>
            <p className="text-xs leading-relaxed text-slate-400 max-w-sm">
              ApexCrypto Enterprise is a premier institutional cryptocurrency wealth management and delta-neutral quantitative yield platform. Backed by multi-region MPC custody and zero-slashing validator staking.
            </p>
            <div className="flex items-center gap-2 pt-2">
              <span className="px-2.5 py-1 rounded-md bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-semibold">
                ● Systems 100% Operational
              </span>
              <span className="px-2.5 py-1 rounded-md bg-white/5 border border-white/10 text-slate-300 text-[11px]">
                v2026.4 Enterprise
              </span>
            </div>
          </div>

          {/* Col 2: Institutional Products */}
          <div>
            <h4 className="text-white font-bold text-xs uppercase tracking-wider mb-4">
              Products & Yield
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <Link href="/#plans" className="hover:text-amber-400 transition-colors">
                  Apex Genesis Starter
                </Link>
              </li>
              <li>
                <Link href="/#plans" className="hover:text-amber-400 transition-colors">
                  Quantum Alpha Fixed
                </Link>
              </li>
              <li>
                <Link href="/#plans" className="hover:text-amber-400 transition-colors">
                  Solana Growth Engine
                </Link>
              </li>
              <li>
                <Link href="/#plans" className="hover:text-amber-400 transition-colors">
                  Institutional Yield Plus
                </Link>
              </li>
              <li>
                <Link href="/#plans" className="hover:text-amber-400 transition-colors">
                  DeFi Liquidity Vault
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 3: Supported Currencies */}
          <div>
            <h4 className="text-white font-bold text-xs uppercase tracking-wider mb-4">
              Supported Assets
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                <span>Bitcoin (BTC Native)</span>
              </li>
              <li className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
                <span>Ethereum (ETH ERC-20)</span>
              </li>
              <li className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span>Tether USD (USDT ERC-20)</span>
              </li>
              <li className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                <span>Solana (SOL Native)</span>
              </li>
              <li className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-yellow-400" />
                <span>Binance Coin (BNB BEP-20)</span>
              </li>
              <li className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                <span>Ripple (XRP Ledger)</span>
              </li>
              <li className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-slate-300" />
                <span>Litecoin (LTC Native)</span>
              </li>
            </ul>
          </div>

          {/* Col 4: Crypto Academy & Legal */}
          <div>
            <h4 className="text-white font-bold text-xs uppercase tracking-wider mb-4">
              Academy & Legal
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <Link href="/#academy" className="hover:text-amber-400 transition-colors">
                  Crypto Academy Curriculum
                </Link>
              </li>
              <li>
                <Link href="/#security" className="hover:text-amber-400 transition-colors">
                  MPC Custody Whitepaper
                </Link>
              </li>
              <li>
                <Link href="/#faq" className="hover:text-amber-400 transition-colors">
                  Regulatory Compliance
                </Link>
              </li>
              <li>
                <Link href="/#faq" className="hover:text-amber-400 transition-colors">
                  Terms of Service & Privacy
                </Link>
              </li>
              <li>
                <Link href="/login" className="hover:text-amber-400 transition-colors">
                  Client Portal Access
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Disclaimer box */}
        <div className="mt-10 p-4 rounded-2xl bg-slate-900/60 border border-white/5 text-[11px] text-slate-400 leading-relaxed">
          <span className="text-amber-400 font-bold">Regulatory & Risk Disclaimer:</span> Cryptocurrency investments and yield strategies involve inherent market risks. Hypothetical simulated projections and backtested annual percentage rates (APY) are provided for educational and analytical purposes and do not guarantee future returns. Digital assets are held in institutional multi-signature MPC vaults with automated AML screening.
        </div>
      </div>

      {/* Bottom Copyright bar */}
      <div className="border-t border-white/5 bg-slate-950/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            © 2026 ApexCrypto Enterprise. All rights reserved.
          </div>
          <div className="flex items-center gap-6">
            <span className="hover:text-slate-300 transition-colors cursor-pointer">
              Privacy Policy
            </span>
            <span className="hover:text-slate-300 transition-colors cursor-pointer">
              Terms & Conditions
            </span>
            <span className="hover:text-slate-300 transition-colors cursor-pointer">
              Security Disclosures
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
