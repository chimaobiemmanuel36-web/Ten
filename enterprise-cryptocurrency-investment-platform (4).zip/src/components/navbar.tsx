"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Shield,
  TrendingUp,
  GraduationCap,
  Menu,
  X,
  LogOut,
  User,
  Zap,
  Lock,
  Wallet,
  LayoutDashboard,
  ChevronRight,
} from "lucide-react";

export function Navbar() {
  const [user, setUser] = useState<any>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    try {
      const stored = localStorage.getItem("apex_crypto_user");
      if (stored) {
        setUser(JSON.parse(stored));
      }
    } catch {}

    async function checkUser() {
      try {
        const res = await fetch("/api/auth/me", {
          cache: "no-store",
          credentials: "include",
          headers: { "Cache-Control": "no-cache" },
        });
        const data = await res.json();
        if (data && data.user) {
          setUser(data.user);
          try {
            localStorage.setItem("apex_crypto_user", JSON.stringify(data.user));
          } catch {}
        } else if (res.status === 401) {
          const hasToken = localStorage.getItem("apex_crypto_token");
          if (!hasToken) {
            setUser(null);
            try {
              localStorage.removeItem("apex_crypto_user");
              localStorage.removeItem("apex_crypto_auth");
            } catch {}
          }
        }
      } catch {
        // Keep local state if transient network error
      }
    }
    checkUser();

    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [pathname]);

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      localStorage.removeItem("apex_crypto_user");
      localStorage.removeItem("apex_crypto_auth");
    } catch {}
    setUser(null);
    router.push("/");
    router.refresh();
  };

  const isAdmin =
    user && (user.role === "admin" || user.role === "superadmin");

  // Hide Navbar on full-screen login / register if desired, but let's keep it clean
  const isAuthPage = pathname === "/login" || pathname === "/register";

  return (
    <header
      className={`sticky top-0 z-40 w-full transition-all duration-300 ${
        scrolled
          ? "bg-slate-950/90 backdrop-blur-md border-b border-white/10 shadow-2xl"
          : "bg-slate-950/70 backdrop-blur-sm border-b border-white/5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link
            href="/"
            className="flex items-center gap-3 group focus:outline-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-600 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-amber-500/20 group-hover:scale-105 transition-transform">
              <Shield className="w-6 h-6 fill-slate-950" />
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold text-xl tracking-tight text-white flex items-center gap-1.5">
                APEX<span className="text-amber-400">CRYPTO</span>
              </span>
              <span className="text-[10px] uppercase tracking-widest text-slate-400 font-semibold">
                Enterprise Yield Vault
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-300">
            <Link
              href="/"
              className={`hover:text-amber-400 transition-colors ${
                pathname === "/" ? "text-amber-400 font-semibold" : ""
              }`}
            >
              Overview
            </Link>
            <Link
              href="/#plans"
              className="hover:text-amber-400 transition-colors"
            >
              Institutional Plans
            </Link>
            <Link
              href="/#academy"
              className="hover:text-amber-400 transition-colors flex items-center gap-1"
            >
              <GraduationCap className="w-4 h-4 text-amber-400" />
              Crypto Academy
            </Link>
            <Link
              href="/#security"
              className="hover:text-amber-400 transition-colors flex items-center gap-1"
            >
              <Lock className="w-3.5 h-3.5 text-emerald-400" />
              MPC Security
            </Link>
            <Link
              href="/#faq"
              className="hover:text-amber-400 transition-colors"
            >
              FAQ
            </Link>
          </nav>

          {/* Right Action Buttons */}
          <div className="hidden md:flex items-center gap-4">
            {user ? (
              <div className="flex items-center gap-3">
                {isAdmin && (
                  <Link
                    href="/admin"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-300 hover:bg-amber-400/20 text-xs font-bold transition-all"
                  >
                    <Zap className="w-3.5 h-3.5 fill-amber-400" />
                    <span>Admin Portal</span>
                  </Link>
                )}

                <Link
                  href="/dashboard"
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/10 text-white text-sm font-semibold transition-all"
                >
                  <LayoutDashboard className="w-4 h-4 text-amber-400" />
                  <span>Vault Dashboard</span>
                </Link>

                <button
                  onClick={handleLogout}
                  title="Secure Logout"
                  className="p-2 rounded-xl bg-slate-900 hover:bg-rose-500/20 hover:text-rose-400 text-slate-400 border border-white/10 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              !isAuthPage && (
                <div className="flex items-center gap-3">
                  <Link
                    href="/login"
                    className="px-5 py-2.5 rounded-xl text-sm font-semibold text-slate-200 hover:text-white hover:bg-white/5 transition-colors"
                  >
                    Sign In
                  </Link>
                  <Link
                    href="/register"
                    className="px-5 py-2.5 rounded-xl text-sm font-bold bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-slate-950 shadow-lg shadow-amber-500/20 hover:scale-105 active:scale-95 transition-all"
                  >
                    Open Account
                  </Link>
                </div>
              )
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-2">
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="p-2.5 rounded-xl bg-slate-900 border border-white/10 text-slate-300 hover:text-white"
            >
              {mobileOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Responsive Mobile Sheet */}
      {mobileOpen && (
        <div className="md:hidden bg-slate-950/95 border-t border-white/10 px-4 pt-4 pb-6 space-y-4">
          <nav className="flex flex-col space-y-3">
            <Link
              href="/"
              onClick={() => setMobileOpen(false)}
              className="text-slate-300 hover:text-amber-400 py-1.5 font-medium"
            >
              Overview
            </Link>
            <Link
              href="/#plans"
              onClick={() => setMobileOpen(false)}
              className="text-slate-300 hover:text-amber-400 py-1.5 font-medium"
            >
              Institutional Plans
            </Link>
            <Link
              href="/#academy"
              onClick={() => setMobileOpen(false)}
              className="text-slate-300 hover:text-amber-400 py-1.5 font-medium flex items-center gap-2"
            >
              <GraduationCap className="w-4 h-4 text-amber-400" />
              Crypto Academy
            </Link>
            <Link
              href="/#security"
              onClick={() => setMobileOpen(false)}
              className="text-slate-300 hover:text-amber-400 py-1.5 font-medium flex items-center gap-2"
            >
              <Lock className="w-4 h-4 text-emerald-400" />
              MPC Security
            </Link>
            <Link
              href="/#faq"
              onClick={() => setMobileOpen(false)}
              className="text-slate-300 hover:text-amber-400 py-1.5 font-medium"
            >
              FAQ
            </Link>
          </nav>

          <div className="pt-4 border-t border-white/10 flex flex-col gap-3">
            {user ? (
              <>
                {isAdmin && (
                  <Link
                    href="/admin"
                    onClick={() => setMobileOpen(false)}
                    className="flex items-center justify-between px-4 py-3 rounded-xl bg-amber-400/10 border border-amber-400/30 text-amber-300 font-bold"
                  >
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 fill-amber-400" />
                      <span>Admin Portal</span>
                    </div>
                    <ChevronRight className="w-4 h-4" />
                  </Link>
                )}
                <Link
                  href="/dashboard"
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold shadow-lg"
                >
                  <LayoutDashboard className="w-4 h-4" />
                  <span>Vault Dashboard</span>
                </Link>
                <button
                  onClick={() => {
                    setMobileOpen(false);
                    handleLogout();
                  }}
                  className="w-full py-3 rounded-xl bg-slate-900 text-rose-400 border border-white/10 font-medium"
                >
                  Secure Logout
                </button>
              </>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                <Link
                  href="/login"
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center justify-center py-3 rounded-xl bg-slate-900 border border-white/10 text-white font-semibold"
                >
                  Sign In
                </Link>
                <Link
                  href="/register"
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center justify-center py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold shadow-lg shadow-amber-500/20"
                >
                  Open Account
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
