"use client";

import React from "react";

interface QrCodeProps {
  value: string;
  size?: number;
  currency?: string;
}

export function QrCode({ value, size = 180, currency = "BTC" }: QrCodeProps) {
  // Generate a deterministic 21x21 grid pattern from the address string
  const grid: boolean[][] = [];
  const seedStr = (value || "bc1qapex2026").padEnd(44, "0");

  for (let r = 0; r < 21; r++) {
    const row: boolean[] = [];
    for (let c = 0; c < 21; c++) {
      // Finder patterns in 3 corners
      const isTopLeft = r < 7 && c < 7;
      const isTopRight = r < 7 && c >= 14;
      const isBottomLeft = r >= 14 && c < 7;

      if (isTopLeft || isTopRight || isBottomLeft) {
        // Border of 7x7 square
        const rRel = isTopRight ? r : isBottomLeft ? r - 14 : r;
        const cRel = isTopRight ? c - 14 : isBottomLeft ? c : c;
        const isOuterBorder =
          rRel === 0 || rRel === 6 || cRel === 0 || cRel === 6;
        const isInnerSolid =
          rRel >= 2 && rRel <= 4 && cRel >= 2 && cRel <= 4;
        row.push(isOuterBorder || isInnerSolid);
      } else {
        // Pseudo-random bit based on characters in value
        const charCode = seedStr.charCodeAt((r * 21 + c) % seedStr.length);
        const bit = ((charCode * (r + 3) * (c + 5)) % 11) > 4;
        row.push(bit);
      }
    }
    grid.push(row);
  }

  const cellSize = size / 21;

  return (
    <div
      className="relative flex items-center justify-center bg-white p-4 rounded-2xl shadow-xl border border-white/20"
      style={{ width: size + 32, height: size + 32 }}
    >
      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        className="block"
      >
        {grid.map((row, r) =>
          row.map((cell, c) =>
            cell ? (
              <rect
                key={`${r}-${c}`}
                x={c * cellSize}
                y={r * cellSize}
                width={cellSize + 0.3}
                height={cellSize + 0.3}
                className="fill-slate-900"
              />
            ) : null
          )
        )}
      </svg>
      {/* Center luxury currency badge */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-10 h-10 rounded-full bg-slate-900 text-amber-400 font-bold text-xs flex items-center justify-center border-2 border-amber-400 shadow-md">
          {currency}
        </div>
      </div>
    </div>
  );
}
