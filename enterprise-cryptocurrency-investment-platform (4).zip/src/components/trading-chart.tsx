"use client";

import React, { useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { ArrowUpRight, ArrowDownRight, Activity, Calendar } from "lucide-react";

interface CoinOption {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  sparkline?: number[];
}

interface TradingChartProps {
  coins: CoinOption[];
}

export function TradingChart({ coins }: TradingChartProps) {
  const [selectedCoinId, setSelectedCoinId] = useState<string>("bitcoin");
  const [timeframe, setTimeframe] = useState<string>("7D");

  const selectedCoin =
    coins.find((c) => c.id === selectedCoinId) ||
    coins[0] || {
      id: "bitcoin",
      symbol: "BTC",
      name: "Bitcoin",
      price: 94820.5,
      change24h: 3.42,
      sparkline: [91200, 91800, 92400, 93100, 92800, 93900, 94820.5],
    };

  const isPos = selectedCoin.change24h >= 0;
  const spark = selectedCoin.sparkline || [selectedCoin.price];

  // Generate simulated historical points based on sparkline and timeframe
  const pointsCount =
    timeframe === "24H" ? 12 : timeframe === "7D" ? 14 : timeframe === "30D" ? 30 : 52;
  const basePrice = spark[0] || selectedCoin.price * 0.95;
  const currentPrice = selectedCoin.price;

  const chartData = Array.from({ length: pointsCount }, (_, idx) => {
    const ratio = idx / (pointsCount - 1);
    const noise = (Math.sin(idx * 1.5) + Math.cos(idx * 0.8)) * 0.008;
    const interpolated = basePrice + (currentPrice - basePrice) * ratio + currentPrice * noise;
    const label =
      timeframe === "24H"
        ? `${(idx * 2) % 24}:00`
        : timeframe === "7D"
        ? `Day ${idx + 1}`
        : timeframe === "30D"
        ? `Day ${idx + 1}`
        : `W${idx + 1}`;
    return {
      name: label,
      price: Number(interpolated.toFixed(2)),
    };
  });

  return (
    <div className="bg-slate-900/80 border border-white/10 rounded-3xl p-6 shadow-2xl backdrop-blur-md">
      {/* Header Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-2xl font-black text-white">
              {selectedCoin.name}
            </span>
            <span className="px-2 py-0.5 rounded-md bg-white/10 text-xs font-bold text-slate-300">
              {selectedCoin.symbol}/USD
            </span>
            <span
              className={`flex items-center gap-1 text-xs font-bold px-2.5 py-0.5 rounded-full ${
                isPos
                  ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                  : "bg-rose-500/10 text-rose-400 border border-rose-500/20"
              }`}
            >
              {isPos ? (
                <ArrowUpRight className="w-3.5 h-3.5" />
              ) : (
                <ArrowDownRight className="w-3.5 h-3.5" />
              )}
              {Math.abs(selectedCoin.change24h).toFixed(2)}%
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              {selectedCoin.price < 10
                ? `$${selectedCoin.price.toFixed(4)}`
                : `$${selectedCoin.price.toLocaleString("en-US", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}`}
            </span>
            <span className="text-xs text-slate-400 font-medium">
              Live MPC Oracle Index
            </span>
          </div>
        </div>

        {/* Coin Selection Tabs */}
        <div className="flex flex-wrap items-center gap-1.5">
          {coins.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCoinId(c.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                selectedCoinId === c.id
                  ? "bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20"
                  : "bg-white/5 hover:bg-white/10 text-slate-300 border border-white/5"
              }`}
            >
              {c.symbol}
            </button>
          ))}
        </div>
      </div>

      {/* Timeframe Switcher */}
      <div className="flex items-center justify-between border-b border-white/5 pb-4 mb-4">
        <div className="flex items-center gap-1">
          {["24H", "7D", "30D", "1Y"].map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                timeframe === tf
                  ? "bg-slate-800 text-amber-400 border border-amber-400/30"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
        <div className="hidden sm:flex items-center gap-2 text-xs text-slate-400">
          <Activity className="w-3.5 h-3.5 text-emerald-400" />
          <span>Tier-1 Exchange Aggregation (Binance, Coinbase, Kraken)</span>
        </div>
      </div>

      {/* Recharts Chart Area */}
      <div className="h-72 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={chartData}
            margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
          >
            <defs>
              <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                <stop
                  offset="5%"
                  stopColor={isPos ? "#10b981" : "#f43f5e"}
                  stopOpacity={0.4}
                />
                <stop
                  offset="95%"
                  stopColor={isPos ? "#10b981" : "#f43f5e"}
                  stopOpacity={0.0}
                />
              </linearGradient>
            </defs>
            <XAxis
              dataKey="name"
              stroke="#64748b"
              fontSize={10}
              tickLine={false}
              axisLine={false}
            />
            <YAxis
              domain={["auto", "auto"]}
              stroke="#64748b"
              fontSize={10}
              tickLine={false}
              axisLine={false}
              tickFormatter={(v) =>
                v < 10 ? `$${v}` : `$${v.toLocaleString()}`
              }
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "#0f172a",
                borderColor: "rgba(255,255,255,0.1)",
                borderRadius: "1rem",
                color: "#fff",
                fontSize: "12px",
                boxShadow: "0 10px 25px rgba(0,0,0,0.5)",
              }}
              formatter={(value: any) => [
                `$${Number(value).toLocaleString("en-US", {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2,
                })}`,
                "Price",
              ]}
            />
            <Area
              type="monotone"
              dataKey="price"
              stroke={isPos ? "#10b981" : "#f43f5e"}
              strokeWidth={2.5}
              fillOpacity={1}
              fill="url(#colorPrice)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
