import { db } from "./index";
import { users } from "./schema";
import { seedDatabase } from "./seed";

let seedingPromise: Promise<void> | null = null;
let hasSeeded = false;

export async function ensureSeeded() {
  if (hasSeeded) return;
  if (seedingPromise) return seedingPromise;

  seedingPromise = (async () => {
    try {
      const existing = await db.select().from(users).limit(1);
      if (existing.length === 0) {
        await seedDatabase();
      }
      hasSeeded = true;
    } catch (err) {
      console.error("Error in ensureSeeded:", err);
    } finally {
      seedingPromise = null;
    }
  })();

  return seedingPromise;
}
