import {
  pgTable,
  text,
  integer,
  numeric,
  boolean,
  timestamp,
  serial,
  jsonb,
  varchar,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  fullName: varchar("full_name", { length: 255 }).notNull(),
  role: varchar("role", { length: 50 }).default("user").notNull(), // 'user' | 'admin' | 'superadmin'
  emailVerified: boolean("email_verified").default(true).notNull(),
  twoFactorEnabled: boolean("two_factor_enabled").default(false).notNull(),
  twoFactorSecret: varchar("two_factor_secret", { length: 100 }),
  referralCode: varchar("referral_code", { length: 50 }).unique(),
  referredBy: varchar("referred_by", { length: 50 }),
  kycStatus: varchar("kyc_status", { length: 50 }).default("unverified").notNull(), // 'unverified' | 'pending' | 'verified' | 'rejected'
  kycDocumentUrl: text("kyc_document_url"),
  status: varchar("status", { length: 50 }).default("active").notNull(), // 'active' | 'suspended'
  loginCount: integer("login_count").default(0).notNull(),
  lastLoginAt: timestamp("last_login_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const wallets = pgTable("wallets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  currency: varchar("currency", { length: 20 }).notNull(), // 'BTC' | 'ETH' | 'XRP' | 'USDT' | 'SOL' | 'BNB' | 'LTC'
  balance: numeric("balance", { precision: 24, scale: 8 }).default("0").notNull(),
  lockedBalance: numeric("locked_balance", { precision: 24, scale: 8 }).default("0").notNull(),
  totalDeposited: numeric("total_deposited", { precision: 24, scale: 8 }).default("0").notNull(),
  totalWithdrawn: numeric("total_withdrawn", { precision: 24, scale: 8 }).default("0").notNull(),
  depositAddress: text("deposit_address"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const deposits = pgTable("deposits", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  currency: varchar("currency", { length: 20 }).notNull(),
  amount: numeric("amount", { precision: 24, scale: 8 }).notNull(),
  txid: varchar("txid", { length: 255 }).notNull(),
  proofUrl: text("proof_url"),
  network: varchar("network", { length: 100 }).notNull(),
  status: varchar("status", { length: 50 }).default("pending").notNull(), // 'pending' | 'confirmed' | 'rejected'
  confirmedAt: timestamp("confirmed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const withdrawals = pgTable("withdrawals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  currency: varchar("currency", { length: 20 }).notNull(),
  amount: numeric("amount", { precision: 24, scale: 8 }).notNull(),
  address: varchar("address", { length: 255 }).notNull(),
  network: varchar("network", { length: 100 }).notNull(),
  status: varchar("status", { length: 50 }).default("pending").notNull(), // 'pending' | 'approved' | 'rejected' | 'completed'
  adminNote: text("admin_note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const investmentPlans = pgTable("investment_plans", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description").notNull(),
  minInvestment: numeric("min_investment", { precision: 24, scale: 8 }).notNull(),
  maxInvestment: numeric("max_investment", { precision: 24, scale: 8 }).notNull(),
  durationDays: integer("duration_days").notNull(),
  managementFeePct: numeric("management_fee_pct", { precision: 10, scale: 2 }).notNull(),
  expectedReturnPct: numeric("expected_return_pct", { precision: 10, scale: 2 }).notNull(),
  lockPeriodDays: integer("lock_period_days").notNull(),
  compoundingAllowed: boolean("compounding_allowed").default(true).notNull(),
  earlyWithdrawalAllowed: boolean("early_withdrawal_allowed").default(true).notNull(),
  supportedCurrencies: jsonb("supported_currencies").notNull(), // e.g. ["BTC", "ETH", "USDT", "SOL"]
  termsText: text("terms_text").notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const activeInvestments = pgTable("active_investments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  planId: integer("plan_id").notNull().references(() => investmentPlans.id, { onDelete: "cascade" }),
  currency: varchar("currency", { length: 20 }).notNull(),
  amount: numeric("amount", { precision: 24, scale: 8 }).notNull(),
  expectedProfit: numeric("expected_profit", { precision: 24, scale: 8 }).notNull(),
  accruedProfit: numeric("accrued_profit", { precision: 24, scale: 8 }).default("0").notNull(),
  status: varchar("status", { length: 50 }).default("active").notNull(), // 'active' | 'completed' | 'withdrawn'
  startDate: timestamp("start_date").defaultNow().notNull(),
  endDate: timestamp("end_date").notNull(),
  lastAccruedAt: timestamp("last_accrued_at").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: varchar("type", { length: 50 }).notNull(), // 'deposit' | 'withdrawal' | 'investment' | 'payout' | 'referral_commission'
  currency: varchar("currency", { length: 20 }).notNull(),
  amount: numeric("amount", { precision: 24, scale: 8 }).notNull(),
  description: text("description").notNull(),
  status: varchar("status", { length: 50 }).default("completed").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const referralCommissions = pgTable("referral_commissions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  referredUserId: integer("referred_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  amount: numeric("amount", { precision: 24, scale: 8 }).notNull(),
  currency: varchar("currency", { length: 20 }).notNull(),
  level: integer("level").default(1).notNull(),
  status: varchar("status", { length: 50 }).default("paid").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const supportTickets = pgTable("support_tickets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  subject: varchar("subject", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  status: varchar("status", { length: 50 }).default("open").notNull(), // 'open' | 'in_progress' | 'resolved' | 'closed'
  priority: varchar("priority", { length: 50 }).default("medium").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const ticketMessages = pgTable("ticket_messages", {
  id: serial("id").primaryKey(),
  ticketId: integer("ticket_id").notNull().references(() => supportTickets.id, { onDelete: "cascade" }),
  senderId: integer("sender_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  senderRole: varchar("sender_role", { length: 50 }).notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const cryptoAcademyLessons = pgTable("crypto_academy_lessons", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  readTimeMinutes: integer("read_time_minutes").notNull(),
  level: varchar("level", { length: 50 }).notNull(), // 'Beginner' | 'Intermediate' | 'Advanced'
  summary: text("summary").notNull(),
  content: text("content").notNull(),
  videoUrl: text("video_url"),
  quizQuestions: jsonb("quiz_questions"), // JSON array of questions and options
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value").notNull(),
  description: text("description"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  action: varchar("action", { length: 255 }).notNull(),
  ipAddress: varchar("ip_address", { length: 100 }).default("127.0.0.1"),
  userAgent: text("user_agent"),
  details: text("details"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const newsArticles = pgTable("news_articles", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  category: varchar("category", { length: 100 }).notNull(),
  excerpt: text("excerpt").notNull(),
  content: text("content").notNull(),
  source: varchar("source", { length: 100 }).notNull(),
  publishedAt: timestamp("published_at").defaultNow().notNull(),
});
