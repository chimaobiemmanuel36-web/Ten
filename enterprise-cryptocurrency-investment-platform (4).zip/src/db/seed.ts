import bcrypt from "bcryptjs";
import { db } from "./index";
import {
  users,
  wallets,
  investmentPlans,
  systemSettings,
  cryptoAcademyLessons,
  newsArticles,
  activeInvestments,
  deposits,
  withdrawals,
  transactions,
  referralCommissions,
  supportTickets,
  ticketMessages,
  auditLogs,
} from "./schema";
import { eq } from "drizzle-orm";

export async function seedDatabase() {
  try {
    // Check if super admin already exists
    const existingAdmin = await db
      .select()
      .from(users)
      .where(eq(users.email, "admin2004@hotmail.com"))
      .limit(1);

    if (existingAdmin.length > 0) {
      console.log("Database already seeded.");
      return;
    }

    console.log("Seeding ApexCrypto Enterprise database...");

    const adminPasswordHash = await bcrypt.hash("pass2004@", 10);
    const demoUserPasswordHash = await bcrypt.hash("UserDemo2026!", 10);

    // 1. Create Super Admin and Demo User
    const [superAdmin] = await db
      .insert(users)
      .values({
        email: "admin2004@hotmail.com",
        passwordHash: adminPasswordHash,
        fullName: "Apex Super Administrator",
        role: "superadmin",
        emailVerified: true,
        twoFactorEnabled: true,
        twoFactorSecret: "JBSWY3DPEHPK3PXP",
        referralCode: "APEX2004ADMIN",
        kycStatus: "verified",
        status: "active",
        loginCount: 42,
        lastLoginAt: new Date(),
      })
      .returning();

    const [demoUser] = await db
      .insert(users)
      .values({
        email: "user@apexcrypto.io",
        passwordHash: demoUserPasswordHash,
        fullName: "Alexander Vance",
        role: "user",
        emailVerified: true,
        twoFactorEnabled: false,
        referralCode: "VANCE8899",
        referredBy: "APEX2004ADMIN",
        kycStatus: "verified",
        kycDocumentUrl: "https://apexcrypto.io/kyc/verified-passport-sample.png",
        status: "active",
        loginCount: 18,
        lastLoginAt: new Date(),
      })
      .returning();

    // 2. Create System Settings (Encrypted Wallet Addresses + Telegram & Support Config)
    const defaultSettings = [
      {
        key: "wallet_BTC",
        value: "bc1q7f80hdwgjxs9k8y2hnmnqsjvy4sk4zz4hdwlz8",
        description: "Bitcoin (BTC) Deposit Wallet Address",
      },
      {
        key: "wallet_XRP",
        value: "rwbEGbEB5EUxgzum561897LYWM5oHQQob2",
        description: "Ripple (XRP) Deposit Wallet Address",
      },
      {
        key: "wallet_USDT",
        value: "0x6495f1ffF39FDedBA7FAdda1aBffA2b118C25D61",
        description: "Tether (USDT ERC-20) Deposit Wallet Address",
      },
      {
        key: "wallet_SOL",
        value: "8sSe9BgHqfN4vyM9QtsmfsJa9WXPaxdHTAs7xuaDiGKC",
        description: "Solana (SOL) Deposit Wallet Address",
      },
      {
        key: "wallet_BNB",
        value: "0x6495f1ffF39FDedBA7FAdda1aBffA2b118C25D61",
        description: "Binance Coin (BNB BEP-20) Deposit Wallet Address",
      },
      {
        key: "wallet_LTC",
        value: "ltc1qk7ks4rqau7xe3qk40m7rntf2yf852ku6asp793",
        description: "Litecoin (LTC) Deposit Wallet Address",
      },
      {
        key: "wallet_ETH",
        value: "0x6495f1ffF39FDedBA7FAdda1aBffA2b118C25D61",
        description: "Ethereum (ETH ERC-20) Deposit Wallet Address",
      },
      {
        key: "telegram_bot_token",
        value: "718290384:AAHqK83m908vApexEnterpriseBotToken",
        description: "Telegram Bot API Token for system & alert notifications",
      },
      {
        key: "telegram_chat_id",
        value: "-100293847583",
        description: "Telegram Channel/Group Chat ID for live alerts",
      },
      {
        key: "support_email",
        value: "support@apexcrypto.io",
        description: "Customer Support Official Email",
      },
      {
        key: "support_phone",
        value: "+1 (800) 934-8821",
        description: "Customer Support Dedicated Helpline",
      },
      {
        key: "support_hours",
        value: "24/7 Global Multilingual Concierge Support",
      },
      {
        key: "site_name",
        value: "ApexCrypto Enterprise",
        description: "Platform Display Title",
      },
      {
        key: "maintenance_mode",
        value: "false",
        description: "Set to true to activate emergency system maintenance",
      },
    ];

    for (const s of defaultSettings) {
      await db.insert(systemSettings).values(s).onConflictDoNothing();
    }

    // 3. Create Wallets for Demo User
    const demoWalletsData = [
      { currency: "BTC", balance: "1.45000000", totalDeposited: "2.00000000", totalWithdrawn: "0.55000000" },
      { currency: "ETH", balance: "14.80000000", totalDeposited: "18.00000000", totalWithdrawn: "3.20000000" },
      { currency: "USDT", balance: "28450.00000000", totalDeposited: "35000.00000000", totalWithdrawn: "6550.00000000" },
      { currency: "SOL", balance: "120.00000000", totalDeposited: "150.00000000", totalWithdrawn: "30.00000000" },
      { currency: "XRP", balance: "5400.00000000", totalDeposited: "6000.00000000", totalWithdrawn: "600.00000000" },
      { currency: "BNB", balance: "12.50000000", totalDeposited: "15.00000000", totalWithdrawn: "2.50000000" },
      { currency: "LTC", balance: "45.00000000", totalDeposited: "50.00000000", totalWithdrawn: "5.00000000" },
    ];

    for (const w of demoWalletsData) {
      await db.insert(wallets).values({
        userId: demoUser.id,
        currency: w.currency,
        balance: w.balance,
        lockedBalance: "0",
        totalDeposited: w.totalDeposited,
        totalWithdrawn: w.totalWithdrawn,
        depositAddress: defaultSettings.find((s) => s.key === `wallet_${w.currency}`)?.value || "",
      });
    }

    // 4. Create Investment Plans
    const samplePlans = [
      {
        name: "Apex Genesis Starter",
        description: "Entry-level institutional algorithmic trading yield fund tailored for high-liquidity capital preservation with low volatility.",
        minInvestment: "100.00000000",
        maxInvestment: "4999.00000000",
        durationDays: 30,
        managementFeePct: "0.75",
        expectedReturnPct: "8.50",
        lockPeriodDays: 30,
        compoundingAllowed: true,
        earlyWithdrawalAllowed: true,
        supportedCurrencies: ["USDT", "BTC", "ETH", "SOL"],
        termsText: "Hypothetical yield projections are based on trailing 3-year algorithmic backtesting. Early withdrawal fee: 2.5%. Principal lock: 30 days.",
        active: true,
      },
      {
        name: "Quantum Alpha Fixed",
        description: "Mid-to-long term delta-neutral arbitration strategy executing high-frequency cross-exchange liquidity captures across tier-1 venues.",
        minInvestment: "5000.00000000",
        maxInvestment: "49999.00000000",
        durationDays: 90,
        managementFeePct: "1.20",
        expectedReturnPct: "18.40",
        lockPeriodDays: 60,
        compoundingAllowed: true,
        earlyWithdrawalAllowed: true,
        supportedCurrencies: ["USDT", "BTC", "ETH"],
        termsText: "Returns distributed daily at 00:00 UTC. Compounding recalculates compound principal daily. Early withdrawal after 60 days has 0% penalty.",
        active: true,
      },
      {
        name: "Solana Growth Engine",
        description: "High-performance Solana ecosystem validator and MEV-optimizing liquid staking pool with automated validator restaking.",
        minInvestment: "500.00000000",
        maxInvestment: "100000.00000000",
        durationDays: 60,
        managementFeePct: "0.90",
        expectedReturnPct: "14.20",
        lockPeriodDays: 30,
        compoundingAllowed: true,
        earlyWithdrawalAllowed: true,
        supportedCurrencies: ["SOL", "USDT"],
        termsText: "Solana MEV validator rewards are distributed directly in SOL or USDT. Early exit penalty 1.5% prior to 30 days.",
        active: true,
      },
      {
        name: "Institutional Yield Plus",
        description: "Premium enterprise portfolio tailored for family offices and institutional treasuries. Managed by dedicated quantitative analysts.",
        minInvestment: "25000.00000000",
        maxInvestment: "1000000.00000000",
        durationDays: 180,
        managementFeePct: "0.50",
        expectedReturnPct: "36.80",
        lockPeriodDays: 90,
        compoundingAllowed: true,
        earlyWithdrawalAllowed: false,
        supportedCurrencies: ["USDT", "BTC", "ETH", "BNB"],
        termsText: "Accredited institutional investor terms apply. Principal and interest guaranteed against platform smart contract exploits via institutional insurance cover.",
        active: true,
      },
      {
        name: "DeFi Liquidity Vault",
        description: "Automated market maker (AMM) liquidity provisioning and impermanent loss hedging across Uniswap v3 and Raydium concentrated liquidity pools.",
        minInvestment: "1000.00000000",
        maxInvestment: "50000.00000000",
        durationDays: 45,
        managementFeePct: "1.00",
        expectedReturnPct: "11.60",
        lockPeriodDays: 15,
        compoundingAllowed: true,
        earlyWithdrawalAllowed: true,
        supportedCurrencies: ["USDT", "ETH", "SOL", "BNB"],
        termsText: "Dynamic APR readjustment weekly based on decentralized pool trading volume and fees.",
        active: true,
      },
      {
        name: "Ethereum Staking Validator",
        description: "Direct Beacon Chain staking node ownership share with zero slashing risk through multi-validator redundancy architecture.",
        minInvestment: "2000.00000000",
        maxInvestment: "250000.00000000",
        durationDays: 120,
        managementFeePct: "0.80",
        expectedReturnPct: "22.50",
        lockPeriodDays: 60,
        compoundingAllowed: true,
        earlyWithdrawalAllowed: true,
        supportedCurrencies: ["ETH", "USDT"],
        termsText: "Staking yield paid in ETH. Projections reflect historical staking APY plus priority tip fees.",
        active: true,
      },
    ];

    const insertedPlans = [];
    for (const plan of samplePlans) {
      const [inserted] = await db.insert(investmentPlans).values(plan).returning();
      insertedPlans.push(inserted);
    }

    // 5. Create Sample Active Investments for Demo User
    if (insertedPlans.length > 0) {
      await db.insert(activeInvestments).values([
        {
          userId: demoUser.id,
          planId: insertedPlans[1].id,
          currency: "USDT",
          amount: "10000.00000000",
          expectedProfit: "1840.00000000",
          accruedProfit: "480.50000000",
          status: "active",
          startDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000), // 15 days ago
          endDate: new Date(Date.now() + 75 * 24 * 60 * 60 * 1000),
          lastAccruedAt: new Date(),
        },
        {
          userId: demoUser.id,
          planId: insertedPlans[0].id,
          currency: "BTC",
          amount: "0.50000000",
          expectedProfit: "0.04250000",
          accruedProfit: "0.01850000",
          status: "active",
          startDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), // 10 days ago
          endDate: new Date(Date.now() + 20 * 24 * 60 * 60 * 1000),
          lastAccruedAt: new Date(),
        },
        {
          userId: demoUser.id,
          planId: insertedPlans[2].id,
          currency: "SOL",
          amount: "50.00000000",
          expectedProfit: "7.10000000",
          accruedProfit: "3.20000000",
          status: "active",
          startDate: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000),
          endDate: new Date(Date.now() + 48 * 24 * 60 * 60 * 1000),
          lastAccruedAt: new Date(),
        },
      ]);
    }

    // 6. Create Sample Deposits, Withdrawals, Transactions & Referral Commissions
    await db.insert(deposits).values([
      {
        userId: demoUser.id,
        currency: "USDT",
        amount: "15000.00000000",
        txid: "0x892a34b8c9d012e84715f2eab9c837482a173849503817293a218273645e4120",
        network: "ERC-20",
        status: "confirmed",
        confirmedAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000),
      },
      {
        userId: demoUser.id,
        currency: "BTC",
        amount: "1.00000000",
        txid: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        network: "Bitcoin Native",
        status: "confirmed",
        confirmedAt: new Date(Date.now() - 18 * 24 * 60 * 60 * 1000),
      },
      {
        userId: demoUser.id,
        currency: "ETH",
        amount: "5.00000000",
        txid: "0xf9a32c45e8210375a89274cb18384931082847291048201948293c128471849a",
        network: "ERC-20",
        status: "confirmed",
        confirmedAt: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000),
      },
      {
        userId: demoUser.id,
        currency: "SOL",
        amount: "100.00000000",
        txid: "3yX9F7uP2rQ8c6L5vG4kZ1mN9pB8vE6wR7tY2oP4xS8c1gM3nQ6lK9wE8jT2vL1x",
        network: "Solana",
        status: "pending",
      },
    ]);

    await db.insert(withdrawals).values([
      {
        userId: demoUser.id,
        currency: "USDT",
        amount: "2500.00000000",
        address: "0x1234567890abcdef1234567890abcdef12345678",
        network: "ERC-20",
        status: "completed",
        adminNote: "Verified and broadcasted by ApexTreasury Vault Node #4",
      },
      {
        userId: demoUser.id,
        currency: "ETH",
        amount: "1.50000000",
        address: "0xa1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1",
        network: "ERC-20",
        status: "pending",
        adminNote: "Under automated AML & compliance screening",
      },
    ]);

    await db.insert(transactions).values([
      {
        userId: demoUser.id,
        type: "deposit",
        currency: "USDT",
        amount: "15000.00000000",
        description: "Confirmed USDT ERC-20 Deposit via Ethereum network",
        status: "completed",
      },
      {
        userId: demoUser.id,
        type: "investment",
        currency: "USDT",
        amount: "10000.00000000",
        description: "Allocated to Quantum Alpha Fixed Strategy Plan",
        status: "completed",
      },
      {
        userId: demoUser.id,
        type: "payout",
        currency: "USDT",
        amount: "125.40000000",
        description: "Daily automated dividend payout - Quantum Alpha Fixed",
        status: "completed",
      },
      {
        userId: demoUser.id,
        type: "referral_commission",
        currency: "USDT",
        amount: "450.00000000",
        description: "Tier 1 Referral Commission - Alexander Vance network",
        status: "completed",
      },
    ]);

    await db.insert(referralCommissions).values([
      {
        userId: superAdmin.id,
        referredUserId: demoUser.id,
        amount: "450.00000000",
        currency: "USDT",
        level: 1,
        status: "paid",
      },
    ]);

    await db.insert(supportTickets).values([
      {
        userId: demoUser.id,
        subject: "Institutional Wire Verification & Higher Deposit Limits",
        category: "KYC & Account Limits",
        status: "resolved",
        priority: "high",
      },
      {
        userId: demoUser.id,
        subject: "Question regarding Solana Validator automated restaking schedule",
        category: "Investment Plans",
        status: "in_progress",
        priority: "medium",
      },
    ]);

    // 7. Seed Crypto Academy Lessons
    const lessons = [
      {
        title: "Introduction to Enterprise Digital Asset Custody & Security",
        category: "Security & Custody",
        readTimeMinutes: 7,
        level: "Beginner",
        summary: "Understand the fundamentals of multi-signature vaults, hardware security modules (HSMs), and cold/hot wallet segregation.",
        content: `
# Mastering Enterprise Digital Asset Security

In the modern financial landscape, cryptocurrency security extends far beyond standard passwords. For enterprise investors and institutions, protecting digital capital requires layered security architectures.

## 1. Multi-Signature & MPC Threshold Vaults
Multi-Party Computation (MPC) replaces single private keys with distributed key shares held by isolated servers across different jurisdictions.
- **Zero Single Point of Failure**: Even if one server is compromised, the private key cannot be reconstructed.
- **Role-Based Approvals**: Enterprise transactions require consensus across compliance, finance, and treasury teams.

## 2. Cold Storage vs. Hot Vaults
- **95% Cold Storage**: All long-term principal balances are stored in offline air-gapped vaults protected in physical vaults.
- **5% Hot Reserves**: Only active liquidity required for immediate withdrawals resides in automated hot vaults with real-time anomaly detection.
        `,
        videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
        quizQuestions: [
          {
            question: "What is the primary advantage of MPC Threshold Vaults?",
            options: [
              "Faster transaction fees on Bitcoin",
              "Zero single point of failure by distributing key shares",
              "Unlimited leverage trading",
              "Automatic tax deduction",
            ],
            correctAnswer: 1,
          },
          {
            question: "What percentage of funds is typically held in air-gapped Cold Storage?",
            options: ["10%", "30%", "50%", "95% or higher"],
            correctAnswer: 3,
          },
        ],
      },
      {
        title: "Quantitative Arbitrage & High-Frequency Yield Fundamentals",
        category: "Investment Strategies",
        readTimeMinutes: 10,
        level: "Intermediate",
        summary: "How delta-neutral algorithmic strategies capture yield without directional crypto price risk.",
        content: `
# Understanding Delta-Neutral Yield

One of the most powerful institutional crypto strategies is Delta-Neutral Arbitrage. By simultaneously entering long and short positions across spot and perpetual futures markets, funds capture funding rates while eliminating volatility exposure.

## Key Mechanisms
1. **Perpetual Funding Capture**: When funding rates are positive, holding spot assets while shorting perpetual futures generates continuous 8-25% annualized yield.
2. **Cross-Exchange Arbitrage**: Exploiting brief pricing discrepancies between tier-1 exchanges like Binance, Coinbase, and Kraken.
        `,
        quizQuestions: [
          {
            question: "How does delta-neutral arbitrage eliminate price volatility risk?",
            options: [
              "By holding 100% in cash",
              "By simultaneously holding spot long and futures short positions",
              "By investing only in meme coins",
              "By locking tokens for 10 years",
            ],
            correctAnswer: 1,
          },
        ],
      },
      {
        title: "Solana MEV, Validator Restaking & Proof-of-History",
        category: "Blockchain Education",
        readTimeMinutes: 12,
        level: "Advanced",
        summary: "Deep dive into Solana's Proof-of-History consensus and Maximal Extractable Value (MEV) capture techniques.",
        content: `
# Solana Validator Engineering & MEV Capture

Solana delivers over 3,000 transactions per second with sub-second finality through Proof-of-History (PoH) and Turbine block propagation.

## Validator Restaking Yield
By deploying staked SOL into Jito-Solana MEV validators, investors earn not only base protocol inflation rewards (~6.8% APY) but also searcher priority tips and MEV bundles, boosting net yields to 11-14% APY.
        `,
        quizQuestions: [
          {
            question: "What technology enables Solana's sub-second finality and high throughput?",
            options: [
              "Proof-of-Work mining",
              "Proof-of-History (PoH) and Turbine block propagation",
              "Manual block signing",
              "Off-chain spreadsheets",
            ],
            correctAnswer: 1,
          },
        ],
      },
    ];

    for (const l of lessons) {
      await db.insert(cryptoAcademyLessons).values(l);
    }

    // 8. Seed News Articles
    const articles = [
      {
        title: "ApexCrypto Expands Institutional Treasury Custody Architecture with Multi-Region MPC",
        slug: "apexcrypto-expands-institutional-treasury-mpc",
        category: "Platform News",
        excerpt: "ApexCrypto Enterprise completes ISO-27001 and SOC2 Type II compliance audit while deploying distributed key management across Zurich, Singapore, and New York.",
        content: "ApexCrypto Enterprise has officially launched its next-generation multi-region MPC custody architecture...",
        source: "ApexCrypto Official Room",
      },
      {
        title: "Global Crypto Institutional Inflows Hit Record $14.8 Billion in Q1 2026",
        slug: "global-crypto-institutional-inflows-record-q1-2026",
        category: "Market Insights",
        excerpt: "Spot Bitcoin and Ethereum ETP products alongside institutional yield funds lead the surge as sovereign wealth funds allocate to digital assets.",
        content: "Institutional participation in cryptocurrency markets reached an all-time high this quarter...",
        source: "Bloomberg Digital Assets",
      },
      {
        title: "Solana TVL Surpasses $8 Billion as Liquid Restaking Accelerates",
        slug: "solana-tvl-surpasses-8-billion-restaking",
        category: "DeFi & Ecosystem",
        excerpt: "High-throughput DeFi protocols on Solana see massive liquidity growth driven by automated MEV-capturing validator staking pools.",
        content: "The Solana DeFi ecosystem continues its rapid expansion in 2026...",
        source: "CoinDesk Research",
      },
    ];

    for (const a of articles) {
      await db.insert(newsArticles).values(a);
    }

    // 9. Add audit log
    await db.insert(auditLogs).values({
      userId: superAdmin.id,
      action: "DATABASE_INITIAL_SEED",
      ipAddress: "127.0.0.1",
      userAgent: "ApexCrypto Enterprise Automated Installer v2026.1",
      details: "Seeded superadmin account admin2004@hotmail.com, demo user, 7 investment plans, crypto academy, settings, and sample transactions.",
    });

    console.log("Database seeded successfully with superadmin admin2004@hotmail.com and demo data!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}
