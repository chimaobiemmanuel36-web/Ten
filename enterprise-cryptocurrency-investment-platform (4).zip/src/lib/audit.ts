import { db } from "@/db";
import { auditLogs, systemSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function logAudit({
  userId,
  action,
  ipAddress = "127.0.0.1",
  userAgent = "ApexCrypto Web Client",
  details,
}: {
  userId?: number;
  action: string;
  ipAddress?: string;
  userAgent?: string;
  details?: string;
}) {
  try {
    await db.insert(auditLogs).values({
      userId: userId || null,
      action,
      ipAddress,
      userAgent,
      details: details || "",
    });

    // If critical alert, attempt to notify Telegram if configured
    if (action.includes("CRITICAL") || action.includes("WITHDRAWAL") || action.includes("ADMIN")) {
      await sendTelegramAlert(`🚨 [ApexCrypto Alert] ${action}\nDetails: ${details || "N/A"}`);
    }
  } catch (error) {
    console.error("Failed to write audit log:", error);
  }
}

export async function sendTelegramAlert(message: string) {
  try {
    const tokenSetting = await db
      .select()
      .from(systemSettings)
      .where(eq(systemSettings.key, "telegram_bot_token"))
      .limit(1);
    const chatSetting = await db
      .select()
      .from(systemSettings)
      .where(eq(systemSettings.key, "telegram_chat_id"))
      .limit(1);

    if (!tokenSetting[0]?.value || !chatSetting[0]?.value) return;

    // Simulate or send alert
    const token = tokenSetting[0].value;
    const chatId = chatSetting[0].value;

    if (token.includes("BotToken") || !token.startsWith("bot")) {
      // Demo token - log to server console
      console.log(`[Telegram Alert Simulation to Chat ${chatId}]: ${message}`);
      return;
    }

    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text: message }),
    }).catch(() => {});
  } catch {
    // Non-blocking
  }
}
