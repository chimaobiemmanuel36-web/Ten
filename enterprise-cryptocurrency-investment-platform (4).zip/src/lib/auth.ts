import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { cookies, headers } from "next/headers";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

const JWT_SECRET = process.env.JWT_SECRET || "enterprise_apex_crypto_jwt_secret_key_2026";
const COOKIE_NAME = "apex_crypto_session";

export interface TokenPayload {
  userId: number;
  email: string;
  role: string;
}

export function createAuthToken(payload: TokenPayload, rememberMe: boolean = true): string {
  const expiresIn = rememberMe ? "30d" : "1d";
  return jwt.sign(payload, JWT_SECRET, { expiresIn });
}

export function verifyAuthToken(token: string): TokenPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as TokenPayload;
  } catch {
    return null;
  }
}

export async function setAuthCookie(token: string, rememberMe: boolean = true) {
  const cookieStore = await cookies();
  const maxAge = rememberMe ? 30 * 24 * 60 * 60 : 24 * 60 * 60; // 30 days or 1 day
  cookieStore.set(COOKIE_NAME, token, {
    httpOnly: false,
    secure: false, // Compatible with preview HTTP/HTTPS proxies and iframes
    sameSite: "lax",
    path: "/",
    maxAge,
  });
  cookieStore.set("apex_crypto_token", token, {
    httpOnly: false,
    secure: false,
    sameSite: "lax",
    path: "/",
    maxAge,
  });
}

export async function clearAuthCookie() {
  const cookieStore = await cookies();
  cookieStore.delete(COOKIE_NAME);
  cookieStore.delete("apex_crypto_token");
}

export async function getCurrentUser(req?: Request) {
  try {
    const cookieStore = await cookies();
    let token =
      cookieStore.get(COOKIE_NAME)?.value ||
      cookieStore.get("apex_crypto_token")?.value;

    if (!token && req) {
      const authHeader = req.headers.get("authorization") || req.headers.get("Authorization");
      if (authHeader && authHeader.startsWith("Bearer ")) {
        token = authHeader.replace("Bearer ", "").trim();
      }
      if (!token) {
        token = req.headers.get("x-auth-token") || undefined;
      }
    }

    if (!token) {
      try {
        const headerStore = await headers();
        const authHeader = headerStore.get("authorization") || headerStore.get("Authorization");
        if (authHeader && authHeader.startsWith("Bearer ")) {
          token = authHeader.replace("Bearer ", "").trim();
        }
        if (!token) {
          token = headerStore.get("x-auth-token") || undefined;
        }
        if (!token) {
          const cookieHeader = headerStore.get("cookie") || "";
          const match =
            cookieHeader.match(new RegExp(`(^|;)\\s*${COOKIE_NAME}\\s*=\\s*([^;]+)`)) ||
            cookieHeader.match(new RegExp(`(^|;)\\s*apex_crypto_token\\s*=\\s*([^;]+)`));
          if (match) {
            token = match[2];
          }
        }
      } catch {
        // ignore if headers() not available in some context
      }
    }

    if (!token) return null;

    const payload = verifyAuthToken(token);
    if (!payload) return null;

    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, payload.userId))
      .limit(1);

    if (!user || user.status !== "active") return null;

    const { passwordHash, twoFactorSecret, ...sanitizedUser } = user;
    return sanitizedUser;
  } catch (error) {
    console.error("Error in getCurrentUser:", error);
    return null;
  }
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function calculatePasswordStrength(password: string): {
  score: number;
  label: string;
  color: string;
} {
  let score = 0;
  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;

  if (score <= 1) return { score: 1, label: "Weak", color: "text-red-500 bg-red-500/20" };
  if (score === 2) return { score: 2, label: "Fair", color: "text-amber-500 bg-amber-500/20" };
  if (score === 3) return { score: 3, label: "Good", color: "text-yellow-400 bg-yellow-400/20" };
  if (score === 4) return { score: 4, label: "Strong", color: "text-emerald-400 bg-emerald-400/20" };
  return { score: 5, label: "Military Grade", color: "text-emerald-500 bg-emerald-500/30" };
}
